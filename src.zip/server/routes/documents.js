import { Router } from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { getStateSnapshot } from '../storage/fileStateStore.js';
import {
  renderHtmlDocumentToPdf,
} from '../storage/documentPdfRenderer.js';
import { hasValidPublicQuoteAccess } from '../security/publicQuoteAccess.js';
import {
  buildContractDocumentHtml,
  buildWeeklyInventoryHtml,
} from '../../src/services/webBridge.js';

const router = Router();
const internalKey = String(process.env.APP_INTERNAL_KEY ?? '').trim();
const maxDocumentHtmlBytes = Number(
  process.env.DOCUMENT_HTML_MAX_BYTES ?? 4 * 1024 * 1024,
);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '../..');
const contractLogoPath = path.join(
  projectRoot,
  'public',
  'imagenes',
  'logo_el_copetin_redisenado.png',
);
let contractLogoDataUrlPromise = null;
const DOCUMENT_ACCESS_TOKEN_TTL_MS = 2 * 60 * 1000;
const documentAccessSecret = internalKey || String(
  process.env.DOCUMENT_ACCESS_SECRET
    ?? process.env.SESSION_SECRET
    ?? 'copetin-document-access',
).trim();

const signDocumentAccessPayload = (payload) => createHmac('sha256', documentAccessSecret)
  .update(payload)
  .digest('base64url');

const createDocumentAccessToken = ({ kind, identifier }) => {
  const expiresAt = Date.now() + DOCUMENT_ACCESS_TOKEN_TTL_MS;
  const payload = [
    String(kind ?? '').trim(),
    String(identifier ?? '').trim(),
    String(expiresAt),
  ].join(':');
  return `${expiresAt}.${signDocumentAccessPayload(payload)}`;
};

const hasValidDocumentAccessToken = ({ token, kind, identifier }) => {
  const rawToken = String(token ?? '').trim();
  const separatorIndex = rawToken.indexOf('.');
  if (separatorIndex <= 0) return false;

  const expiresAtRaw = rawToken.slice(0, separatorIndex);
  const providedSignature = rawToken.slice(separatorIndex + 1);
  const expiresAt = Number(expiresAtRaw);
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now() || !providedSignature) {
    return false;
  }

  const payload = [
    String(kind ?? '').trim(),
    String(identifier ?? '').trim(),
    String(expiresAt),
  ].join(':');
  const expectedSignature = signDocumentAccessPayload(payload);

  try {
    const providedBuffer = Buffer.from(providedSignature);
    const expectedBuffer = Buffer.from(expectedSignature);
    return providedBuffer.length === expectedBuffer.length
      && timingSafeEqual(providedBuffer, expectedBuffer);
  } catch {
    return false;
  }
};


const getContractLogoDataUrl = async () => {
  if (!contractLogoDataUrlPromise) {
    contractLogoDataUrlPromise = fs.readFile(contractLogoPath)
      .then((buffer) => `data:image/png;base64,${buffer.toString('base64')}`)
      .catch((error) => {
        contractLogoDataUrlPromise = null;
        throw error;
      });
  }
  return contractLogoDataUrlPromise;
};

const embedContractAssets = async (html) => {
  const logoDataUrl = await getContractLogoDataUrl();
  return String(html ?? '')
    .replace(
      /(?:https?:\/\/[^"'\s>]+)?\/imagenes\/logo_el_copetin_redisenado\.png/gi,
      logoDataUrl,
    );
};

const getLocalDocumentAssetBaseUrl = () => {
  const configured = String(process.env.DOCUMENT_ASSET_BASE_URL ?? '').trim();
  if (configured) return configured.replace(/\/$/, '');

  const port = Number.parseInt(process.env.PORT ?? '4000', 10) || 4000;
  return `http://127.0.0.1:${port}`;
};

const embedInventoryAssets = async (html) => {
  // Las fotos no se incrustan como Base64: en órdenes grandes eso hacía crecer
  // demasiado el RSS de Node. En su lugar Chromium las solicita directamente
  // al mismo backend por loopback, evitando DNS/TLS/Nginx y manteniendo las
  // imágenes fuera del heap de Node.
  const localAssetBaseUrl = getLocalDocumentAssetBaseUrl();
  const nextHtml = String(html ?? '').replace(
    /(?:https?:\/\/[^"'\s>]+)?(\/uploads\/products\/[^"'\s>]+)/gi,
    (_match, assetPath) => `${localAssetBaseUrl}${assetPath}`,
  );

  return embedContractAssets(nextHtml);
};

const requireInternalKey = (req, res, next) => {
  if (!internalKey) {
    next();
    return;
  }

  const providedKey = String(req.get('X-App-Internal-Key') ?? '').trim();
  if (!providedKey) {
    res.status(401).json({ error: 'Clave interna requerida.' });
    return;
  }
  if (providedKey !== internalKey) {
    res.status(403).json({ error: 'Clave interna inválida.' });
    return;
  }
  next();
};

const requireContractPdfAccess = (req, res, next) => {
  const requestedId = String(req.params.id ?? '').trim();
  const token = String(req.query?.access_token ?? '').trim();

  if (token && hasValidDocumentAccessToken({
    token,
    kind: 'contract',
    identifier: requestedId,
  })) {
    next();
    return;
  }

  requireInternalKey(req, res, next);
};

const requireQuotePdfAccess = (req, res, next) => {
  const requestedId = String(req.params.id ?? '').trim();
  const token = String(req.query?.access_token ?? '').trim();

  if (token && hasValidDocumentAccessToken({
    token,
    kind: 'quote',
    identifier: requestedId,
  })) {
    next();
    return;
  }

  requireInternalKey(req, res, next);
};

const matchesIdentifier = (entry, requestedId) => [
  entry?.id,
  entry?.contractId,
  entry?.rentalId,
  entry?.contractCode,
  entry?.quoteCode,
  entry?.orderCode,
  entry?.number,
].some((value) => String(value ?? '').trim() === requestedId);

const sanitizeFilePart = (value) =>
  String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9 _-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

const buildContractPdfFileName = (contract, rental) => {
  const customer = sanitizeFilePart(
    contract?.customerName ?? rental?.customerName ?? '',
  ).split(' ').filter(Boolean).slice(0, 2).join(' ');
  const code = sanitizeFilePart(
    contract?.contractCode ?? rental?.contractCode ?? rental?.orderCode ?? 'contrato',
  );
  return [customer, code].filter(Boolean).join(' ').toUpperCase() || 'CONTRATO';
};

const buildQuotePdfFileName = (quote) => {
  const customer = sanitizeFilePart(quote?.customerName ?? '')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .join(' ');
  const code = sanitizeFilePart(quote?.quoteCode ?? 'cotizacion');
  return [customer, code].filter(Boolean).join(' ').toUpperCase() || 'COTIZACION';
};

const normalizeContractPaperSize = (value) => (
  String(value ?? '').trim().toLowerCase() === 'carta' ? 'carta' : 'oficio'
);

const buildInventoryPdfFileName = (rental, contract) => {
  const customer = sanitizeFilePart(
    contract?.customerName ?? rental?.customerName ?? rental?.client ?? '',
  ).split(' ').filter(Boolean).slice(0, 2).join(' ');
  const code = sanitizeFilePart(
    rental?.orderCode ?? contract?.orderCode ?? contract?.contractCode ?? rental?.contractCode ?? 'inventario',
  );
  return [customer, code].filter(Boolean).join(' ').toUpperCase() || 'INVENTARIO';
};

const toDateKey = (value) => {
  if (!value) return '';
  const rawValue = String(value);
  const directMatch = rawValue.match(/\d{4}-\d{2}-\d{2}/);
  if (directMatch) return directMatch[0];
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getWeekRange = (dateKey) => {
  const sourceDate = dateKey ? new Date(`${dateKey}T12:00:00`) : new Date();
  if (Number.isNaN(sourceDate.getTime())) {
    return getWeekRange(toDateKey(new Date()));
  }
  const day = sourceDate.getDay();
  const mondayOffset = day === 0 ? -6 : 1 - day;
  const monday = new Date(sourceDate);
  monday.setDate(sourceDate.getDate() + mondayOffset);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  return {
    weekStart: toDateKey(monday),
    weekEnd: toDateKey(sunday),
  };
};

const isPickupDeliveryRecord = (entry) => {
  const rawType = String(
    entry?.type ?? entry?.kind ?? entry?.direction ?? entry?.operation ?? entry?.status ?? '',
  ).toLowerCase();
  return rawType.includes('pickup')
    || rawType.includes('recojo')
    || rawType.includes('recog')
    || rawType.includes('return')
    || rawType.includes('devol');
};

const resolveContractContext = (state, requestedId) => {
  const contracts = Array.isArray(state?.contracts) ? state.contracts : [];
  const rentals = Array.isArray(state?.rentals) ? state.rentals : [];
  const allDeliveries = Array.isArray(state?.deliveries) ? state.deliveries : [];

  const contract = contracts.find((entry) => matchesIdentifier(entry, requestedId)) ?? null;
  if (!contract) return null;

  const rentalByContractId = contract?.id
    ? rentals.find((entry) =>
      String(entry?.contractId ?? '').trim() === String(contract.id).trim()
    )
    : null;
  const rentalByOrderCode = !rentalByContractId && contract?.orderCode
    ? rentals.find((entry) =>
      String(entry?.orderCode ?? '').trim() === String(contract.orderCode).trim()
    )
    : null;
  const rentalByContractCode = !rentalByContractId && !rentalByOrderCode && contract?.contractCode
    ? rentals.find((entry) =>
      String(entry?.contractCode ?? '').trim() === String(contract.contractCode).trim()
    )
    : null;
  const rental = rentalByContractId ?? rentalByOrderCode ?? rentalByContractCode ?? null;

  const deliveries = allDeliveries
    .filter((entry) =>
      (
        rental?.id
        && String(entry?.rentalId ?? '').trim() === String(rental.id).trim()
      )
      || (
        rental?.orderCode
        && String(entry?.orderCode ?? '').trim() === String(rental.orderCode).trim()
      )
      || (
        contract?.id
        && String(entry?.contractId ?? '').trim() === String(contract.id).trim()
      )
      || (
        contract?.contractCode
        && String(entry?.contractCode ?? '').trim() === String(contract.contractCode).trim()
      )
    )
    .sort((left, right) =>
      new Date(left?.createdAt ?? 0).getTime() - new Date(right?.createdAt ?? 0).getTime()
    );

  return { contract, rental, deliveries };
};

const resolveQuoteContext = (state, requestedId) => {
  const quotes = Array.isArray(state?.quotes) ? state.quotes : [];
  const quote = quotes.find((entry) => !entry?.deletedAt && matchesIdentifier(entry, requestedId))
    ?? quotes.find((entry) => matchesIdentifier(entry, requestedId))
    ?? null;
  return quote ? { quote } : null;
};

const resolveInventoryContext = (state, requestedId) => {
  const contracts = Array.isArray(state?.contracts) ? state.contracts : [];
  const rentals = Array.isArray(state?.rentals) ? state.rentals : [];
  const allDeliveries = Array.isArray(state?.deliveries) ? state.deliveries : [];

  let rental = rentals.find((entry) => matchesIdentifier(entry, requestedId)) ?? null;
  let contract = contracts.find((entry) => matchesIdentifier(entry, requestedId)) ?? null;

  if (!rental && contract) {
    rental = (
      contract?.id
        ? rentals.find((entry) =>
          String(entry?.contractId ?? '').trim() === String(contract.id).trim()
        )
        : null
    ) ?? (
      contract?.orderCode
        ? rentals.find((entry) =>
          String(entry?.orderCode ?? '').trim() === String(contract.orderCode).trim()
        )
        : null
    ) ?? (
      contract?.contractCode
        ? rentals.find((entry) =>
          String(entry?.contractCode ?? '').trim() === String(contract.contractCode).trim()
        )
        : null
    ) ?? null;
  }

  if (rental && !contract) {
    contract = (
      rental?.contractId
        ? contracts.find((entry) =>
          String(entry?.id ?? '').trim() === String(rental.contractId).trim()
        )
        : null
    ) ?? (
      rental?.orderCode
        ? contracts.find((entry) =>
          String(entry?.orderCode ?? '').trim() === String(rental.orderCode).trim()
        )
        : null
    ) ?? (
      rental?.contractCode
        ? contracts.find((entry) =>
          String(entry?.contractCode ?? '').trim() === String(rental.contractCode).trim()
        )
        : null
    ) ?? null;
  }

  const deliveries = allDeliveries
    .filter((entry) =>
      (
        rental?.id
        && String(entry?.rentalId ?? '').trim() === String(rental.id).trim()
      )
      || (
        rental?.orderCode
        && String(entry?.orderCode ?? '').trim() === String(rental.orderCode).trim()
      )
      || (
        contract?.id
        && String(entry?.contractId ?? '').trim() === String(contract.id).trim()
      )
      || (
        contract?.contractCode
        && String(entry?.contractCode ?? '').trim() === String(contract.contractCode).trim()
      )
    )
    .sort((left, right) =>
      new Date(left?.createdAt ?? 0).getTime() - new Date(right?.createdAt ?? 0).getTime()
    );

  return { contract, rental, deliveries };
};

router.post(
  '/__copetin_db/contracts/:id/pdf-access',
  requireInternalKey,
  (req, res) => {
    const requestedId = String(req.params.id ?? '').trim();
    if (!requestedId) {
      res.status(400).json({ error: 'Debes indicar el contrato.' });
      return;
    }

    const paperSize = normalizeContractPaperSize(req.query?.paper ?? req.body?.paper);
    const token = createDocumentAccessToken({
      kind: 'contract',
      identifier: requestedId,
    });
    const encodedId = encodeURIComponent(requestedId);
    const encodedToken = encodeURIComponent(token);
    const encodedPaperSize = encodeURIComponent(paperSize);

    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      paperSize,
      url: `/__copetin_db/contracts/${encodedId}/pdf?paper=${encodedPaperSize}&access_token=${encodedToken}`,
      expiresInMs: DOCUMENT_ACCESS_TOKEN_TTL_MS,
    });
  },
);

router.get(
  '/__copetin_db/contracts/:id/pdf',
  requireContractPdfAccess,
  async (req, res, next) => {
    const startedAt = Date.now();
    try {
      const requestedId = String(req.params.id ?? '').trim();
      const paperSize = normalizeContractPaperSize(req.query?.paper);
      if (!requestedId) {
        res.status(400).json({ error: 'Debes indicar el contrato.' });
        return;
      }

      const snapshot = await getStateSnapshot();
      const context = resolveContractContext(snapshot?.state, requestedId);
      if (!context?.contract) {
        res.status(404).json({ error: 'Contrato no encontrado.' });
        return;
      }

      if (context.contract?._summaryOnly) {
        res.status(409).json({
          error: 'El servidor no dispone del contrato completo para generar el PDF.',
        });
        return;
      }

      const rawHtml = buildContractDocumentHtml({
        contract: context.contract,
        cashMovements: snapshot?.state?.cashMovements ?? [],
        rental: context.rental ?? {},
        deliveries: context.deliveries,
        settings: snapshot?.state?.settings ?? {},
        items: Array.isArray(snapshot?.state?.items) ? snapshot.state.items : [],
        paperSize,
      });
      const html = await embedContractAssets(rawHtml);

      const result = await renderHtmlDocumentToPdf({
        html,
        baseUrl: `${req.protocol}://${req.get('host')}`,
        fileName: buildContractPdfFileName(context.contract, context.rental),
      });

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `inline; filename="${result.fileName}"`);
      res.setHeader('Content-Length', String(result.buffer.length));
      res.setHeader('Cache-Control', 'private, max-age=0, must-revalidate');
      res.setHeader('X-Document-Cache', result.cacheHit ? 'HIT' : 'MISS');
      res.setHeader('X-Document-Key', result.cacheKey);
      res.setHeader('X-Document-Duration-Ms', String(Date.now() - startedAt));
      res.setHeader('X-Contract-Paper-Size', paperSize);
      res.send(result.buffer);
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  '/__copetin_db/quotes/:id/pdf-access',
  requireInternalKey,
  (req, res) => {
    const requestedId = String(req.params.id ?? '').trim();
    if (!requestedId) {
      res.status(400).json({ error: 'Debes indicar la cotizacion.' });
      return;
    }

    const paperSize = normalizeContractPaperSize(req.query?.paper ?? req.body?.paper);
    const token = createDocumentAccessToken({
      kind: 'quote',
      identifier: requestedId,
    });
    const encodedId = encodeURIComponent(requestedId);
    const encodedToken = encodeURIComponent(token);
    const encodedPaperSize = encodeURIComponent(paperSize);

    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      paperSize,
      url: `/__copetin_db/quotes/${encodedId}/pdf?paper=${encodedPaperSize}&access_token=${encodedToken}`,
      expiresInMs: DOCUMENT_ACCESS_TOKEN_TTL_MS,
    });
  },
);

router.get(
  '/__copetin_db/quotes/:id/pdf',
  requireQuotePdfAccess,
  async (req, res, next) => {
    const startedAt = Date.now();
    try {
      const requestedId = String(req.params.id ?? '').trim();
      const paperSize = normalizeContractPaperSize(req.query?.paper);
      if (!requestedId) {
        res.status(400).json({ error: 'Debes indicar la cotizacion.' });
        return;
      }

      const snapshot = await getStateSnapshot();
      const context = resolveQuoteContext(snapshot?.state, requestedId);
      if (!context?.quote) {
        res.status(404).json({ error: 'Cotizacion no encontrada.' });
        return;
      }

      const quote = context.quote;
      const rawHtml = buildContractDocumentHtml({
        contract: quote,
        rental: quote,
        deliveries: [],
        settings: snapshot?.state?.settings ?? {},
        items: Array.isArray(snapshot?.state?.items) ? snapshot.state.items : [],
        paperSize,
        documentKind: 'quote',
      });
      const html = await embedContractAssets(rawHtml);

      const result = await renderHtmlDocumentToPdf({
        html,
        baseUrl: `${req.protocol}://${req.get('host')}`,
        fileName: buildQuotePdfFileName(quote),
      });

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `inline; filename="${result.fileName}"`);
      res.setHeader('Content-Length', String(result.buffer.length));
      res.setHeader('Cache-Control', 'private, max-age=0, must-revalidate');
      res.setHeader('X-Document-Cache', result.cacheHit ? 'HIT' : 'MISS');
      res.setHeader('X-Document-Key', result.cacheKey);
      res.setHeader('X-Document-Duration-Ms', String(Date.now() - startedAt));
      res.setHeader('X-Quote-Paper-Size', paperSize);
      res.send(result.buffer);
    } catch (error) {
      next(error);
    }
  },
);

router.get(['/api/public/quotes/:id/pdf', '/__copetin_db/public/quotes/:id/pdf'], async (req, res, next) => {
  const startedAt = Date.now();
  try {
    const requestedId = String(req.params.id ?? '').trim();
    const token = String(req.query?.token ?? '').trim();
    if (!requestedId) {
      res.status(400).json({ error: 'Debes indicar la cotizacion.' });
      return;
    }

    const snapshot = await getStateSnapshot();
    const context = resolveQuoteContext(snapshot?.state, requestedId);
    if (!context?.quote) {
      res.status(404).json({ error: 'Cotizacion no encontrada.' });
      return;
    }
    if (!hasValidPublicQuoteAccess(context.quote, token)) {
      res.status(403).json({ error: 'El enlace de descarga no es valido.' });
      return;
    }

    const quote = context.quote;
    const paperSize = 'carta';
    const rawHtml = buildContractDocumentHtml({
      contract: quote,
      rental: quote,
      deliveries: [],
      settings: snapshot?.state?.settings ?? {},
      items: Array.isArray(snapshot?.state?.items) ? snapshot.state.items : [],
      paperSize,
      documentKind: 'quote',
    });
    const html = await embedContractAssets(rawHtml);
    const result = await renderHtmlDocumentToPdf({
      html,
      baseUrl: `${req.protocol}://${req.get('host')}`,
      fileName: buildQuotePdfFileName(quote),
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${result.fileName}"`);
    res.setHeader('Content-Length', String(result.buffer.length));
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('X-Document-Duration-Ms', String(Date.now() - startedAt));
    res.send(result.buffer);
  } catch (error) {
    next(error);
  }
});

router.get(
  '/__copetin_db/inventory-orders/:id/pdf',
  requireInternalKey,
  async (req, res, next) => {
    const startedAt = Date.now();
    try {
      const requestedId = String(req.params.id ?? '').trim();
      if (!requestedId) {
        res.status(400).json({ error: 'Debes indicar la orden de inventario.' });
        return;
      }

      const snapshot = await getStateSnapshot();
      const state = snapshot?.state ?? {};
      const context = resolveInventoryContext(state, requestedId);
      if (!context?.rental) {
        res.status(404).json({ error: 'Orden de inventario no encontrada.' });
        return;
      }

      if (context.rental?._summaryOnly || context.contract?._summaryOnly) {
        res.status(409).json({
          error: 'El servidor no dispone de la orden completa para generar el PDF.',
        });
        return;
      }

      const deliveryOut = context.deliveries.find((entry) => !isPickupDeliveryRecord(entry))
        ?? context.deliveries[0]
        ?? null;
      const baseDate = toDateKey(
        context.contract?.deliveryDate
        ?? deliveryOut?.scheduledDate
        ?? context.rental?.rentalDate
        ?? context.rental?.createdAt,
      );
      const { weekStart, weekEnd } = getWeekRange(baseDate);

      const buildStartedAt = Date.now();
      const rawHtml = buildWeeklyInventoryHtml({
        rentals: [context.rental],
        contracts: context.contract ? [context.contract] : [],
        deliveries: context.deliveries,
        settings: state?.settings ?? {},
        items: Array.isArray(state?.items) ? state.items : [],
        weekStart,
        weekEnd,
        format: 'individual',
        targetRentalId: context.rental?.id ?? '',
        targetOrderCode: context.rental?.orderCode ?? context.contract?.orderCode ?? '',
        targetContractCode: context.contract?.contractCode ?? context.rental?.contractCode ?? '',
      });
      const buildDurationMs = Date.now() - buildStartedAt;

      const assetStartedAt = Date.now();
      const html = await embedInventoryAssets(rawHtml);
      const assetDurationMs = Date.now() - assetStartedAt;

      console.info('[inventory-pdf] Documento preparado.', {
        orderCode: context.rental?.orderCode ?? context.contract?.orderCode ?? '',
        rentalId: context.rental?.id ?? '',
        rawHtmlBytes: Buffer.byteLength(rawHtml, 'utf8'),
        htmlBytes: Buffer.byteLength(html, 'utf8'),
        rentalItems: Array.isArray(context.rental?.items) ? context.rental.items.length : 0,
        rssMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
      });

      const renderStartedAt = Date.now();
      const result = await renderHtmlDocumentToPdf({
        html,
        baseUrl: `${req.protocol}://${req.get('host')}`,
        fileName: buildInventoryPdfFileName(context.rental, context.contract),
        imageOptimization: {
          selector: '.wi-product img',
          maxWidth: 180,
          maxHeight: 180,
          quality: 0.72,
          mimeType: 'image/jpeg',
        },
      });
      const renderDurationMs = Date.now() - renderStartedAt;

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `inline; filename="${result.fileName}"`);
      res.setHeader('Content-Length', String(result.buffer.length));
      res.setHeader('Cache-Control', 'private, max-age=0, must-revalidate');
      res.setHeader('X-Document-Cache', result.cacheHit ? 'HIT' : 'MISS');
      res.setHeader('X-Document-Key', result.cacheKey);
      res.setHeader('X-Document-Duration-Ms', String(Date.now() - startedAt));
      res.setHeader(
        'Server-Timing',
        `inventory-build;dur=${buildDurationMs}, inventory-assets;dur=${assetDurationMs}, inventory-pdf;dur=${renderDurationMs}`,
      );
      if (result.imageOptimizationStats) {
        res.setHeader(
          'X-Document-Optimized-Images',
          String(result.imageOptimizationStats.optimizedCount ?? 0),
        );
      }
      res.send(result.buffer);
    } catch (error) {
      next(error);
    }
  },
);

// Compatibility endpoint for other document types that still send HTML.
router.post('/__copetin_db/documents/render-pdf', requireInternalKey, async (req, res, next) => {
  try {
    const html = String(req.body?.html ?? '');
    if (!html.trim()) {
      res.status(400).json({ error: 'Debes enviar el contenido del documento.' });
      return;
    }

    if (Buffer.byteLength(html, 'utf8') > maxDocumentHtmlBytes) {
      res.status(413).json({ error: 'El documento supera el tamaño máximo permitido.' });
      return;
    }

    const result = await renderHtmlDocumentToPdf({
      html,
      baseUrl: req.body?.baseUrl,
      fileName: req.body?.fileName,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${result.fileName}"`);
    res.setHeader('Content-Length', String(result.buffer.length));
    res.setHeader('Cache-Control', 'private, max-age=0, must-revalidate');
    res.setHeader('X-Document-Cache', result.cacheHit ? 'HIT' : 'MISS');
    res.setHeader('X-Document-Key', result.cacheKey);
    res.send(result.buffer);
  } catch (error) {
    next(error);
  }
});

export default router;
