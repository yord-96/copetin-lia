import { Router } from 'express';
import { updateStateSnapshot } from '../storage/fileStateStore.js';
import { getWebBridge } from '../../src/services/webBridge.js';

const router = Router();
const internalKey = String(process.env.APP_INTERNAL_KEY ?? '').trim();

const requireInternalKey = (req, res, next) => {
  if (!internalKey) {
    next();
    return;
  }
  const providedKey = String(req.get('X-App-Internal-Key') ?? '').trim();
  if (!providedKey) {
    res.status(401).json({ error: 'Clave interna requerida.' });
    return;
  }
  if (providedKey !== internalKey) {
    res.status(403).json({ error: 'Clave interna invalida.' });
    return;
  }
  next();
};

const toMoney = (value) => {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Number(number.toFixed(2))) : 0;
};

const normalizeApprovalItems = (items) => (Array.isArray(items) ? items : []).map((line) => ({
  ...line,
  itemId: line?.itemId ?? null,
  lineKey: line?.lineKey ?? null,
  quantity: line?.quantity,
  unitPriceBs: line?.unitPriceBs,
  rentalPriceBs: line?.rentalPriceBs,
  grossLineTotalBs: line?.grossLineTotalBs,
  discountPercent: line?.discountPercent ?? 0,
  discountBs: line?.discountBs ?? 0,
  lineTotalBs: line?.lineTotalBs,
  controlsStock: line?.controlsStock,
  verificationStatus: line?.verificationStatus,
  supplierBackedQty: line?.supplierBackedQty ?? 0,
  internalReservedQty: line?.internalReservedQty ?? null,
  lineType: line?.lineType ?? '',
  observation: line?.observation ?? '',
  quickItem: line?.quickItem ?? null,
  comboId: line?.comboId ?? null,
  comboName: line?.comboName ?? '',
  comboLineKey: line?.comboLineKey ?? null,
  comboComponentName: line?.comboComponentName ?? '',
  comboQuantity: line?.comboQuantity ?? 1,
  comboComponentQuantity: line?.comboComponentQuantity ?? 1,
  comboPricingRole: line?.comboPricingRole ?? '',
  comboPricingCondition: line?.comboPricingCondition ?? null,
  comboRuleIndex: line?.comboRuleIndex ?? 0,
  comboSlotLabel: line?.comboSlotLabel ?? '',
  comboSelectionMode: line?.comboSelectionMode ?? 'item',
  comboOptionItemIds: Array.isArray(line?.comboOptionItemIds) ? line.comboOptionItemIds : [],
  comboCategory: line?.comboCategory ?? '',
  serviceDayId: line?.serviceDayId ?? line?.scheduleDayId ?? null,
  serviceDate: line?.serviceDate ?? line?.date ?? null,
  serviceDayLabel: line?.serviceDayLabel ?? line?.dayLabel ?? '',
}));

const normalizeApprovalServices = (services) => (Array.isArray(services) ? services : []).map((service) => ({
  ...service,
  serviceDayId: service?.serviceDayId ?? service?.scheduleDayId ?? null,
  serviceDate: service?.serviceDate ?? service?.date ?? null,
  serviceDayLabel: service?.serviceDayLabel ?? service?.dayLabel ?? '',
}));

router.post(['/__copetin_db/contracts/create-and-approve', '/__copetin_db/contracts/:id/approve'], requireInternalKey, async (req, res, next) => {
  const startedAt = Date.now();
  const timings = {};
  let lastMarkAt = startedAt;
  const mark = (name) => {
    const now = Date.now();
    timings[name] = now - lastMarkAt;
    lastMarkAt = now;
  };
  const logProfile = (status, extra = {}) => {
    const totalMs = Date.now() - startedAt;
    console.info('[contract-transaction] perfil', { status, totalMs, ...timings, ...extra });
    return totalMs;
  };
  try {
    const existingId = String(req.params.id ?? '').trim();
    const contractPayload = req.body?.contract;
    if (!existingId && (!contractPayload || typeof contractPayload !== 'object' || Array.isArray(contractPayload))) {
      res.status(400).json({ error: 'Debes enviar el contrato completo.' });
      return;
    }
    if (contractPayload?._summaryOnly) {
      res.status(409).json({ error: 'No se puede aprobar un contrato resumido.' });
      return;
    }
    if (!existingId && !contractPayload.items?.length && !contractPayload.services?.length) {
      res.status(400).json({ error: 'El contrato debe incluir sus items completos.' });
      return;
    }

    const trace = req.body?.trace && typeof req.body.trace === 'object' ? req.body.trace : {};
    const expectedRevision = req.body?.revision;
    let responseBundle = null;
    mark('validation');

    const result = await updateStateSnapshot(async (state) => {
      mark('queueAndSnapshot');
      const bridge = getWebBridge();
      await bridge.__storage.beginBatch(state);
      mark('beginBatch');

      try {
      const existingContract = existingId ? (state.contracts ?? []).find((entry) => entry.id === existingId) : null;
      if (existingId && (!existingContract || existingContract.deletedAt || ['anulado', 'rechazado'].includes(existingContract.status))) {
        throw new Error('El contrato no existe o no admite aprobacion.');
      }
      const existingRental = existingContract && (state.rentals ?? []).find((entry) => (
        !entry.deletedAt && entry.status !== 'cancelled'
        && (entry.contractId === existingId || entry.id === existingContract.rentalId)
      ));
      if (existingContract?.status === 'aprobado' && existingRental) {
        responseBundle = { contract: existingContract, rental: existingRental, changes: {
          contracts: [existingContract], rentals: [existingRental],
        } };
        return await bridge.__storage.commitBatch();
      }
      const repairingApproval = existingContract?.status === 'aprobado';
      const createdContract = existingContract ?? await bridge.contracts.create({
        ...trace,
        ...contractPayload,
      });
      mark('contractCreate');
      if (!createdContract || createdContract._summaryOnly) {
        throw new Error('No se pudo crear el contrato completo.');
      }

      const historicalReconstruction = Boolean(
        createdContract?.historicalReconstruction
          ?? contractPayload?.historicalReconstruction,
      );
      const approvalItems = normalizeApprovalItems(createdContract.items);
      const approvalServices = normalizeApprovalServices(createdContract.services);
      const totalBs = toMoney(createdContract?.totals?.totalBs);
      const paidAtApprovalBs = toMoney(createdContract?.payment?.paidAtApprovalBs);
      const rawGuaranteeStatus = String(
        createdContract?.guarantee?.status
          ?? createdContract?.payment?.guaranteeStatus
          ?? '',
      ).trim();
      const isGuaranteeValidated = rawGuaranteeStatus === 'validado'
        || (!rawGuaranteeStatus && toMoney(createdContract?.totals?.guaranteeBs) > 0);
      const guaranteeForCashBs = isGuaranteeValidated
        ? toMoney(createdContract?.totals?.guaranteeBs)
        : 0;

      const currentState = await bridge.__storage.exportState();
      const localClient = (currentState.clients ?? []).find((entry) => entry.id === createdContract.clientId)
        ?? (currentState.clients ?? []).find((entry) => (
          String(entry?.name ?? '').trim().toLowerCase()
          === String(createdContract.customerName ?? '').trim().toLowerCase()
        ));
      mark('exportAfterContract');
      const availablePrepaidBs = localClient?.prepaidEnabled
        ? toMoney(localClient.prepaidBalanceBs)
        : 0;
      const requestedPrepaidAppliedBs = toMoney(
        createdContract?.payment?.prepaidAppliedBs ?? createdContract?.prepaidAppliedBs,
      );
      const prepaidRoomBs = Math.max(0, totalBs - paidAtApprovalBs);
      const prepaidAppliedBs = repairingApproval
        ? Math.min(requestedPrepaidAppliedBs, prepaidRoomBs)
        : Math.min(requestedPrepaidAppliedBs, availablePrepaidBs, prepaidRoomBs);
      const coveredAtApprovalBs = toMoney(paidAtApprovalBs + prepaidAppliedBs);
      const paymentMode = coveredAtApprovalBs >= totalBs && totalBs > 0
        ? 'cancelado'
        : coveredAtApprovalBs > 0
          ? 'a_cuenta'
          : 'sin_pago';
      const responsible = Array.isArray(createdContract.responsibles)
        ? createdContract.responsibles.find((entry) => String(entry?.name ?? '').trim())
        : null;
      const legacyCombinedPickupCoordinate = createdContract.pickupDateMode === undefined
        && createdContract.pickupTimeMode === 'coordinate';
      const pickupDateCoordinatesPending = createdContract.pickupDateMode === 'coordinate'
        || legacyCombinedPickupCoordinate;
      const pickupTimeCoordinatesPending = createdContract.pickupTimeMode === 'coordinate';

      const createdRental = await bridge.rentals.create({
        ...trace,
        createdBy: responsible?.name ?? createdContract.createdBy ?? createdContract.createdByName ?? trace.createdBy,
        createdById: responsible?.id ?? createdContract.createdById ?? trace.createdById,
        createdByName: responsible?.name ?? createdContract.createdByName ?? trace.createdByName,
        createdByRole: responsible?.role ?? createdContract.createdByRole ?? trace.createdByRole,
        clientId: createdContract.clientId ?? null,
        customerName: createdContract.customerName,
        customerPhone: createdContract.customerPhone,
        contractDate: createdContract.contractDate ?? createdContract.createdAt,
        rentalDate: createdContract.deliveryDate || createdContract.eventDate,
        dueDate: pickupDateCoordinatesPending
          ? (createdContract.eventDate || createdContract.deliveryDate)
          : createdContract.pickupDate || createdContract.deliveryDate || createdContract.eventDate,
        dueTime: pickupTimeCoordinatesPending ? '23:59' : createdContract.pickupWindowEnd || createdContract.eventTime || '23:59',
        deliveryWindowStart: createdContract.deliveryWindowStart || '00:00',
        deliveryWindowEnd: createdContract.deliveryWindowEnd || createdContract.eventTime || null,
        pickupWindowStart: pickupTimeCoordinatesPending ? null : createdContract.pickupWindowStart || null,
        pickupWindowEnd: pickupTimeCoordinatesPending ? null : createdContract.pickupWindowEnd || createdContract.eventTime || '23:59',
        pickupDateMode: pickupDateCoordinatesPending ? 'coordinate' : 'fixed',
        pickupTimeMode: pickupTimeCoordinatesPending ? 'coordinate' : 'fixed',
        depositBs: guaranteeForCashBs,
        guaranteeDeclaredBs: toMoney(createdContract?.totals?.guaranteeBs),
        guaranteeStatus: isGuaranteeValidated ? 'validado' : 'no_validado',
        guaranteePaymentMethod: createdContract?.guarantee?.paymentMethod
          ?? createdContract?.payment?.guaranteePaymentMethod
          ?? 'efectivo',
        guaranteePaymentAccount: createdContract?.guarantee?.paymentAccount
          ?? createdContract?.payment?.guaranteePaymentAccount
          ?? '',
        paidAtRentalBs: coveredAtApprovalBs,
        initialPaymentMethod: createdContract?.payment?.initialPaymentMethod ?? 'efectivo',
        initialPaymentAccount: createdContract?.payment?.initialPaymentAccount ?? '',
        paymentMode,
        prepaidClientId: prepaidAppliedBs > 0 ? localClient?.id : null,
        prepaidAppliedBs,
        notes: createdContract.observations,
        billingMode: createdContract.billingMode ?? 'sin_factura',
        logisticsMode: createdContract.logisticsMode ?? 'envio',
        deliveryChargeMode: createdContract.deliveryChargeMode
          ?? (toMoney(createdContract?.totals?.deliveryFeeBs) > 0 ? 'extra' : 'included'),
        deliveryFeeBs: toMoney(createdContract?.totals?.deliveryFeeBs ?? createdContract?.deliveryFeeBs),
        deliveryFeeReason: createdContract.deliveryFeeReason
          ?? (toMoney(createdContract?.totals?.deliveryFeeBs) > 0 ? 'quantity' : 'covered'),
        pricingPlan: createdContract.pricingPlan ?? null,
        historicalReconstruction,
        supplierFulfillmentPlan: historicalReconstruction
          ? []
          : Array.isArray(createdContract.supplierFulfillmentPlan)
            ? createdContract.supplierFulfillmentPlan
            : [],
        quotedTotals: createdContract.totals ?? null,
        eventType: createdContract.eventType,
        eventAddress: createdContract.address,
        contractId: createdContract.id,
        contractCode: createdContract.contractCode,
        allowPastDueDate: true,
        items: approvalItems,
        services: approvalServices,
      }, {
        registerInitialCash: !repairingApproval,
        registerPrepaidUsage: !repairingApproval,
      });

      mark('rentalCreate');
      const approvedAt = createdContract.approvedAt
        ?? createdRental.createdAt
        ?? new Date().toISOString();
      const updatedContract = await bridge.contracts.update({
        ...trace,
        id: createdContract.id,
        status: 'aprobado',
        approvedAt,
        rejectedAt: null,
        rentalId: createdRental.id,
        orderCode: createdRental.orderCode,
        paidAtApprovalBs: coveredAtApprovalBs,
        prepaidAppliedBs,
        pricingPlan: createdContract.pricingPlan ?? null,
        items: approvalItems,
        services: approvalServices,
        historicalReconstruction,
        supplierFulfillmentPlan: historicalReconstruction
          ? []
          : Array.isArray(createdContract.supplierFulfillmentPlan)
            ? createdContract.supplierFulfillmentPlan
            : [],
      });

      mark('contractApprove');

      if (createdContract.quoteId) {
        const linkedQuote = (currentState.quotes ?? []).find((entry) => entry.id === createdContract.quoteId);
        if (linkedQuote) {
          await bridge.quotes.update({
            id: linkedQuote.id,
            status: 'aprobada',
            approvedAt,
            rejectedAt: null,
            rentalId: createdRental.id,
            orderCode: createdRental.orderCode,
          });
        }
      }

      mark('quoteUpdate');

      if (!historicalReconstruction && (createdContract.logisticsMode ?? 'envio') !== 'recojo') {
        const stateAfterRental = await bridge.__storage.exportState();
        const linkedDeliveries = (stateAfterRental.deliveries ?? []).filter(
          (entry) => entry.rentalId === createdRental.id,
        );
        const outbound = linkedDeliveries[0] ?? null;
        if (outbound) {
          await bridge.transport.updateDelivery({
            id: outbound.id,
            scheduledDate: createdContract.deliveryDate || createdContract.eventDate,
            windowStart: createdContract.deliveryWindowStart || outbound.windowStart,
            windowEnd: createdContract.deliveryWindowEnd || outbound.windowEnd,
            address: createdContract.address || outbound.address,
            city: createdContract.city || outbound.city,
            driverId: createdContract.driverId || outbound.driverId,
            vehicleId: createdContract.vehicleId || outbound.vehicleId,
            notes: `Entrega de ${createdRental.orderCode}. ${createdContract.observations ?? ''}`.trim(),
          });
        }
        if (!pickupDateCoordinatesPending && !pickupTimeCoordinatesPending && linkedDeliveries.length < 2) {
          await bridge.transport.createDelivery({
            rentalId: createdRental.id,
            orderCode: createdRental.orderCode,
            customerName: createdContract.customerName,
            companyName: createdContract.companyName || createdContract.customerName,
            address: createdContract.address || 'Direccion pendiente',
            city: createdContract.city || 'Ciudad',
            scheduledDate: createdContract.pickupDate || createdContract.deliveryDate || createdContract.eventDate,
            windowStart: createdContract.pickupWindowStart || '20:00',
            windowEnd: createdContract.pickupWindowEnd || '22:00',
            driverId: createdContract.driverId || null,
            vehicleId: createdContract.vehicleId || null,
            notes: `Recojo programado de ${createdRental.orderCode}`,
          });
        }
      }

      mark('transport');

      const supplierPlan = historicalReconstruction
        ? []
        : Array.isArray(createdContract.supplierFulfillmentPlan)
          ? createdContract.supplierFulfillmentPlan
          : [];
      const groupedBySupplier = new Map();
      supplierPlan.forEach((line) => {
        const supplierId = String(line?.supplierId ?? '').trim();
        const supplierName = String(line?.supplierName ?? '').trim();
        const itemName = String(line?.itemName ?? '').trim();
        const itemId = String(line?.itemId ?? '').trim();
        const neededQty = Math.max(0, Math.trunc(Number(line?.neededQty ?? 0)));
        const supplierUnitCostBs = toMoney(line?.supplierUnitCostBs);
        if (!supplierId || !supplierName || !itemName || neededQty <= 0) return;
        if (!groupedBySupplier.has(supplierId)) {
          groupedBySupplier.set(supplierId, { supplierId, items: [] });
        }
        groupedBySupplier.get(supplierId).items.push({
          itemId: itemId || null,
          itemName,
          category: String(line?.category ?? '').trim(),
          quantity: neededQty,
          unitPriceBs: supplierUnitCostBs,
        });
      });
      for (const entry of groupedBySupplier.values()) {
        if (!entry.items.length) continue;
        await bridge.suppliers.createLoan({
          supplierId: entry.supplierId,
          direction: 'from_supplier',
          flowType: 'paid',
          requestDate: createdContract.deliveryDate || createdContract.eventDate || new Date().toISOString().slice(0, 10),
          returnDate: pickupDateCoordinatesPending ? null : createdContract.pickupDate || null,
          eventName: `Abastecimiento ${createdRental.orderCode}`,
          notes: `Generado automaticamente desde contrato ${createdContract.contractCode}.`,
          sourceContractId: createdContract.id,
          sourceRentalId: createdRental.id,
          sourceOrderCode: createdRental.orderCode,
          autoCreated: true,
          items: entry.items,
        });
      }

      mark('supplierLoans');

      const baseDate = createdRental.rentalDate ?? createdRental.createdAt?.slice(0, 10) ?? null;
      const endDate = createdRental.dueDate ?? baseDate;
      await bridge.reports.generate({
        name: `Contrato ${createdRental.orderCode}`,
        category: 'Documentos',
        periodFrom: baseDate,
        periodTo: endDate,
        format: 'PDF',
        generatedBy: 'Sistema Copetin',
        sourceType: 'contrato',
        sourceId: createdRental.id,
      });
      await bridge.reports.generate({
        name: `Orden Inventario ${createdRental.orderCode}`,
        category: 'Inventario',
        periodFrom: baseDate,
        periodTo: endDate,
        format: 'PDF',
        generatedBy: 'Sistema Copetin',
        sourceType: 'orden_inventario',
        sourceId: createdRental.id,
      });

      mark('reports');

      const finalState = await bridge.__storage.exportState();
      const finalContract = (finalState.contracts ?? []).find((entry) => entry.id === updatedContract.id);
      const finalRental = (finalState.rentals ?? []).find((entry) => entry.id === createdRental.id);
      if (!finalContract || !finalRental || finalContract.rentalId !== finalRental.id) {
        throw new Error('No se pudo confirmar la orden vinculada; la aprobacion fue cancelada.');
      }
      const linkedDeliveries = (finalState.deliveries ?? []).filter((entry) => entry.rentalId === createdRental.id);
      const linkedInventoryMovements = (finalState.inventoryMovements ?? []).filter((entry) => (
        entry.rentalId === createdRental.id
        || entry.orderCode === createdRental.orderCode
        || entry.contractId === createdContract.id
      ));
      const linkedCashMovements = (finalState.cashMovements ?? []).filter((entry) => (
        entry.rentalId === createdRental.id
        || entry.orderCode === createdRental.orderCode
        || entry.contractId === createdContract.id
      ));
      const linkedSupplierLoans = (finalState.supplierLoans ?? []).filter((entry) => (
        entry.sourceRentalId === createdRental.id
        || entry.sourceContractId === createdContract.id
      ));
      const linkedReports = (finalState.generatedReports ?? []).filter((entry) => entry.sourceId === createdRental.id);

      mark('finalExportAndSelect');

      responseBundle = {
        contract: finalContract,
        rental: finalRental,
        changes: {
          contracts: finalContract ? [finalContract] : [],
          rentals: finalRental ? [finalRental] : [],
          deliveries: linkedDeliveries,
          inventoryMovements: linkedInventoryMovements,
          cashMovements: linkedCashMovements,
          supplierLoans: linkedSupplierLoans,
          generatedReports: linkedReports,
          clients: localClient
            ? (finalState.clients ?? []).filter((entry) => entry.id === localClient.id)
            : [],
          quotes: createdContract.quoteId
            ? (finalState.quotes ?? []).filter((entry) => entry.id === createdContract.quoteId)
            : [],
        },
      };
      mark('responseBundle');
      const committedState = await bridge.__storage.commitBatch();
      mark('commitBatch');
      return committedState;
      } catch (error) {
        await bridge.__storage.rollbackBatch();
        throw error;
      }
    }, expectedRevision);

    mark('stateValidationAndWrite');

    if (!result.initialized) {
      res.status(404).json({ error: 'La base de datos aun no esta inicializada.' });
      return;
    }

    mark('beforeResponse');
    const totalMs = logProfile('ok', {
      contractId: responseBundle?.contract?.id ?? null,
      rentalId: responseBundle?.rental?.id ?? null,
    });
    const serverTiming = Object.entries(timings)
      .map(([name, duration]) => `${name};dur=${duration}`)
      .concat(`total;dur=${totalMs}`)
      .join(', ');
    res.set('Server-Timing', serverTiming);
    res.json({
      ok: true,
      ...responseBundle,
      revision: result.revision,
      version: result.version,
      updatedAt: result.updatedAt,
      durationMs: totalMs,
      timings,
    });
  } catch (error) {
    logProfile('error', { code: error?.code, message: error?.message });
    if (error?.code === 'STATE_REVISION_CONFLICT') {
      res.status(409).json({
        error: 'Los datos fueron actualizados por otro usuario. Recarga antes de aprobar.',
        currentRevision: error.currentRevision,
        providedRevision: error.providedRevision,
      });
      return;
    }
    if (error?.status === 409 || error?.code === 'CONTRACT_CODE_CONFLICT') {
      res.status(409).json({
        error: error?.message || 'El numero de contrato ya esta siendo utilizado.',
        code: error?.code || 'CONTRACT_CODE_CONFLICT',
        details: error?.details ?? null,
      });
      return;
    }
    next(error);
  }
});

router.put('/__copetin_db/contracts/:id/update', requireInternalKey, async (req, res, next) => {
  const startedAt = Date.now();
  try {
    const requestedId = String(req.params.id ?? '').trim();
    const contractPayload = req.body?.contract;
    if (!requestedId || !contractPayload || typeof contractPayload !== 'object' || Array.isArray(contractPayload)) {
      res.status(400).json({ error: 'Debes enviar el contrato completo que deseas actualizar.' });
      return;
    }

    let responseBundle = null;
    const result = await updateStateSnapshot(async (state) => {
      const bridge = getWebBridge();
      await bridge.__storage.beginBatch(state);
      try {
        const updatedContract = await bridge.contracts.update({
          ...contractPayload,
          id: requestedId,
        });
        const linkedRental = (state.rentals ?? []).find((entry) => (
          !entry?.deletedAt
          && (
            String(entry.id ?? '') === String(updatedContract.rentalId ?? '')
            || String(entry.contractId ?? '') === String(updatedContract.id ?? '')
            || (updatedContract.orderCode && String(entry.orderCode ?? '') === String(updatedContract.orderCode))
          )
        )) ?? null;
        const itemIds = new Set((updatedContract.items ?? [])
          .map((line) => String(line?.itemId ?? '').trim())
          .filter(Boolean));

        responseBundle = {
          contract: updatedContract,
          rental: linkedRental,
          changes: {
            contracts: [updatedContract],
            rentals: linkedRental ? [linkedRental] : [],
            items: (state.items ?? []).filter((item) => itemIds.has(String(item?.id ?? '').trim())),
          },
        };

        return await bridge.__storage.commitBatch();
      } catch (error) {
        await bridge.__storage.rollbackBatch();
        throw error;
      }
    }, req.body?.revision);

    if (!result.initialized) {
      res.status(404).json({ error: 'La base de datos aun no esta inicializada.' });
      return;
    }

    res.set('Server-Timing', `total;dur=${Date.now() - startedAt}`);
    res.json({
      ok: true,
      ...responseBundle,
      revision: result.revision,
      version: result.version,
      updatedAt: result.updatedAt,
      durationMs: Date.now() - startedAt,
    });
  } catch (error) {
    if (error?.code === 'STATE_REVISION_CONFLICT') {
      res.status(409).json({
        error: 'Los datos fueron actualizados por otro usuario. Vuelve a abrir el contrato antes de guardar.',
        code: error.code,
        currentRevision: error.currentRevision,
        providedRevision: error.providedRevision,
      });
      return;
    }
    if (error?.statusCode || error?.status === 409 || error?.code === 'CONTRACT_CODE_CONFLICT') {
      res.status(Number(error?.statusCode ?? error?.status ?? 409)).json({
        error: error?.message || 'No se pudo actualizar el contrato.',
        code: error?.code || 'CONTRACT_UPDATE_BLOCKED',
        details: error?.details ?? null,
      });
      return;
    }
    next(error);
  }
});

router.post('/__copetin_db/contracts/:id/remove', requireInternalKey, async (req, res, next) => {
  const startedAt = Date.now();
  try {
    const requestedId = String(req.params.id ?? '').trim();
    if (!requestedId) {
      res.status(400).json({ error: 'Debes indicar el contrato que deseas eliminar.' });
      return;
    }

    const trace = req.body?.trace && typeof req.body.trace === 'object' && !Array.isArray(req.body.trace)
      ? req.body.trace
      : {};
    let responseBundle = null;
    const result = await updateStateSnapshot(async (state) => {
      const contractBefore = (state.contracts ?? []).find((entry) => (
        String(entry?.id ?? '').trim() === requestedId && !entry?.deletedAt
      ));
      if (!contractBefore) {
        const error = new Error('Contrato no encontrado o ya eliminado.');
        error.statusCode = 404;
        throw error;
      }
      if (String(contractBefore.status ?? '').trim() !== 'anulado') {
        const error = new Error('Por seguridad, solo se puede eliminar definitivamente de la lista un contrato anulado.');
        error.statusCode = 409;
        error.code = 'CONTRACT_REMOVE_REQUIRES_CANCELLED';
        throw error;
      }

      // Esta operacion nunca debe recalcular ni reemplazar el inventario. La
      // comparacion completa protege cantidad, disponibilidad, precios y fotos.
      const inventoryBefore = JSON.stringify(Array.isArray(state.items) ? state.items : []);
      const inventoryCountBefore = Array.isArray(state.items) ? state.items.length : 0;
      const linkedRentalIds = new Set((state.rentals ?? [])
        .filter((rental) => (
          String(rental?.id ?? '') === String(contractBefore.rentalId ?? '')
          || String(rental?.contractId ?? '') === String(contractBefore.id ?? '')
          || (contractBefore.orderCode && String(rental?.orderCode ?? '') === String(contractBefore.orderCode))
        ))
        .map((rental) => String(rental?.id ?? ''))
        .filter(Boolean));

      const bridge = getWebBridge();
      await bridge.__storage.beginBatch(state);
      try {
        const removedContract = await bridge.contracts.remove({
          ...trace,
          id: requestedId,
        });
        const finalState = await bridge.__storage.exportState();
        const inventoryAfter = JSON.stringify(Array.isArray(finalState.items) ? finalState.items : []);
        if (inventoryAfter !== inventoryBefore) {
          const error = new Error('Eliminacion detenida: la operacion intentaba modificar el inventario. No se guardo ningun cambio.');
          error.statusCode = 409;
          error.code = 'CONTRACT_REMOVE_INVENTORY_MUTATION_BLOCKED';
          throw error;
        }

        const finalContract = (finalState.contracts ?? []).find((entry) => String(entry?.id ?? '') === requestedId);
        if (!finalContract?.deletedAt || String(finalContract.status ?? '') !== 'eliminado') {
          throw new Error('El servidor no pudo confirmar la eliminacion del contrato.');
        }

        const linkedRentals = (finalState.rentals ?? []).filter((rental) => linkedRentalIds.has(String(rental?.id ?? '')));
        const linkedOrderCodes = new Set(linkedRentals.map((rental) => String(rental?.orderCode ?? '')).filter(Boolean));
        responseBundle = {
          contract: removedContract,
          changes: {
            contracts: [finalContract],
            rentals: linkedRentals,
            deliveries: (finalState.deliveries ?? []).filter((delivery) => (
              linkedRentalIds.has(String(delivery?.rentalId ?? ''))
              || linkedOrderCodes.has(String(delivery?.orderCode ?? ''))
            )),
          },
          safety: {
            inventoryRowsBefore: inventoryCountBefore,
            inventoryRowsAfter: Array.isArray(finalState.items) ? finalState.items.length : 0,
            inventoryUnchanged: true,
            removedContractId: requestedId,
            releasedContractCode: String(contractBefore.contractCode ?? '').trim(),
          },
        };
        return await bridge.__storage.commitBatch();
      } catch (error) {
        await bridge.__storage.rollbackBatch();
        throw error;
      }
    }, req.body?.revision);

    if (!result.initialized) {
      res.status(404).json({ error: 'La base de datos aun no esta inicializada.' });
      return;
    }

    res.set('Server-Timing', `total;dur=${Date.now() - startedAt}`);
    res.json({
      ok: true,
      ...responseBundle,
      revision: result.revision,
      version: result.version,
      updatedAt: result.updatedAt,
      durationMs: Date.now() - startedAt,
    });
  } catch (error) {
    if (error?.code === 'STATE_REVISION_CONFLICT') {
      res.status(409).json({
        error: 'Los datos fueron actualizados por otro usuario. Recarga antes de eliminar el contrato.',
        code: error.code,
        currentRevision: error.currentRevision,
        providedRevision: error.providedRevision,
      });
      return;
    }
    if (error?.statusCode || error?.status) {
      res.status(Number(error.statusCode ?? error.status)).json({
        error: error.message || 'No se pudo eliminar el contrato.',
        code: error.code || 'CONTRACT_REMOVE_BLOCKED',
      });
      return;
    }
    next(error);
  }
});

export default router;
