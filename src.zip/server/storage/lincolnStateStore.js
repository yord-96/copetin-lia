import { normalizeOrganizerEvent } from '../services/lincoln/lincolnOrganizerService.js';
import { buildLincolnCashLedger, cashDate, cashMoney } from '../../shared/lincolnCash.js';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { normalizeLincolnReservation } from '../services/lincoln/lincolnReservationService.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..', '..');
const defaultStateFile = path.join(projectRoot, 'data', 'lincoln-state.json');
const stateFilePath = path.resolve(process.env.LINCOLN_STATE_FILE || defaultStateFile);
const copetinStateFilePath = path.resolve(process.env.APP_STATE_FILE || path.join(projectRoot, 'data', 'app-state.json'));
if (stateFilePath === copetinStateFilePath) {
  throw new Error('LINCOLN_STATE_FILE debe ser diferente de APP_STATE_FILE para impedir mezcla de datos.');
}
let writeQueue = Promise.resolve();
let cachedPayload = null;
let cachedSignature = null;

const createEmptyLincolnState = () => ({
  schemaVersion: 6,
  company: {
    id: 'lincoln',
    name: 'Centro de Eventos Lincoln',
    timezone: 'America/La_Paz',
    currency: 'BOB',
  },
  reservations: [],
  leads: [],
  events: [],
  rooms: [],
  packages: [],
  packageServices: [],
  packageExtras: [],
  clients: [],
  meetings: [],
  suppliers: [],
  inventory: [],
  payments: [],
  receipts: [],
  incomeEntries: [],
  expenseEntries: [],
  eventSettlements: [],
  economicLedgerEntries: [],
  cashRenditions: [],
  settings: {
    eventTypes: ['BODA', '15 AÑOS', 'CUMPLEAÑOS', 'EVENTO CORPORATIVO', 'OTRO'],
    paymentDestinations: ['CAJA CHICA', 'SRA. LIA'],
    expenseCategories: ['PERSONAL', 'COMIDA', 'BEBIDAS', 'AGUA', 'BOCADITOS', 'TRANSPORTE', 'AMPLIFICACION', 'TORTA', 'OTROS'],
  },
  auditLog: [],
});

const checksumForState = (state) => crypto
  .createHash('sha256')
  .update(JSON.stringify(state ?? null))
  .digest('hex')
  .slice(0, 16);

const signatureForFile = async () => {
  try {
    const stats = await fs.stat(stateFilePath);
    return `${stats.size}:${stats.mtimeMs}`;
  } catch (error) {
    if (error?.code === 'ENOENT') return null;
    throw error;
  }
};

const writePayload = async (payload) => {
  await fs.mkdir(path.dirname(stateFilePath), { recursive: true });
  const temporaryPath = `${stateFilePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  try {
    const serialized = JSON.stringify(payload, null, 2);
    await fs.writeFile(temporaryPath, serialized, 'utf8');
    if (process.platform === 'win32') {
      await fs.writeFile(stateFilePath, serialized, 'utf8');
    } else {
      await fs.rename(temporaryPath, stateFilePath);
    }
    cachedPayload = payload;
    cachedSignature = await signatureForFile();
  } finally {
    await fs.rm(temporaryPath, { force: true }).catch(() => {});
  }
};

const readPayload = async () => {
  const signature = await signatureForFile();
  if (signature && cachedPayload && cachedSignature === signature) return cachedPayload;
  if (!signature) return null;
  const payload = JSON.parse(await fs.readFile(stateFilePath, 'utf8'));
  cachedPayload = payload;
  cachedSignature = signature;
  return payload;
};


const INITIAL_PACKAGE_DOCUMENTS_MIGRATION = 'packageDocuments20260826';
const SALON_GRANDE_EXTRAS_MIGRATION = 'salonGrandeExtras20260831';

const seedServiceLine = ({ id, category, description, variantIds = [], catalogId = '' }) => ({
  id,
  category,
  sourceType: 'internal',
  description,
  quantity: 1,
  unit: 'SERVICIO',
  costMode: 'fixed_event',
  unitCostBs: 0,
  supplierId: '',
  supplierName: '',
  included: true,
  notes: '',
  variantIds,
  catalogId,
  catalogKind: 'service',
});

const seedExtraLine = ({ id, description, priceBs, costMode = 'per_person', catalogId }) => ({
  id,
  category: 'OTROS',
  sourceType: 'internal',
  description,
  quantity: 1,
  unit: costMode === 'per_person' ? 'PERSONA' : 'EVENTO',
  costMode,
  unitCostBs: priceBs,
  supplierId: '',
  supplierName: '',
  included: false,
  notes: 'Precio referencial tomado del documento comercial entregado por Lincoln.',
  variantIds: [],
  catalogId,
  catalogKind: 'extra',
});

const initialPackageDocumentSeed = (state) => {
  const serviceCatalog = [
    ['SRV-DOC-001', 'CATERING', 'Plato servido: 2 carnes, 3 guarniciones'],
    ['SRV-DOC-002', 'CATERING', 'Bocaditos: 2 rondas'],
    ['SRV-DOC-003', 'CATERING', 'Galleta de champagne (hojaldre con almendras)'],
    ['SRV-DOC-004', 'BEBIDAS', 'Jugos de fruta natural'],
    ['SRV-DOC-005', 'BEBIDAS', 'Cereser para el brindis'],
    ['SRV-DOC-006', 'BEBIDAS', 'Singani: Casa Real negro'],
    ['SRV-DOC-007', 'BEBIDAS', 'Ron: Bacardi añejo'],
    ['SRV-DOC-008', 'BEBIDAS', 'Gaseosas: barra libre'],
    ['SRV-DOC-009', 'BEBIDAS', 'Agua: barra libre'],
    ['SRV-DOC-010', 'BEBIDAS', 'Hielo: barra libre'],
    ['SRV-DOC-011', 'MONTAJE', 'Montaje de mesas con mantelería fina, sillas Tiffany, cristalería, mesa principal para novios, torta, postres y otras mesas especiales'],
    ['SRV-DOC-012', 'SONIDO', 'Amplificación, iluminación y maestro de ceremonia'],
    ['SRV-DOC-013', 'PERSONAL', 'Coordinador de evento, recepcionista, guardia de seguridad, personal de limpieza y garzones'],
    ['SRV-DOC-014', 'SALÓN', 'Alquiler de instalaciones del Salón Grande, gaseado de salón'],
    ['SRV-DOC-015', 'CATERING', 'Bocaditos: 5 rondas – menú amplio a elección'],
    ['SRV-DOC-016', 'MONTAJE', 'Montaje de mesas con mantelería, sillas Tiffany y cristalería básica; mesas especiales de torta y postres'],
    ['SRV-DOC-017', 'PERSONAL', 'Garzones (1 garzón por cada 30 personas)'],
    ['SRV-DOC-018', 'SALÓN', 'Alquiler de instalaciones del Salón Pequeño gaseado'],
    ['SRV-DOC-019', 'CATERING', 'Plato servido: 2 carnes, 3 guarniciones – menú amplio a elección'],
    ['SRV-DOC-020', 'MONTAJE', 'Montaje de mesas con mantelería fina, sillas, cristalería, vajilla, mesa principal de torta, postres, juego de lounge y mesas altas con taburetes'],
    ['SRV-DOC-021', 'PERSONAL', 'Coordinador de evento, recepcionista, guardia de seguridad, garzones (1 garzón por cada 30 personas) y personal de limpieza permanente'],
    ['SRV-DOC-022', 'SALÓN', 'Alquiler de instalaciones del Salón Principal gaseado'],
  ].map(([id, category, description], index) => ({
    id,
    code: `SRV-DOC-${String(index + 1).padStart(3, '0')}`,
    name: description,
    category,
    description,
    sourceType: 'internal',
    costMode: 'fixed_event',
    unit: 'SERVICIO',
    unitCostBs: 0,
    supplierId: '',
    supplierName: '',
    status: 'active',
    notes: 'Servicio inicial cargado una sola vez desde los documentos comerciales de Lincoln.',
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }));

  const extraCatalog = [
    ['EXT-DOC-001', 'Singani: Casa Real negro o Vodka', 7, 'per_person'],
    ['EXT-DOC-002', 'Ron: Bacardi añejo o Fernet', 8.5, 'per_person'],
    ['EXT-DOC-003', 'Ron: Habana 7 años, Solera', 13, 'per_person'],
    ['EXT-DOC-004', 'Whisky: Johnnie Walker o Chivas Regal', 29, 'per_person'],
    ['EXT-DOC-005', 'Whisky: Old Parr', 32, 'per_person'],
    ['EXT-DOC-006', 'Buffet de postres: 3 postres por persona de 5 variedades', 21, 'per_person'],
    ['EXT-DOC-007', 'Buffet de picaditos: variedad de quesos, jamón y otros', 21, 'per_person'],
    ['EXT-DOC-008', 'Torta con maqueta', 15, 'per_person'],
    ['EXT-DOC-009', 'Saladitos (papa frita, maní)', 5, 'per_person'],
    ['EXT-DOC-010', 'Cócteles (margarita, martini, mojitos, daiquiri, kalua entre otros) con o sin alcohol', 24, 'per_person'],
    ['EXT-DOC-011', 'Vino tinto o blanco (Campos de Solana, Kohlberg fino)', 4, 'per_person'],
    ['EXT-DOC-012', 'Vino tinto o blanco (Rosé, Duo, Terruño, Cabernet)', 7, 'per_person'],
    ['EXT-DOC-013', 'Servicio de amplificación, iluminación, DJ y maestro de ceremonias', 1200, 'fixed_event'],
    ['EXT-DOC-014', 'Servicio de amplificación, iluminación con juego de luces, DJ y maestro de ceremonias para 15 años', 3000, 'fixed_event'],
  ].map(([id, description, unitCostBs, costMode], index) => ({
    id,
    code: `EXT-DOC-${String(index + 1).padStart(3, '0')}`,
    name: description,
    category: 'OTROS',
    description,
    sourceType: 'internal',
    costMode,
    unit: costMode === 'per_person' ? 'PERSONA' : 'EVENTO',
    unitCostBs,
    supplierId: '',
    supplierName: '',
    status: 'active',
    notes: 'Precio referencial inicial cargado una sola vez desde los documentos comerciales de Lincoln.',
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }));

  const roomByName = (terms) => (state.rooms ?? []).find((room) => {
    const name = String(room?.name ?? '').toUpperCase();
    return terms.some((term) => name.includes(term));
  }) ?? null;
  const largeRoom = roomByName(['GRANDE', 'PRINCIPAL']);
  const smallRoom = roomByName(['PEQUEÑO', 'PEQUENO']);

  const grandeVariants = [
    { id: 'VAR-GRANDE-COBRE', name: 'COBRE', pricePerPersonBs: 120, minimumGuests: 120, status: 'active' },
    { id: 'VAR-GRANDE-PLATA', name: 'PLATA', pricePerPersonBs: 145, minimumGuests: 120, status: 'active' },
    { id: 'VAR-GRANDE-ORO', name: 'ORO', pricePerPersonBs: 210, minimumGuests: 120, status: 'active' },
    { id: 'VAR-GRANDE-PLATINO', name: 'PLATINO', pricePerPersonBs: 245, minimumGuests: 120, status: 'active' },
  ];
  const smallVariants = [
    { id: 'VAR-PEQ-BASICO', name: 'BÁSICO', pricePerPersonBs: 70, minimumGuests: 50, status: 'active' },
    { id: 'VAR-PEQ-PLATA', name: 'PLATA', pricePerPersonBs: 80, minimumGuests: 50, status: 'active' },
    { id: 'VAR-PEQ-PLATINO', name: 'PLATINO', pricePerPersonBs: 145, minimumGuests: 50, status: 'active' },
    { id: 'VAR-PEQ-ORO', name: 'ORO', pricePerPersonBs: 160, minimumGuests: 50, status: 'active' },
  ];
  const quinceVariants = [
    { id: 'VAR-15-BASICO', name: 'BÁSICO', pricePerPersonBs: 120, minimumGuests: 120, status: 'active' },
    { id: 'VAR-15-JOVENES', name: 'JÓVENES', pricePerPersonBs: 180, minimumGuests: 120, status: 'active' },
    { id: 'VAR-15-ADULTOS', name: 'ADULTOS', pricePerPersonBs: 190, minimumGuests: 120, status: 'active' },
  ];

  const packages = [
    {
      id: 'PKG-DOC-SALON-GRANDE', code: 'PAQ-DOC-001', name: 'SALÓN GRANDE', familyName: 'SALÓN GRANDE',
      roomId: largeRoom?.id ?? '', roomName: largeRoom?.name ?? 'SALÓN GRANDE', segment: 'EVENTOS',
      eventTypes: ['BODA', '15 AÑOS', 'CUMPLEAÑOS', 'EVENTO CORPORATIVO', 'OTRO'], minimumGuests: 120,
      pricePerPersonBs: 120, status: 'active', description: 'Paquetes Cobre, Plata, Oro y Platino del Salón Grande según documento comercial entregado por Lincoln.', images: [], variants: grandeVariants,
      serviceLines: [
        seedServiceLine({ id: 'L-GR-001', category: 'CATERING', description: 'Plato servido: 2 carnes, 3 guarniciones', variantIds: ['VAR-GRANDE-ORO','VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-001' }),
        seedServiceLine({ id: 'L-GR-002', category: 'CATERING', description: 'Bocaditos: 2 rondas', variantIds: ['VAR-GRANDE-ORO','VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-002' }),
        seedServiceLine({ id: 'L-GR-003', category: 'CATERING', description: 'Galleta de champagne (hojaldre con almendras)', variantIds: ['VAR-GRANDE-PLATA','VAR-GRANDE-ORO','VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-003' }),
        seedServiceLine({ id: 'L-GR-004', category: 'BEBIDAS', description: 'Jugos de fruta natural', variantIds: ['VAR-GRANDE-PLATA','VAR-GRANDE-ORO','VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-004' }),
        seedServiceLine({ id: 'L-GR-005', category: 'BEBIDAS', description: 'Cereser para el brindis', variantIds: ['VAR-GRANDE-PLATA','VAR-GRANDE-ORO','VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-005' }),
        seedServiceLine({ id: 'L-GR-006', category: 'BEBIDAS', description: 'Singani: Casa Real negro', variantIds: ['VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-006' }),
        seedServiceLine({ id: 'L-GR-007', category: 'BEBIDAS', description: 'Ron: Bacardi añejo', variantIds: ['VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-007' }),
        seedServiceLine({ id: 'L-GR-008', category: 'BEBIDAS', description: 'Gaseosas: barra libre', variantIds: ['VAR-GRANDE-PLATA','VAR-GRANDE-ORO','VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-008' }),
        seedServiceLine({ id: 'L-GR-009', category: 'BEBIDAS', description: 'Agua: barra libre', variantIds: ['VAR-GRANDE-PLATA','VAR-GRANDE-ORO','VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-009' }),
        seedServiceLine({ id: 'L-GR-010', category: 'BEBIDAS', description: 'Hielo: barra libre', variantIds: ['VAR-GRANDE-PLATA','VAR-GRANDE-ORO','VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-010' }),
        seedServiceLine({ id: 'L-GR-011', category: 'MONTAJE', description: 'Montaje de mesas con mantelería fina, sillas Tiffany, cristalería, mesa principal para novios, torta, postres y otras mesas especiales', variantIds: [], catalogId: 'SRV-DOC-011' }),
        seedServiceLine({ id: 'L-GR-012', category: 'SONIDO', description: 'Amplificación, iluminación y maestro de ceremonia', variantIds: ['VAR-GRANDE-PLATINO'], catalogId: 'SRV-DOC-012' }),
        seedServiceLine({ id: 'L-GR-013', category: 'PERSONAL', description: 'Coordinador de evento, recepcionista, guardia de seguridad, personal de limpieza y garzones', variantIds: [], catalogId: 'SRV-DOC-013' }),
        seedServiceLine({ id: 'L-GR-014', category: 'SALÓN', description: 'Alquiler de instalaciones del Salón Grande, gaseado de salón', variantIds: [], catalogId: 'SRV-DOC-014' }),
        ...extraCatalog.map((item, index) => seedExtraLine({ id: `L-GR-EXT-${index + 1}`, description: item.description, priceBs: item.unitCostBs, costMode: item.costMode, catalogId: item.id })),
      ],
      servicesText: '', sourceDocument: 'PAQUETES SALÓN GRANDE', createdAt: nowIso(), updatedAt: nowIso(),
    },
    {
      id: 'PKG-DOC-SALON-PEQUENO', code: 'PAQ-DOC-002', name: 'SALÓN PEQUEÑO 2024', familyName: 'SALÓN PEQUEÑO 2024',
      roomId: smallRoom?.id ?? '', roomName: smallRoom?.name ?? 'SALÓN PEQUEÑO', segment: 'EVENTOS',
      eventTypes: ['BODA', '15 AÑOS', 'CUMPLEAÑOS', 'EVENTO CORPORATIVO', 'OTRO'], minimumGuests: 50,
      pricePerPersonBs: 70, status: 'active', description: 'Paquetes Básico, Plata, Platino y Oro del Salón Pequeño según documento comercial 2024.', images: [], variants: smallVariants,
      serviceLines: [
        seedServiceLine({ id: 'L-PEQ-001', category: 'CATERING', description: 'Plato servido: 2 carnes, 3 guarniciones – menú amplio a elección', variantIds: ['VAR-PEQ-ORO'], catalogId: 'SRV-DOC-019' }),
        seedServiceLine({ id: 'L-PEQ-002', category: 'CATERING', description: 'Bocaditos: 5 rondas – menú amplio a elección', variantIds: ['VAR-PEQ-PLATINO'], catalogId: 'SRV-DOC-015' }),
        seedServiceLine({ id: 'L-PEQ-003', category: 'CATERING', description: 'Galleta de champagne (hojaldre con almendras)', variantIds: ['VAR-PEQ-PLATINO','VAR-PEQ-ORO'], catalogId: 'SRV-DOC-003' }),
        seedServiceLine({ id: 'L-PEQ-004', category: 'BEBIDAS', description: 'Jugos de fruta natural', variantIds: ['VAR-PEQ-PLATINO','VAR-PEQ-ORO'], catalogId: 'SRV-DOC-004' }),
        seedServiceLine({ id: 'L-PEQ-005', category: 'BEBIDAS', description: 'Cereser para el brindis', variantIds: ['VAR-PEQ-PLATINO','VAR-PEQ-ORO'], catalogId: 'SRV-DOC-005' }),
        seedServiceLine({ id: 'L-PEQ-006', category: 'BEBIDAS', description: 'Gaseosas: barra libre', variantIds: ['VAR-PEQ-PLATINO','VAR-PEQ-ORO'], catalogId: 'SRV-DOC-008' }),
        seedServiceLine({ id: 'L-PEQ-007', category: 'BEBIDAS', description: 'Agua: barra libre', variantIds: ['VAR-PEQ-PLATINO','VAR-PEQ-ORO'], catalogId: 'SRV-DOC-009' }),
        seedServiceLine({ id: 'L-PEQ-008', category: 'BEBIDAS', description: 'Hielo: barra libre', variantIds: ['VAR-PEQ-PLATINO','VAR-PEQ-ORO'], catalogId: 'SRV-DOC-010' }),
        seedServiceLine({ id: 'L-PEQ-009', category: 'MONTAJE', description: 'Montaje de mesas con mantelería, sillas Tiffany y cristalería básica; mesas especiales de torta y postres', variantIds: [], catalogId: 'SRV-DOC-016' }),
        seedServiceLine({ id: 'L-PEQ-010', category: 'PERSONAL', description: 'Garzones (1 garzón por cada 30 personas)', variantIds: ['VAR-PEQ-PLATA','VAR-PEQ-PLATINO','VAR-PEQ-ORO'], catalogId: 'SRV-DOC-017' }),
        seedServiceLine({ id: 'L-PEQ-011', category: 'SALÓN', description: 'Alquiler de instalaciones del Salón Pequeño gaseado', variantIds: [], catalogId: 'SRV-DOC-018' }),
        ...extraCatalog.filter((item) => item.id !== 'EXT-DOC-014').map((item, index) => seedExtraLine({ id: `L-PEQ-EXT-${index + 1}`, description: item.description, priceBs: item.unitCostBs, costMode: item.costMode, catalogId: item.id })),
      ], servicesText: '', sourceDocument: 'PAQUETES SALÓN PEQUEÑO 2024', createdAt: nowIso(), updatedAt: nowIso(),
    },
    {
      id: 'PKG-DOC-15-ANOS', code: 'PAQ-DOC-003', name: 'PAQUETE 15 AÑOS', familyName: 'PAQUETE 15 AÑOS',
      roomId: largeRoom?.id ?? '', roomName: largeRoom?.name ?? 'SALÓN PRINCIPAL', segment: '15 AÑOS',
      eventTypes: ['15 AÑOS'], minimumGuests: 120, pricePerPersonBs: 120, status: 'active',
      description: 'Paquete 15 Años con niveles Básico, Jóvenes y Adultos según documento comercial entregado por Lincoln.', images: [], variants: quinceVariants,
      serviceLines: [
        seedServiceLine({ id: 'L-15-001', category: 'CATERING', description: 'Plato servido: 2 carnes, 3 guarniciones – menú amplio a elección', variantIds: ['VAR-15-ADULTOS'], catalogId: 'SRV-DOC-019' }),
        seedServiceLine({ id: 'L-15-002', category: 'CATERING', description: 'Bocaditos: 5 rondas – menú amplio a elección', variantIds: ['VAR-15-JOVENES'], catalogId: 'SRV-DOC-015' }),
        seedServiceLine({ id: 'L-15-003', category: 'CATERING', description: 'Galleta de champagne (hojaldre con almendras)', variantIds: ['VAR-15-JOVENES','VAR-15-ADULTOS'], catalogId: 'SRV-DOC-003' }),
        seedServiceLine({ id: 'L-15-004', category: 'BEBIDAS', description: 'Jugos de fruta natural', variantIds: ['VAR-15-JOVENES','VAR-15-ADULTOS'], catalogId: 'SRV-DOC-004' }),
        seedServiceLine({ id: 'L-15-005', category: 'BEBIDAS', description: 'Cereser para el brindis', variantIds: ['VAR-15-JOVENES','VAR-15-ADULTOS'], catalogId: 'SRV-DOC-005' }),
        seedServiceLine({ id: 'L-15-006', category: 'BEBIDAS', description: 'Gaseosas: barra libre', variantIds: ['VAR-15-JOVENES','VAR-15-ADULTOS'], catalogId: 'SRV-DOC-008' }),
        seedServiceLine({ id: 'L-15-007', category: 'BEBIDAS', description: 'Agua: barra libre', variantIds: ['VAR-15-JOVENES','VAR-15-ADULTOS'], catalogId: 'SRV-DOC-009' }),
        seedServiceLine({ id: 'L-15-008', category: 'BEBIDAS', description: 'Hielo: barra libre', variantIds: ['VAR-15-JOVENES','VAR-15-ADULTOS'], catalogId: 'SRV-DOC-010' }),
        seedServiceLine({ id: 'L-15-009', category: 'MONTAJE', description: 'Montaje de mesas con mantelería fina, sillas, cristalería, vajilla, mesa principal de torta, postres, juego de lounge y mesas altas con taburetes', variantIds: [], catalogId: 'SRV-DOC-020' }),
        seedServiceLine({ id: 'L-15-010', category: 'PERSONAL', description: 'Coordinador de evento, recepcionista, guardia de seguridad, garzones (1 garzón por cada 30 personas) y personal de limpieza permanente', variantIds: [], catalogId: 'SRV-DOC-021' }),
        seedServiceLine({ id: 'L-15-011', category: 'SALÓN', description: 'Alquiler de instalaciones del Salón Principal gaseado', variantIds: [], catalogId: 'SRV-DOC-022' }),
        ...extraCatalog.filter((item) => item.id !== 'EXT-DOC-013').map((item, index) => seedExtraLine({ id: `L-15-EXT-${index + 1}`, description: item.description, priceBs: item.unitCostBs, costMode: item.costMode, catalogId: item.id })),
      ], servicesText: '', sourceDocument: 'PAQUETE 15 AÑOS', createdAt: nowIso(), updatedAt: nowIso(),
    },
  ];

  return { packages, serviceCatalog, extraCatalog };
};

const applyInitialPackageDocumentSeed = (state) => {
  const settings = state.settings && typeof state.settings === 'object' && !Array.isArray(state.settings) ? state.settings : {};
  const migrations = settings.dataMigrations && typeof settings.dataMigrations === 'object' && !Array.isArray(settings.dataMigrations)
    ? settings.dataMigrations
    : {};
  if (migrations[INITIAL_PACKAGE_DOCUMENTS_MIGRATION]) return { state, changed: false };

  const { packages, serviceCatalog, extraCatalog } = initialPackageDocumentSeed(state);
  const packageIds = new Set((state.packages ?? []).map((row) => row?.id));
  const serviceIds = new Set((state.packageServices ?? []).map((row) => row?.id));
  const extraIds = new Set((state.packageExtras ?? []).map((row) => row?.id));
  state.packages = [...(state.packages ?? []), ...packages.filter((row) => !packageIds.has(row.id))];
  state.packageServices = [...(state.packageServices ?? []), ...serviceCatalog.filter((row) => !serviceIds.has(row.id))];
  state.packageExtras = [...(state.packageExtras ?? []), ...extraCatalog.filter((row) => !extraIds.has(row.id))];
  state.settings = {
    ...settings,
    dataMigrations: {
      ...migrations,
      [INITIAL_PACKAGE_DOCUMENTS_MIGRATION]: {
        appliedAt: nowIso(),
        source: 'Documentos comerciales Lincoln entregados por el usuario',
        packagesAdded: packages.length,
      },
    },
  };
  state.schemaVersion = Math.max(6, Number(state.schemaVersion ?? 1));
  return { state, changed: true };
};

const applySalonGrandeExtrasMigration = (state) => {
  const settings = state.settings && typeof state.settings === 'object' && !Array.isArray(state.settings) ? state.settings : {};
  const migrations = settings.dataMigrations && typeof settings.dataMigrations === 'object' && !Array.isArray(settings.dataMigrations)
    ? settings.dataMigrations
    : {};
  if (migrations[SALON_GRANDE_EXTRAS_MIGRATION]) return { state, changed: false };

  const largePackage = (state.packages ?? []).find((pkg) => (
    String(pkg?.id ?? '') === 'PKG-DOC-SALON-GRANDE'
    || String(pkg?.code ?? '') === 'PAQ-DOC-001'
  ));
  let extrasAdded = 0;
  if (largePackage) {
    const { extraCatalog } = initialPackageDocumentSeed(state);
    const existingLines = Array.isArray(largePackage.serviceLines) ? largePackage.serviceLines : [];
    const existingCatalogIds = new Set(existingLines.map((line) => String(line?.catalogId ?? '')).filter(Boolean));
    const missingExtras = extraCatalog
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => !existingCatalogIds.has(String(item.id)))
      .map(({ item, index }) => seedExtraLine({
        id: `L-GR-EXT-${index + 1}`,
        description: item.description,
        priceBs: item.unitCostBs,
        costMode: item.costMode,
        catalogId: item.id,
      }));
    largePackage.serviceLines = [...existingLines, ...missingExtras];
    largePackage.updatedAt = nowIso();
    extrasAdded = missingExtras.length;
  }
  state.settings = {
    ...settings,
    dataMigrations: {
      ...migrations,
      [SALON_GRANDE_EXTRAS_MIGRATION]: { appliedAt: nowIso(), extrasAdded },
    },
  };
  return { state, changed: true };
};

export const ensureLincolnStateStore = async () => {
  await fs.mkdir(path.dirname(stateFilePath), { recursive: true });
  const signature = await signatureForFile();
  if (!signature) {
    const seeded = applySalonGrandeExtrasMigration(applyInitialPackageDocumentSeed(createEmptyLincolnState()).state).state;
    const updatedAt = new Date().toISOString();
    await writePayload({
      state: seeded,
      version: 1,
      checksum: checksumForState(seeded),
      updatedAt,
    });
    return;
  }

  const payload = await readPayload();
  const normalized = normalizeLincolnStateShape(payload?.state ?? createEmptyLincolnState());
  const initialMigration = applyInitialPackageDocumentSeed(normalized);
  const migration = applySalonGrandeExtrasMigration(initialMigration.state);
  if (!initialMigration.changed && !migration.changed) return;
  const version = Number(payload?.version ?? 1) + 1;
  const checksum = checksumForState(migration.state);
  const updatedAt = new Date().toISOString();
  await writePayload({ state: migration.state, version, checksum, updatedAt });
};

export const getLincolnStateSnapshot = async () => {
  await ensureLincolnStateStore();
  const payload = await readPayload();
  return {
    initialized: Boolean(payload?.state),
    state: normalizeLincolnStateShape(payload?.state ?? createEmptyLincolnState()),
    version: Number(payload?.version ?? 1),
    revision: payload?.state ? `${payload.version ?? 1}:${payload.checksum ?? 'state'}` : null,
    updatedAt: payload?.updatedAt ?? null,
  };
};

export const replaceLincolnStateSnapshot = async (state, expectedRevision) => {
  const operation = writeQueue.then(async () => {
    const current = await getLincolnStateSnapshot();
    if (String(expectedRevision ?? '') !== String(current.revision ?? '')) {
      const error = new Error('La revision de Lincoln no coincide con la version actual.');
      error.statusCode = 409;
      error.code = 'LINCOLN_REVISION_CONFLICT';
      throw error;
    }
    const nextState = normalizeLincolnStateShape(
      state && typeof state === 'object' && !Array.isArray(state)
        ? state
        : createEmptyLincolnState(),
    );
    const version = current.version + 1;
    const checksum = checksumForState(nextState);
    const updatedAt = new Date().toISOString();
    await writePayload({ state: nextState, version, checksum, updatedAt });
    return { ok: true, version, revision: `${version}:${checksum}`, updatedAt };
  });
  writeQueue = operation.catch(() => {});
  return operation;
};


const LINCOLN_MUTABLE_COLLECTIONS = new Set(['clients', 'rooms', 'packages', 'packageServices', 'packageExtras', 'reservations', 'events', 'meetings', 'expenseEntries']);

const normalizeLincolnStateShape = (state) => {
  const base = createEmptyLincolnState();
  const source = state && typeof state === 'object' && !Array.isArray(state) ? state : {};
  const next = {
    ...base,
    ...source,
    company: { ...base.company, ...(source.company ?? {}), id: 'lincoln' },
    settings: { ...base.settings, ...(source.settings ?? {}) },
  };
  ['reservations', 'leads', 'events', 'rooms', 'packages', 'packageServices', 'packageExtras', 'clients', 'meetings', 'suppliers', 'inventory', 'payments', 'receipts', 'incomeEntries', 'expenseEntries', 'eventSettlements', 'economicLedgerEntries', 'cashRenditions', 'auditLog'].forEach((key) => {
    next[key] = Array.isArray(source[key]) ? source[key] : [];
  });
  next.schemaVersion = Math.max(6, Number(source.schemaVersion ?? 1));
  return next;
};

const makeLincolnId = (prefix) => `${prefix}-${crypto.randomUUID()}`;
const nowIso = () => new Date().toISOString();

const nextLincolnCode = (prefix, rows = []) => {
  const year = new Date().getFullYear();
  const regex = new RegExp(`^${prefix}-${year}-(\\d+)$`, 'i');
  const max = rows.reduce((currentMax, row) => {
    const match = String(row?.code ?? '').match(regex);
    return match ? Math.max(currentMax, Number(match[1])) : currentMax;
  }, 0);
  return `${prefix}-${year}-${String(max + 1).padStart(4, '0')}`;
};

const getCollectionPrefix = (collection) => ({
  clients: 'CLI',
  rooms: 'SAL',
  packages: 'PAQ',
  packageServices: 'SRV',
  packageExtras: 'EXT',
  reservations: 'RES',
  events: 'EVE',
  meetings: 'REU',
  expenseEntries: 'EGR',
}[collection] ?? 'LIN');

const appendLincolnAudit = (state, entry) => {
  state.auditLog = [{ id: makeLincolnId('AUD'), createdAt: nowIso(), ...entry }, ...(Array.isArray(state.auditLog) ? state.auditLog : [])].slice(0, 5000);
};

const normalizeClientText = (value) => String(value ?? '').trim();
const normalizeClientKey = (value) => normalizeClientText(value).toLowerCase().replace(/\s+/g, ' ');
const normalizeClientPhone = (value) => normalizeClientText(value).replace(/\D/g, '');

const ensureReservationClient = (state, person, actor, sourceCode = '') => {
  const name = normalizeClientText(person?.name);
  if (!name) return null;
  const ci = normalizeClientText(person?.ci);
  const phone = normalizeClientText(person?.phone);
  const normalizedCi = normalizeClientKey(ci);
  const normalizedPhone = normalizeClientPhone(phone);
  const normalizedName = normalizeClientKey(name);
  const existing = state.clients.find((client) => {
    const clientCi = normalizeClientKey(client?.ci);
    const clientPhone = normalizeClientPhone(client?.phone);
    const clientName = normalizeClientKey(client?.name);
    if (normalizedCi && clientCi) return normalizedCi === clientCi;
    if (normalizedPhone && clientPhone) return normalizedPhone === clientPhone;
    return normalizedName && clientName === normalizedName;
  });
  if (existing) {
    let changed = false;
    if (!normalizeClientText(existing.ci) && ci) { existing.ci = ci; changed = true; }
    if (!normalizeClientText(existing.phone) && phone) { existing.phone = phone; changed = true; }
    if (changed) existing.updatedAt = nowIso();
    return existing;
  }
  const createdAt = nowIso();
  const client = {
    id: makeLincolnId('CLI'),
    code: nextLincolnCode('CLI', state.clients),
    name, ci, phone, secondaryPhone: '', email: '', notes: sourceCode ? `Creado automáticamente desde ${sourceCode}.` : 'Creado automáticamente desde Reservas Lincoln.',
    status: 'active', createdAt, updatedAt: createdAt,
    createdById: String(actor?.id ?? '').trim() || null, createdByName: String(actor?.name ?? '').trim() || null,
  };
  state.clients.unshift(client);
  appendLincolnAudit(state, { action: 'clients.auto_create', entityType: 'clients', entityId: client.id, entityCode: client.code, actorId: client.createdById, actorName: client.createdByName, sourceCode });
  return client;
};

const mutateLincolnState = async (expectedRevision, mutator) => {
  const operation = writeQueue.then(async () => {
    const current = await getLincolnStateSnapshot();
    if (String(expectedRevision ?? '') !== String(current.revision ?? '')) {
      const error = new Error('La revision de Lincoln no coincide con la version actual.');
      error.statusCode = 409;
      error.code = 'LINCOLN_REVISION_CONFLICT';
      error.currentRevision = current.revision;
      throw error;
    }
    const state = normalizeLincolnStateShape(current.state);
    const result = await mutator(state);
    const version = current.version + 1;
    const checksum = checksumForState(state);
    const updatedAt = nowIso();
    await writePayload({ state, version, checksum, updatedAt });
    return { ok: true, version, revision: `${version}:${checksum}`, updatedAt, ...result };
  });
  writeQueue = operation.catch(() => {});
  return operation;
};

export const createLincolnRecord = async (collection, payload, expectedRevision, actor = {}) => {
  if (!LINCOLN_MUTABLE_COLLECTIONS.has(collection)) {
    const error = new Error('Coleccion Lincoln no permitida.');
    error.statusCode = 400;
    error.code = 'LINCOLN_COLLECTION_INVALID';
    throw error;
  }
  return mutateLincolnState(expectedRevision, (state) => {
    const rows = state[collection];
    const prefix = getCollectionPrefix(collection);
    const createdAt = nowIso();
    let normalizedPayload = collection === 'reservations'
      ? normalizeLincolnReservation({ ...payload, reservationDate: payload?.reservationDate || createdAt.slice(0, 10) }, state)
      : (payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {});
    if (collection === 'events') normalizedPayload = normalizeOrganizerEvent(normalizedPayload, state);
    if (collection === 'reservations') {
      const primaryClient = ensureReservationClient(state, { name: normalizedPayload.contractor1Name, ci: normalizedPayload.contractor1Ci, phone: normalizedPayload.contractor1Phone }, actor, String(payload?.code ?? '').trim() || 'RESERVA LINCOLN');
      const secondaryClient = ensureReservationClient(state, { name: normalizedPayload.contractor2Name, ci: normalizedPayload.contractor2Ci, phone: normalizedPayload.contractor2Phone }, actor, String(payload?.code ?? '').trim() || 'RESERVA LINCOLN');
      normalizedPayload = { ...normalizedPayload, clientId: primaryClient?.id ?? null, secondClientId: secondaryClient?.id ?? null };
    }
    const record = {
      ...normalizedPayload,
      id: makeLincolnId(prefix),
      code: String(payload?.code ?? '').trim() || nextLincolnCode(prefix, rows),
      createdAt,
      updatedAt: createdAt,
      createdById: String(actor?.id ?? '').trim() || null,
      createdByName: String(actor?.name ?? '').trim() || null,
    };
    rows.unshift(record);
    if (collection === "events") syncContractMoney(state,record,actor);
    appendLincolnAudit(state, { action: `${collection}.create`, entityType: collection, entityId: record.id, entityCode: record.code, actorId: String(actor?.id ?? '').trim() || null, actorName: String(actor?.name ?? '').trim() || null });
    return { record };
  });
};

export const updateLincolnRecord = async (collection, id, payload, expectedRevision, actor = {}) => {
  if (!LINCOLN_MUTABLE_COLLECTIONS.has(collection)) {
    const error = new Error('Coleccion Lincoln no permitida.');
    error.statusCode = 400;
    error.code = 'LINCOLN_COLLECTION_INVALID';
    throw error;
  }
  return mutateLincolnState(expectedRevision, (state) => {
    const rows = state[collection];
    const index = rows.findIndex((row) => String(row?.id ?? '') === String(id ?? ''));
    if (index < 0) {
      const error = new Error('Registro Lincoln no encontrado.');
      error.statusCode = 404;
      error.code = 'LINCOLN_RECORD_NOT_FOUND';
      throw error;
    }
    const current = rows[index];
    const incoming = payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
    let normalizedIncoming = collection === 'reservations'
      ? normalizeLincolnReservation(incoming, state, { existing: current })
      : incoming;
    if (collection === 'events') normalizedIncoming = normalizeOrganizerEvent({ ...current, ...normalizedIncoming }, state, { excludeEventId: current.id, excludeReservationId: current.reservationId });
    if (collection === 'reservations') {
      const primaryClient = ensureReservationClient(state, { name: normalizedIncoming.contractor1Name, ci: normalizedIncoming.contractor1Ci, phone: normalizedIncoming.contractor1Phone }, actor, current.code);
      const secondaryClient = ensureReservationClient(state, { name: normalizedIncoming.contractor2Name, ci: normalizedIncoming.contractor2Ci, phone: normalizedIncoming.contractor2Phone }, actor, current.code);
      normalizedIncoming = { ...normalizedIncoming, clientId: primaryClient?.id ?? null, secondClientId: secondaryClient?.id ?? null };
    }
    const linkedEvent = collection === 'reservations'
      ? state.events.find((event) => String(event?.reservationId ?? '') === String(current.id) || String(event?.id ?? '') === String(current.eventId ?? ''))
      : null;
    const protectedIncoming = linkedEvent
      ? { ...normalizedIncoming, status: 'converted', eventId: linkedEvent.id }
      : normalizedIncoming;
    const record = {
      ...current,
      ...protectedIncoming,
      id: current.id,
      code: current.code,
      createdAt: current.createdAt,
      updatedAt: nowIso(),
      updatedById: String(actor?.id ?? '').trim() || null,
      updatedByName: String(actor?.name ?? '').trim() || null,
    };
    rows[index] = record;
    if (collection === "events") syncContractMoney(state,record,actor);
    appendLincolnAudit(state, { action: `${collection}.update`, entityType: collection, entityId: record.id, entityCode: record.code, actorId: String(actor?.id ?? '').trim() || null, actorName: String(actor?.name ?? '').trim() || null });
    return { record };
  });
};

export const convertLincolnReservationToEvent = async (reservationId, payload, expectedRevision, actor = {}) =>
  mutateLincolnState(expectedRevision, (state) => {
    const reservationIndex = state.reservations.findIndex((row) => String(row?.id ?? '') === String(reservationId ?? ''));
    if (reservationIndex < 0) {
      const error = new Error('Reserva Lincoln no encontrada.');
      error.statusCode = 404;
      error.code = 'LINCOLN_RESERVATION_NOT_FOUND';
      throw error;
    }
    const reservation = state.reservations[reservationIndex];
    const reservationPaymentBs = Number(reservation?.reservationPaymentBs ?? 0);
    const reservationStatus = String(reservation?.status ?? '').trim().toLowerCase();
    if (reservationPaymentBs <= 0 || reservationStatus === 'lead') {
      const error = new Error('La reserva todavía está como interesado. Primero debe concretarse con dinero de reserva antes de generar el contrato.');
      error.statusCode = 400;
      error.code = 'LINCOLN_RESERVATION_NOT_CONFIRMED';
      throw error;
    }
    const existing = state.events.find((row) => String(row?.reservationId ?? '') === String(reservation.id));
    if (existing) {
      const repairedReservation = {
        ...reservation,
        status: 'converted',
        eventId: existing.id,
        updatedAt: nowIso(),
      };
      state.reservations[reservationIndex] = repairedReservation;
      return { record: existing, reservation: repairedReservation, alreadyConverted: true };
    }
    const createdAt = nowIso();
    const contractCode = nextLincolnCode('CON', state.events.map((row) => ({ code: row?.contractCode ?? '' })));
    const event = {
      clientId: reservation.clientId ?? null,
      clientName: reservation.clientName ?? '',
      clientCi: reservation.clientCi ?? '',
      clientPhone: reservation.clientPhone ?? '',
      contractor1Name: reservation.contractor1Name ?? reservation.clientName ?? '',
      contractor1Ci: reservation.contractor1Ci ?? reservation.clientCi ?? '',
      contractor1Phone: reservation.contractor1Phone ?? reservation.clientPhone ?? '',
      contractor2Name: reservation.contractor2Name ?? reservation.secondContractorName ?? '',
      contractor2Ci: reservation.contractor2Ci ?? reservation.secondContractorCi ?? '',
      contractor2Phone: reservation.contractor2Phone ?? reservation.secondContractorPhone ?? '',
      organizerId: reservation.organizerId ?? null,
      organizerName: reservation.organizerName ?? '',
      organizerPhone: reservation.organizerPhone ?? '',
      reservationDate: reservation.reservationDate ?? '',
      eventType: reservation.eventType ?? '',
      eventDate: reservation.eventDate ?? '',
      startTime: reservation.startTime ?? '',
      durationHours: Number(reservation.durationHours ?? 8),
      roomId: reservation.roomId ?? null,
      roomName: reservation.roomName ?? '',
      guestCount: Number(reservation.guestCount ?? 0),
      packageId: reservation.packageId ?? null,
      packageName: reservation.packageName ?? '',
      packageVariantId: reservation.packageVariantId ?? null,
      packageVariantName: reservation.packageVariantName ?? '',
      packageSnapshot: reservation.packageSnapshot && typeof reservation.packageSnapshot === 'object' ? reservation.packageSnapshot : null,
      packageLines: Array.isArray(reservation.packageLines) ? reservation.packageLines : [],
      estimatedTotalBs: Number(reservation.estimatedTotalBs ?? 0),
      reservationPaymentBs: Number(reservation.reservationPaymentBs ?? 0),
      accountPaymentBs: Number(reservation.accountPaymentBs ?? 0),
      guaranteeBs: Number(reservation.guaranteeBs ?? 0),
      notes: reservation.notes ?? '',
      internalCommercialNote: reservation.internalCommercialNote ?? '',
      internalCommercialNotes: Array.isArray(reservation.internalCommercialNotes)
        ? reservation.internalCommercialNotes.map((note) => ({ ...note }))
        : [],
      status: 'contract_pending',
      ...(payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {}),
      contractCode,
      contractDocumentVersion: Math.max(1, Number(payload?.contractDocumentVersion ?? 1)),
      contractedAt: String(payload?.contractedAt ?? '').trim() || createdAt,
      id: makeLincolnId('EVE'),
      code: nextLincolnCode('EVE', state.events),
      reservationId: reservation.id,
      createdAt,
      updatedAt: createdAt,
      createdById: String(actor?.id ?? '').trim() || null,
      createdByName: String(actor?.name ?? '').trim() || null,
    };
    const normalizedEvent = normalizeOrganizerEvent(event, state, { excludeReservationId: reservation.id });
    Object.assign(event, normalizedEvent);
    state.events.unshift(event);
    syncContractMoney(state,event,actor);
    state.reservations[reservationIndex] = { ...reservation, status: 'converted', eventId: event.id, updatedAt: createdAt };
    appendLincolnAudit(state, { action: 'reservations.convert_to_event', entityType: 'events', entityId: event.id, entityCode: event.code, actorId: String(actor?.id ?? '').trim() || null, actorName: String(actor?.name ?? '').trim() || null });
    return { record: event, reservation: state.reservations[reservationIndex] };
  });


const SERVICE_PAYMENT_TYPES = new Set(['advance', 'installment', 'balance']);
const PAYMENT_TYPE_LABELS = {
  deposit: 'PAGO FLEXIBLE',
  advance: 'ANTICIPO',
  installment: 'A CUENTA',
  balance: 'SALDO',
  guarantee: 'GARANTIA',
  replacement: 'REPOSICION',
};

const roundMoney = (value) => {
  const parsed = Number(value ?? 0);
  return Number.isFinite(parsed) ? Number(parsed.toFixed(2)) : 0;
};

const requirePositiveMoney = (value, label = 'monto') => {
  const amount = roundMoney(value);
  if (amount <= 0) {
    const error = new Error(`El ${label} debe ser mayor a cero.`);
    error.statusCode = 400;
    error.code = 'LINCOLN_AMOUNT_INVALID';
    throw error;
  }
  return amount;
};

const findLincolnEvent = (state, eventId) => {
  const event = state.events.find((row) => String(row?.id ?? '') === String(eventId ?? ''));
  if (!event) {
    const error = new Error('Evento Lincoln no encontrado.');
    error.statusCode = 404;
    error.code = 'LINCOLN_EVENT_NOT_FOUND';
    throw error;
  }
  return event;
};

const activeEventPayments = (state, eventId) => state.payments.filter((row) =>
  String(row?.eventId ?? '') === String(eventId ?? '') && !row?.voidedAt,
);

const activeEventEconomicLedger = (state, eventId) => (Array.isArray(state.economicLedgerEntries) ? state.economicLedgerEntries : [])
  .filter((row) => String(row?.eventId ?? '') === String(eventId ?? '') && !row?.voidedAt && !row?.deletedAt);

const getPaymentAllocations = (payment = {}) => {
  const amountBs = roundMoney(payment.amountBs);
  const hasExplicitAllocation = ['serviceAllocationBs', 'guaranteeAllocationBs', 'replacementAllocationBs', 'surplusAllocationBs']
    .some((key) => payment?.[key] !== undefined && payment?.[key] !== null && payment?.[key] !== '');
  if (hasExplicitAllocation) {
    return {
      serviceBs: roundMoney(payment.serviceAllocationBs),
      guaranteeBs: roundMoney(payment.guaranteeAllocationBs),
      replacementBs: roundMoney(payment.replacementAllocationBs),
      surplusBs: roundMoney(payment.surplusAllocationBs),
    };
  }
  if (SERVICE_PAYMENT_TYPES.has(String(payment.type ?? '').toLowerCase())) return { serviceBs: amountBs, guaranteeBs: 0, replacementBs: 0, surplusBs: 0 };
  if (String(payment.type ?? '').toLowerCase() === 'guarantee') return { serviceBs: 0, guaranteeBs: amountBs, replacementBs: 0, surplusBs: 0 };
  if (String(payment.type ?? '').toLowerCase() === 'replacement') return { serviceBs: 0, guaranteeBs: 0, replacementBs: amountBs, surplusBs: 0 };
  return { serviceBs: 0, guaranteeBs: 0, replacementBs: 0, surplusBs: amountBs };
};

const buildEventFinancialSummary = (state, event) => {
  const payments = activeEventPayments(state, event.id);
  const ledger = activeEventEconomicLedger(state, event.id);
  const allocations = payments.map(getPaymentAllocations);
  const servicePaidBs = roundMoney(allocations.reduce((sum, row) => sum + row.serviceBs, 0));
  const guaranteeCollectedBs = roundMoney(allocations.reduce((sum, row) => sum + row.guaranteeBs, 0));
  const guaranteeReturnedBs = roundMoney(sumMoney(payments.filter((row) => row.type === 'guarantee_return'), 'amountBs'));
  const replacementCollectedBs = roundMoney(allocations.reduce((sum, row) => sum + row.replacementBs, 0));
  const replacementChargedBs = roundMoney(ledger.filter((row) => row.type === 'charge').reduce((sum, row) => sum + roundMoney(row.amountBs), 0));
  const guaranteeAppliedBs = roundMoney(ledger.filter((row) => row.type === 'guarantee_apply').reduce((sum, row) => sum + roundMoney(row.amountBs), 0));
  const replacementPendingBs = Math.max(0, roundMoney(replacementChargedBs - replacementCollectedBs - guaranteeAppliedBs));
  const eventTotalBs = roundMoney(event.totalBs ?? event.estimatedTotalBs ?? 0);
  const guaranteeRequiredBs = roundMoney(event.guaranteeBs ?? 0);
  return {
    eventTotalBs,
    servicePaidBs,
    serviceBalanceBs: Math.max(0, roundMoney(eventTotalBs - servicePaidBs)),
    guaranteeRequiredBs,
    guaranteeCollectedBs,
    guaranteePendingBs: Math.max(0, roundMoney(guaranteeRequiredBs - guaranteeCollectedBs)),
    guaranteeReturnedBs,
    guaranteeAppliedBs,
    guaranteeHeldBs: Math.max(0, roundMoney(guaranteeCollectedBs - guaranteeReturnedBs - guaranteeAppliedBs)),
    replacementBs: replacementCollectedBs,
    replacementChargedBs,
    replacementCollectedBs,
    replacementPendingBs,
  };
};

const sumMoney = (rows, key) => rows.reduce((total, row) => total + roundMoney(row?.[key] ?? 0), 0);

const appendIncomeForPayment = (state, payment, actor) => {
  const income = {
    id: makeLincolnId('ING'),
    code: nextLincolnCode('ING', state.incomeEntries),
    paymentId: payment.id,
    receiptId: payment.receiptId ?? null,
    eventId: payment.eventId,
    eventCode: payment.eventCode,
    clientId: payment.clientId ?? null,
    clientName: payment.clientName ?? '',
    date: payment.date,
    category: PAYMENT_TYPE_LABELS[payment.type] ?? String(payment.type ?? 'INGRESO').toUpperCase(),
    description: payment.description,
    method: payment.method,
    destination: payment.destination,
    amountBs: payment.amountBs,
    serviceAllocationBs: roundMoney(payment.serviceAllocationBs),
    guaranteeAllocationBs: roundMoney(payment.guaranteeAllocationBs),
    replacementAllocationBs: roundMoney(payment.replacementAllocationBs),
    surplusAllocationBs: roundMoney(payment.surplusAllocationBs),
    createdAt: payment.createdAt,
    createdById: String(actor?.id ?? '').trim() || null,
    createdByName: String(actor?.name ?? '').trim() || null,
  };
  state.incomeEntries.unshift(income);
  return income;
};

const registerPaymentInState = (state, eventId, payload, actor = {}) => {
    const event = findLincolnEvent(state, eventId);
    const type = String(payload?.type ?? 'deposit').trim().toLowerCase();
    if (!Object.prototype.hasOwnProperty.call(PAYMENT_TYPE_LABELS, type)) {
      const error = new Error('Tipo de pago Lincoln no permitido.');
      error.statusCode = 400;
      error.code = 'LINCOLN_PAYMENT_TYPE_INVALID';
      throw error;
    }
    const amountBs = requirePositiveMoney(payload?.amountBs, 'monto del pago');
    let serviceAllocationBs = roundMoney(payload?.serviceAllocationBs);
    let guaranteeAllocationBs = roundMoney(payload?.guaranteeAllocationBs);
    let replacementAllocationBs = roundMoney(payload?.replacementAllocationBs);
    if (type !== 'deposit') {
      serviceAllocationBs = SERVICE_PAYMENT_TYPES.has(type) ? amountBs : 0;
      guaranteeAllocationBs = type === 'guarantee' ? amountBs : 0;
      replacementAllocationBs = type === 'replacement' ? amountBs : 0;
    }
    const allocatedBs = roundMoney(serviceAllocationBs + guaranteeAllocationBs + replacementAllocationBs);
    if (allocatedBs > amountBs + 0.009) {
      const error = new Error('La distribución del ingreso supera el monto recibido.');
      error.statusCode = 400;
      error.code = 'LINCOLN_PAYMENT_ALLOCATION_INVALID';
      throw error;
    }
    const surplusAllocationBs = roundMoney(Math.max(0, amountBs - allocatedBs));
    const createdAt = nowIso();
    const receipt = {
      id: makeLincolnId('RCL'),
      code: nextLincolnCode('RCL', state.receipts),
      eventId: event.id,
      eventCode: event.code,
      clientId: event.clientId ?? null,
      clientName: event.clientName ?? '',
      date: String(payload?.date ?? '').trim() || createdAt.slice(0, 10),
      type,
      direction: 'income',
      concept: String(payload?.description ?? '').trim() || PAYMENT_TYPE_LABELS[type],
      method: String(payload?.method ?? 'cash').trim().toLowerCase(),
      destination: String(payload?.destination ?? '').trim() || 'CAJA CHICA',
      payerName: String(payload?.payerName ?? event.clientName ?? '').trim(),
      amountBs,
      serviceAllocationBs,
      guaranteeAllocationBs,
      replacementAllocationBs,
      surplusAllocationBs,
      status: 'active',
      createdAt,
      createdById: String(actor?.id ?? '').trim() || null,
      createdByName: String(actor?.name ?? '').trim() || null,
    };
    const payment = {
      id: makeLincolnId('PAG'),
      code: nextLincolnCode('PAG', state.payments),
      receiptId: receipt.id,
      receiptCode: receipt.code,
      eventId: event.id,
      eventCode: event.code,
      clientId: event.clientId ?? null,
      clientName: event.clientName ?? '',
      date: receipt.date,
      type,
      amountBs,
      serviceAllocationBs,
      guaranteeAllocationBs,
      replacementAllocationBs,
      surplusAllocationBs,
      method: receipt.method,
      destination: receipt.destination,
      payerName: receipt.payerName,
      description: receipt.concept,
      reference: String(payload?.reference ?? '').trim(),
      createdAt,
      createdById: String(actor?.id ?? '').trim() || null,
      createdByName: String(actor?.name ?? '').trim() || null,
    };
    state.receipts.unshift(receipt);
    state.payments.unshift(payment);
    const income = appendIncomeForPayment(state, payment, actor);
    state.economicLedgerEntries = Array.isArray(state.economicLedgerEntries) ? state.economicLedgerEntries : [];
    const ledgerEntry = {
      id: makeLincolnId('ECO'),
      code: nextLincolnCode('ECO', state.economicLedgerEntries),
      eventId: event.id,
      eventCode: event.code,
      type: type === 'guarantee' ? 'guarantee' : 'deposit',
      subtype: type,
      amountBs,
      serviceAllocationBs,
      guaranteeAllocationBs,
      replacementAllocationBs,
      surplusAllocationBs,
      method: payment.method,
      destination: payment.destination,
      note: payment.description,
      reference: payment.reference,
      paymentId: payment.id,
      receiptId: receipt.id,
      receiptCode: receipt.code,
      incomeEntryId: income.id,
      isCashRegistered: true,
      createdAt,
      createdById: payment.createdById,
      createdByName: payment.createdByName,
    };
    state.economicLedgerEntries.unshift(ledgerEntry);
    event.updatedAt = createdAt;
    event.financial = buildEventFinancialSummary(state, event);
    appendLincolnAudit(state, {
      action: 'events.payment.create', entityType: 'payments', entityId: payment.id, entityCode: payment.code,
      actorId: String(actor?.id ?? '').trim() || null, actorName: String(actor?.name ?? '').trim() || null,
      eventId: event.id, receiptCode: receipt.code, amountBs,
    });
    return { payment, receipt, income, ledgerEntry, eventFinancial: event.financial };
  };

export const registerLincolnEventPayment = async (eventId, payload, expectedRevision, actor = {}) =>
  mutateLincolnState(expectedRevision, state => registerPaymentInState(state,eventId,payload,actor));

const syncContractAdvance = (state,event,actor) => {
  const advance = roundMoney(event.contractDocumentSnapshot?.advanceBs);
  if (advance <= roundMoney(event.contractAdvanceRecordedBs)) { event.financial = buildEventFinancialSummary(state,event); return; }
  const paid = buildEventFinancialSummary(state,event).servicePaidBs;
  const missing = roundMoney(Math.max(0,advance-paid));
  if (missing > 0) registerPaymentInState(state,event.id,{type:"advance",amountBs:missing,description:"Anticipo registrado en el contrato",date:event.contractDocumentSnapshot?.contractDate?.slice(0,10),method:event.contractDocumentSnapshot?.advanceMethod || "cash",destination:event.contractDocumentSnapshot?.advanceDestination || "CAJA CHICA"},actor);
  event.contractAdvanceRecordedBs = advance;
  event.financial = buildEventFinancialSummary(state,event);
};

const syncContractGuarantee = (state,event,actor) => {
  const snapshot = event.contractDocumentSnapshot && typeof event.contractDocumentSnapshot === 'object' ? event.contractDocumentSnapshot : {};
  const guarantee = roundMoney(snapshot.guaranteeBs ?? event.guaranteeBs);
  const guaranteeStatus = String(snapshot.guaranteeStatus ?? event.guaranteeStatus ?? 'due').trim().toLowerCase() === 'paid' ? 'paid' : 'due';
  event.guaranteeBs = guarantee;
  event.guaranteeStatus = guaranteeStatus;
  if (guaranteeStatus !== 'paid' || guarantee <= 0) {
    event.financial = buildEventFinancialSummary(state,event);
    return;
  }
  const recorded = roundMoney(event.contractGuaranteeRecordedBs);
  if (guarantee <= recorded) {
    event.financial = buildEventFinancialSummary(state,event);
    return;
  }
  const collected = buildEventFinancialSummary(state,event).guaranteeCollectedBs;
  const missing = roundMoney(Math.max(0, guarantee - collected));
  if (missing > 0) registerPaymentInState(state,event.id,{
    type:'guarantee',
    amountBs:missing,
    description:'Garantía pagada al formalizar el contrato',
    date:snapshot.contractDate?.slice(0,10),
    method:snapshot.guaranteeMethod || snapshot.advanceMethod || 'cash',
    destination:snapshot.guaranteeDestination || snapshot.advanceDestination || 'CAJA CHICA',
  },actor);
  event.contractGuaranteeRecordedBs = Math.max(roundMoney(event.contractGuaranteeRecordedBs), guarantee);
  event.financial = buildEventFinancialSummary(state,event);
};

const syncContractMoney = (state,event,actor) => {
  syncContractAdvance(state,event,actor);
  syncContractGuarantee(state,event,actor);
};

const voidPaymentInState = (state,paymentId,payload,actor = {}) => {
    const payment = state.payments.find((row) => String(row?.id ?? '') === String(paymentId ?? ''));
    assertCashRowsUnrendered(state, row => row.paymentId === paymentId);
    if (!payment) {
      const error = new Error('Pago Lincoln no encontrado.');
      error.statusCode = 404;
      error.code = 'LINCOLN_PAYMENT_NOT_FOUND';
      throw error;
    }
    if (payment.voidedAt) return { payment };
    const voidedAt = nowIso();
    const reason = String(payload?.reason ?? '').trim() || 'ANULACION ADMINISTRATIVA';
    payment.voidedAt = voidedAt;
    payment.voidReason = reason;
    payment.voidedById = String(actor?.id ?? '').trim() || null;
    payment.voidedByName = String(actor?.name ?? '').trim() || null;
    const receipt = state.receipts.find((row) => String(row?.id ?? '') === String(payment.receiptId ?? ''));
    if (receipt) {
      receipt.status = 'voided';
      receipt.voidedAt = voidedAt;
      receipt.voidReason = reason;
    }
    const income = [...state.incomeEntries,...state.expenseEntries].find((row) => String(row?.paymentId ?? '') === String(payment.id));
    if (income) {
      income.voidedAt = voidedAt;
      income.voidReason = reason;
    }
    (Array.isArray(state.economicLedgerEntries) ? state.economicLedgerEntries : []).forEach((entry) => {
      if (String(entry?.paymentId ?? '') !== String(payment.id)) return;
      entry.voidedAt = voidedAt;
      entry.voidReason = reason;
      entry.voidedById = String(actor?.id ?? '').trim() || null;
      entry.voidedByName = String(actor?.name ?? '').trim() || null;
    });
    const event = findLincolnEvent(state, payment.eventId);
    event.updatedAt = voidedAt;
    event.financial = buildEventFinancialSummary(state, event);
    appendLincolnAudit(state, {
      action: 'payments.void', entityType: 'payments', entityId: payment.id, entityCode: payment.code,
      actorId: String(actor?.id ?? '').trim() || null, actorName: String(actor?.name ?? '').trim() || null,
      eventId: event.id, reason,
    });
    return { payment, eventFinancial: event.financial };
  };

export const voidLincolnPayment = async (paymentId,payload,expectedRevision,actor = {}) => mutateLincolnState(expectedRevision,state=>voidPaymentInState(state,paymentId,payload,actor));

export const returnLincolnGuarantee = async (eventId, payload, expectedRevision, actor = {}) =>
  mutateLincolnState(expectedRevision, (state) => {
    const event = findLincolnEvent(state, eventId);
    const before = buildEventFinancialSummary(state, event);
    const amountBs = requirePositiveMoney(payload?.amountBs ?? before.guaranteeHeldBs, 'monto de devolución');
    if (amountBs > before.guaranteeHeldBs) {
      const error = new Error('La devolución supera la garantía actualmente retenida.');
      error.statusCode = 400;
      error.code = 'LINCOLN_GUARANTEE_RETURN_EXCEEDS_HELD';
      throw error;
    }
    const createdAt = nowIso();
    const receipt = {
      id: makeLincolnId('RCL'), code: nextLincolnCode('RCL', state.receipts),
      eventId: event.id, eventCode: event.code, clientId: event.clientId ?? null, clientName: event.clientName ?? '',
      date: String(payload?.date ?? '').trim() || createdAt.slice(0, 10), type: 'guarantee_return', direction: 'expense',
      concept: String(payload?.description ?? '').trim() || 'DEVOLUCION DE GARANTIA',
      method: String(payload?.method ?? 'cash').trim().toLowerCase(), destination: String(payload?.destination ?? '').trim() || 'CAJA CHICA',
      payerName: event.clientName ?? '', amountBs, status: 'active', createdAt,
      createdById: String(actor?.id ?? '').trim() || null, createdByName: String(actor?.name ?? '').trim() || null,
    };
    const payment = {
      id: makeLincolnId('PAG'), code: nextLincolnCode('PAG', state.payments), receiptId: receipt.id, receiptCode: receipt.code,
      eventId: event.id, eventCode: event.code, clientId: event.clientId ?? null, clientName: event.clientName ?? '',
      date: receipt.date, type: 'guarantee_return', amountBs, method: receipt.method, destination: receipt.destination,
      payerName: event.clientName ?? '', description: receipt.concept, reference: String(payload?.reference ?? '').trim(), createdAt,
      createdById: receipt.createdById, createdByName: receipt.createdByName,
    };
    const expense = {
      id: makeLincolnId('EGR'), code: nextLincolnCode('EGR', state.expenseEntries), eventId: event.id, eventCode: event.code,
      date: payment.date, category: 'DEVOLUCION GARANTIA', description: payment.description, method: payment.method,
      destination: payment.destination, amountBs, paymentId: payment.id, receiptId: receipt.id, receiptCode: receipt.code,
      createdAt, createdById: payment.createdById, createdByName: payment.createdByName,
    };
    state.receipts.unshift(receipt);
    state.payments.unshift(payment);
    state.expenseEntries.unshift(expense);
    state.economicLedgerEntries = Array.isArray(state.economicLedgerEntries) ? state.economicLedgerEntries : [];
    const ledgerEntry = {
      id: makeLincolnId('ECO'), code: nextLincolnCode('ECO', state.economicLedgerEntries), eventId: event.id, eventCode: event.code,
      type: 'refund', subtype: 'guarantee_return', refundSource: 'guarantee', amountBs, method: payment.method,
      destination: payment.destination, note: payment.description, reference: payment.reference, paymentId: payment.id,
      receiptId: receipt.id, receiptCode: receipt.code, expenseEntryId: expense.id, isCashRegistered: true,
      createdAt, createdById: payment.createdById, createdByName: payment.createdByName,
    };
    state.economicLedgerEntries.unshift(ledgerEntry);
    event.updatedAt = createdAt;
    event.financial = buildEventFinancialSummary(state, event);
    appendLincolnAudit(state, {
      action: 'events.guarantee.return', entityType: 'expenseEntries', entityId: expense.id, entityCode: expense.code,
      actorId: String(actor?.id ?? '').trim() || null, actorName: String(actor?.name ?? '').trim() || null,
      eventId: event.id, amountBs, receiptCode: receipt.code,
    });
    return { payment, receipt, expense, ledgerEntry, eventFinancial: event.financial };
  });

export const registerLincolnEconomicLedgerEntry = async (eventId, payload, expectedRevision, actor = {}) =>
  mutateLincolnState(expectedRevision, (state) => {
    const event = findLincolnEvent(state, eventId);
    const type = String(payload?.type ?? 'note').trim().toLowerCase();
    if (!['charge', 'guarantee_apply', 'note'].includes(type)) {
      const error = new Error('Tipo de movimiento económico Lincoln no permitido.');
      error.statusCode = 400;
      error.code = 'LINCOLN_ECONOMIC_TYPE_INVALID';
      throw error;
    }
    const before = buildEventFinancialSummary(state, event);
    const amountBs = type === 'note' ? 0 : requirePositiveMoney(payload?.amountBs, 'monto del movimiento');
    if (type === 'guarantee_apply') {
      if (amountBs > before.guaranteeHeldBs + 0.009) {
        const error = new Error('La aplicación supera la garantía retenida disponible.');
        error.statusCode = 400;
        error.code = 'LINCOLN_GUARANTEE_APPLY_EXCEEDS_HELD';
        throw error;
      }
      if (amountBs > before.replacementPendingBs + 0.009) {
        const error = new Error('La aplicación supera los cargos/reposiciones pendientes.');
        error.statusCode = 400;
        error.code = 'LINCOLN_GUARANTEE_APPLY_EXCEEDS_CHARGE';
        throw error;
      }
    }
    const createdAt = nowIso();
    state.economicLedgerEntries = Array.isArray(state.economicLedgerEntries) ? state.economicLedgerEntries : [];
    const entry = {
      id: makeLincolnId('ECO'), code: nextLincolnCode('ECO', state.economicLedgerEntries), eventId: event.id, eventCode: event.code,
      type, amountBs, note: String(payload?.note ?? payload?.description ?? '').trim(), reference: String(payload?.reference ?? '').trim(),
      isCashRegistered: false, createdAt, createdById: String(actor?.id ?? '').trim() || null, createdByName: String(actor?.name ?? '').trim() || null,
    };
    state.economicLedgerEntries.unshift(entry);
    event.updatedAt = createdAt;
    event.financial = buildEventFinancialSummary(state, event);
    appendLincolnAudit(state, { action: `events.economic.${type}`, entityType: 'economicLedgerEntries', entityId: entry.id, entityCode: entry.code,
      actorId: entry.createdById, actorName: entry.createdByName, eventId: event.id, amountBs });
    return { ledgerEntry: entry, eventFinancial: event.financial };
  });

const economicMutationError = (message,statusCode=400) => Object.assign(new Error(message),{statusCode,code:'LINCOLN_ECONOMIC_MUTATION_INVALID'});
const checkEconomicConsistency = (state,event) => {
  const financial=buildEventFinancialSummary(state,event);
  if (financial.guaranteeReturnedBs+financial.guaranteeAppliedBs > financial.guaranteeCollectedBs+.009) throw economicMutationError('La garantía recibida no puede ser menor que lo ya devuelto o aplicado.');
  if (financial.guaranteeAppliedBs > 0 && financial.guaranteeAppliedBs > financial.replacementChargedBs-financial.replacementCollectedBs+.009) throw economicMutationError('Los cargos deben cubrir la garantía ya aplicada.');
  event.financial=financial;
};
const findEconomicMovement = (state,id) => {
  const entry=state.economicLedgerEntries.find(row=>row.id===id && !row.voidedAt && !row.deletedAt);
  const paymentId=entry?.paymentId || (String(id).startsWith('legacy-') ? String(id).slice(7) : '');
  const payment=state.payments.find(row=>row.id===paymentId && !row.voidedAt);
  if (!entry && !payment) throw economicMutationError('Movimiento no encontrado.',404);
  return {entry,payment,event:findLincolnEvent(state,entry?.eventId || payment.eventId)};
};

export const updateLincolnEconomicMovement = async (id,payload,revision,actor={}) => mutateLincolnState(revision,state=>{
  const {entry,payment,event}=findEconomicMovement(state,id);
  if (payment) assertCashRowsUnrendered(state, row => row.paymentId === payment.id);
  const before=structuredClone({entry,payment,receipt:state.receipts.find(row=>row.id===payment?.receiptId)});
  const updatedAt=nowIso();
  if (payment) {
    const refund=payment.type==='guarantee_return';
    const type=refund ? 'guarantee_return' : String(payload.type || payment.type);
    if (!refund && !Object.hasOwn(PAYMENT_TYPE_LABELS,type)) throw economicMutationError('Tipo de pago inválido.');
    const amountBs=requirePositiveMoney(payload.amountBs,'monto del recibo');
    const serviceAllocationBs=refund?0:type==='deposit'?roundMoney(payload.serviceAllocationBs):SERVICE_PAYMENT_TYPES.has(type)?amountBs:0;
    const guaranteeAllocationBs=refund?0:type==='deposit'?roundMoney(payload.guaranteeAllocationBs):type==='guarantee'?amountBs:0;
    const replacementAllocationBs=refund?0:type==='deposit'?roundMoney(payload.replacementAllocationBs):type==='replacement'?amountBs:0;
    const allocated=roundMoney(serviceAllocationBs+guaranteeAllocationBs+replacementAllocationBs);
    if (allocated>amountBs+.009) throw economicMutationError('La distribución supera el monto del recibo.');
    const date=String(payload.date || payment.date || '').slice(0,10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(`${date}T12:00:00Z`)) || new Date(`${date}T12:00:00Z`).toISOString().slice(0,10)!==date) throw economicMutationError('Fecha del recibo inválida.');
    const receipt=state.receipts.find(row=>row.id===payment.receiptId);
    if (!receipt) throw economicMutationError('El recibo vinculado no existe.');
    const receiptCode=String(payload.receiptCode || receipt.code).trim();
    if (state.receipts.some(row=>row.id!==receipt.id && row.code===receiptCode)) throw economicMutationError('Ese número de recibo ya existe.');
    const fields={type,amountBs,date,serviceAllocationBs,guaranteeAllocationBs,replacementAllocationBs,surplusAllocationBs:refund?0:roundMoney(amountBs-allocated),method:String(payload.method || payment.method),destination:String(payload.destination ?? payment.destination),payerName:String(payload.payerName ?? payment.payerName),receivedByName:String(payload.receivedByName ?? receipt.receivedByName ?? receipt.createdByName ?? ''),clientName:String(payload.clientName ?? payment.clientName),description:String(payload.description ?? payment.description),reference:String(payload.reference ?? payment.reference),receiptCode,updatedAt,updatedById:actor.id || null,updatedByName:actor.name || null};
    Object.assign(payment,fields);
    Object.assign(receipt,fields,{code:receiptCode,concept:fields.description,direction:refund?'expense':'income'});
    for (const cash of [...state.incomeEntries,...state.expenseEntries].filter(row=>row.paymentId===payment.id)) Object.assign(cash,fields,{category:refund?'DEVOLUCION GARANTIA':PAYMENT_TYPE_LABELS[type]});
    for (const ledger of state.economicLedgerEntries.filter(row=>row.paymentId===payment.id)) Object.assign(ledger,fields,{type:refund?'refund':type==='guarantee'?'guarantee':'deposit',subtype:type,note:fields.description});
  } else {
    const type=String(payload.type || entry.type);
    if (!['charge','note','guarantee_apply'].includes(type)) throw economicMutationError('Tipo de movimiento interno inválido.');
    Object.assign(entry,{type,amountBs:type==='note'?0:requirePositiveMoney(payload.amountBs,'monto'),note:String(payload.note ?? ''),reference:String(payload.reference ?? ''),updatedAt,updatedById:actor.id || null,updatedByName:actor.name || null});
  }
  checkEconomicConsistency(state,event);
  event.updatedAt=updatedAt;
  appendLincolnAudit(state,{action:'events.economic.update',entityType:'economicLedgerEntries',entityId:id,eventId:event.id,actorId:actor.id || null,actorName:actor.name || null,before,after:structuredClone({entry,payment})});
  return {ledgerEntry:entry,payment,eventFinancial:event.financial};
});

export const deleteLincolnEconomicMovement = async (id,payload,revision,actor={}) => mutateLincolnState(revision,state=>{
  const {entry,payment,event}=findEconomicMovement(state,id);
  if (payment) voidPaymentInState(state,payment.id,{reason:payload.reason || 'ELIMINACION DE MOVIMIENTO'},actor);
  else Object.assign(entry,{deletedAt:nowIso(),deletedById:actor.id || null,deleteReason:payload.reason || 'ELIMINACION DE MOVIMIENTO'});
  checkEconomicConsistency(state,event);
  appendLincolnAudit(state,{action:'events.economic.delete',entityType:'economicLedgerEntries',entityId:id,eventId:event.id,actorId:actor.id || null,actorName:actor.name || null});
  return {eventFinancial:event.financial};
});

export const deleteLincolnContract = async (eventId,payload,revision,actor={}) => mutateLincolnState(revision,state=>{
  assertCashRowsUnrendered(state, row => row.eventId === eventId);
  const event=findLincolnEvent(state,eventId);
  const archived=structuredClone(event);
  for (const payment of activeEventPayments(state,eventId)) voidPaymentInState(state,payment.id,{reason:payload.reason || 'CONTRATO ELIMINADO'},actor);
  for (const collection of ['receipts','economicLedgerEntries','incomeEntries','expenseEntries','eventSettlements']) for (const row of state[collection] || []) if (row.eventId===eventId) Object.assign(row,{status:'voided',voidedAt:nowIso(),deletedAt:nowIso(),voidReason:'CONTRATO ELIMINADO'});
  for (const reservation of state.reservations.filter(row=>row.eventId===eventId || row.id===event.reservationId)) Object.assign(reservation,{eventId:null,status:Number(reservation.reservationPaymentBs)>0?'confirmed':'lead',updatedAt:nowIso()});
  state.events=state.events.filter(row=>row.id!==eventId);
  appendLincolnAudit(state,{action:'events.delete',entityType:'events',entityId:eventId,entityCode:event.code,actorId:actor.id || null,actorName:actor.name || null,reason:payload.reason || '',archivedRecord:archived});
  return {deletedId:eventId};
});

export const resetLincolnEventEconomics = async (eventId, payload, expectedRevision, actor = {}) =>
  mutateLincolnState(expectedRevision, (state) => {
    assertCashRowsUnrendered(state, row => row.eventId === eventId);
    const event = findLincolnEvent(state, eventId);
    const role = String(actor?.role ?? '').trim().toLowerCase();
    if (role !== 'developer') {
      const error = new Error('Solo el rol developer puede ejecutar el Reset económico del evento.');
      error.statusCode = 403;
      error.code = 'LINCOLN_ECONOMIC_RESET_FORBIDDEN';
      throw error;
    }
    const confirmation = String(payload?.confirmation ?? '').trim().toUpperCase();
    if (confirmation !== 'RESET ECONOMICO') {
      const error = new Error('Escribe RESET ECONOMICO para confirmar la reconstrucción económica.');
      error.statusCode = 400;
      error.code = 'LINCOLN_ECONOMIC_RESET_CONFIRMATION';
      throw error;
    }
    const eventIdKey = String(event.id);
    const linkedPayments = state.payments.filter((row) => String(row?.eventId ?? '') === eventIdKey);
    const paymentIds = new Set(linkedPayments.map((row) => String(row.id)));
    const receiptIds = new Set(linkedPayments.map((row) => String(row.receiptId ?? '')).filter(Boolean));
    const beforeCounts = {
      payments: linkedPayments.length,
      receipts: state.receipts.filter((row) => String(row?.eventId ?? '') === eventIdKey || receiptIds.has(String(row?.id ?? ''))).length,
      incomeEntries: state.incomeEntries.filter((row) => String(row?.eventId ?? '') === eventIdKey && (paymentIds.has(String(row?.paymentId ?? '')) || row?.paymentId)).length,
      guaranteeReturnExpenses: state.expenseEntries.filter((row) => String(row?.eventId ?? '') === eventIdKey && paymentIds.has(String(row?.paymentId ?? ''))).length,
      ledgerEntries: (state.economicLedgerEntries ?? []).filter((row) => String(row?.eventId ?? '') === eventIdKey).length,
    };
    state.payments = state.payments.filter((row) => String(row?.eventId ?? '') !== eventIdKey);
    state.receipts = state.receipts.filter((row) => String(row?.eventId ?? '') !== eventIdKey && !receiptIds.has(String(row?.id ?? '')));
    state.incomeEntries = state.incomeEntries.filter((row) => !(String(row?.eventId ?? '') === eventIdKey && paymentIds.has(String(row?.paymentId ?? ''))));
    state.expenseEntries = state.expenseEntries.filter((row) => !(String(row?.eventId ?? '') === eventIdKey && paymentIds.has(String(row?.paymentId ?? ''))));
    state.economicLedgerEntries = (state.economicLedgerEntries ?? []).filter((row) => String(row?.eventId ?? '') !== eventIdKey);
    const resetAt = nowIso();
    event.financial = buildEventFinancialSummary(state, event);
    event.economicResetAt = resetAt;
    event.economicResetById = String(actor?.id ?? '').trim() || null;
    event.economicResetByName = String(actor?.name ?? '').trim() || null;
    event.updatedAt = resetAt;
    appendLincolnAudit(state, { action: 'events.economic.reset', entityType: 'events', entityId: event.id, entityCode: event.code,
      actorId: event.economicResetById, actorName: event.economicResetByName, eventId: event.id,
      reason: String(payload?.reason ?? '').trim(), beforeCounts });
    return { eventFinancial: event.financial, resetSummary: beforeCounts, economicResetAt: resetAt };
  });

export const createLincolnExpense = async (payload, expectedRevision, actor = {}) =>
  mutateLincolnState(expectedRevision, (state) => {
    const amountBs = requirePositiveMoney(payload?.amountBs, 'monto del egreso');
    const eventId = String(payload?.eventId ?? '').trim() || null;
    const event = eventId ? findLincolnEvent(state, eventId) : null;
    const createdAt = nowIso();
    const expense = {
      id: makeLincolnId('EGR'),
      code: nextLincolnCode('EGR', state.expenseEntries),
      eventId: event?.id ?? null,
      eventCode: event?.code ?? null,
      date: requireCashDate(payload?.date),
      category: String(payload?.category ?? 'OTROS').trim().toUpperCase() || 'OTROS',
      description: String(payload?.description ?? '').trim(),
      method: String(payload?.method ?? 'cash').trim().toLowerCase(),
      destination: String(payload?.destination ?? '').trim() || 'CAJA CHICA',
      supplierName: String(payload?.supplierName ?? '').trim(),
      reference: String(payload?.reference ?? '').trim(),
      amountBs,
      createdAt,
      createdById: String(actor?.id ?? '').trim() || null,
      createdByName: String(actor?.name ?? '').trim() || null,
    };
    state.expenseEntries.unshift(expense);
    const receipt = appendCashDocument(state, expense, 'expense', actor);
    if (event) event.updatedAt = createdAt;
    appendLincolnAudit(state, {
      action: 'expenses.create', entityType: 'expenseEntries', entityId: expense.id, entityCode: expense.code,
      actorId: String(actor?.id ?? '').trim() || null, actorName: String(actor?.name ?? '').trim() || null,
      eventId: event?.id ?? null, amountBs,
    });
    return { expense, receipt };
  });

export const updateLincolnExpense = async (expenseId, payload, expectedRevision, actor = {}) =>
  mutateLincolnState(expectedRevision, (state) => {
    assertCashRowsUnrendered(state, row => row.id === expenseId);
    const expense = state.expenseEntries.find((row) => String(row?.id ?? '') === String(expenseId ?? ''));
    if (!expense || expense?.voidedAt) {
      const error = new Error('Egreso Lincoln no encontrado o anulado.');
      error.statusCode = 404;
      error.code = 'LINCOLN_EXPENSE_NOT_FOUND';
      throw error;
    }
    const nextEventId = String(payload?.eventId ?? expense.eventId ?? '').trim() || null;
    const event = nextEventId ? findLincolnEvent(state, nextEventId) : null;
    const updatedAt = nowIso();
    Object.assign(expense, {
      eventId: event?.id ?? null,
      eventCode: event?.code ?? null,
      date: requireCashDate(payload?.date ?? expense.date),
      category: String(payload?.category ?? expense.category ?? 'OTROS').trim().toUpperCase() || 'OTROS',
      description: String(payload?.description ?? expense.description ?? '').trim(),
      method: String(payload?.method ?? expense.method ?? 'cash').trim().toLowerCase(),
      destination: String(payload?.destination ?? expense.destination ?? '').trim() || 'CAJA CHICA',
      supplierName: String(payload?.supplierName ?? expense.supplierName ?? '').trim(),
      reference: String(payload?.reference ?? expense.reference ?? '').trim(),
      amountBs: requirePositiveMoney(payload?.amountBs ?? expense.amountBs, 'monto del egreso'),
      updatedAt,
      updatedById: String(actor?.id ?? '').trim() || null,
      updatedByName: String(actor?.name ?? '').trim() || null,
    });
    const receipt = state.receipts.find(row => row.id === expense.receiptId);
    if (receipt) Object.assign(receipt, { date: expense.date, amountBs: expense.amountBs, method: expense.method, destination: expense.destination, clientName: expense.supplierName, payerName: expense.supplierName, concept: expense.description, reference: expense.reference, eventId: expense.eventId, eventCode: expense.eventCode });
    appendLincolnAudit(state, {
      action: 'expenses.update', entityType: 'expenseEntries', entityId: expense.id, entityCode: expense.code,
      actorId: String(actor?.id ?? '').trim() || null, actorName: String(actor?.name ?? '').trim() || null,
      eventId: event?.id ?? null,
    });
    return { expense };
  });


export const setLincolnSettlementStatus = async (eventId, payload, expectedRevision, actor = {}) =>
  mutateLincolnState(expectedRevision, (state) => {
    const event = findLincolnEvent(state, eventId);
    const requestedStatus = String(payload?.status ?? 'closed').trim().toLowerCase();
    if (!['open', 'closed'].includes(requestedStatus)) {
      const error = new Error('Estado de rendición Lincoln no permitido.');
      error.statusCode = 400;
      error.code = 'LINCOLN_SETTLEMENT_STATUS_INVALID';
      throw error;
    }
    const existingIndex = state.eventSettlements.findIndex((row) => String(row?.eventId ?? '') === String(event.id));
    const changedAt = nowIso();
    const current = existingIndex >= 0 ? state.eventSettlements[existingIndex] : null;
    const settlement = {
      ...(current ?? {}),
      id: current?.id ?? makeLincolnId('REN'),
      code: current?.code ?? nextLincolnCode('REN', state.eventSettlements),
      eventId: event.id,
      eventCode: event.code ?? '',
      status: requestedStatus,
      notes: String(payload?.notes ?? current?.notes ?? '').trim(),
      createdAt: current?.createdAt ?? changedAt,
      createdById: current?.createdById ?? (String(actor?.id ?? '').trim() || null),
      createdByName: current?.createdByName ?? (String(actor?.name ?? '').trim() || null),
      updatedAt: changedAt,
      updatedById: String(actor?.id ?? '').trim() || null,
      updatedByName: String(actor?.name ?? '').trim() || null,
      closedAt: requestedStatus === 'closed' ? changedAt : null,
      closedById: requestedStatus === 'closed' ? String(actor?.id ?? '').trim() || null : null,
      closedByName: requestedStatus === 'closed' ? String(actor?.name ?? '').trim() || null : null,
    };
    if (existingIndex >= 0) state.eventSettlements[existingIndex] = settlement;
    else state.eventSettlements.unshift(settlement);
    appendLincolnAudit(state, {
      action: requestedStatus === 'closed' ? 'settlements.close' : 'settlements.reopen',
      entityType: 'eventSettlements',
      entityId: settlement.id,
      entityCode: settlement.code,
      eventId: event.id,
      actorId: String(actor?.id ?? '').trim() || null,
      actorName: String(actor?.name ?? '').trim() || null,
    });
    return { settlement };
  });

function assertCashRowsUnrendered(state, predicate) {
  if ([...state.incomeEntries, ...state.expenseEntries].some(row => predicate(row) && row.cashRenditionId)) {
    throw economicMutationError('Este movimiento ya fue rendido. Su comprobante histórico debe conservarse sin cambios.');
  }
}

const requireCashDate = value => {
  const date = String(value || cashDate());
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(Date.parse(`${date}T12:00:00Z`)) || new Date(`${date}T12:00:00Z`).toISOString().slice(0, 10) !== date) throw economicMutationError('Fecha de caja inválida.');
  return date;
};
const cashText = value => String(value || '').trim();

function appendCashDocument(state, entry, direction, actor) {
  const receipt = {
    id: makeLincolnId('RCL'), code: nextLincolnCode('RCL', state.receipts),
    cashEntryId: entry.id, direction, type: entry.cashOperation || 'expense',
    date: entry.date, amountBs: entry.amountBs, method: entry.method, destination: entry.destination,
    eventId: entry.eventId || null, eventCode: entry.eventCode || '',
    clientName: entry.payerName || entry.supplierName || 'Caja Lincoln', payerName: entry.payerName || entry.supplierName || '',
    concept: entry.description, reference: entry.reference || '', status: 'active',
    createdAt: entry.createdAt, createdById: actor.id || null, createdByName: actor.name || null,
  };
  entry.receiptId = receipt.id;
  entry.receiptCode = receipt.code;
  state.receipts.unshift(receipt);
  return receipt;
}

export const registerLincolnCashFunds = (payload, revision, actor = {}) => mutateLincolnState(revision, state => {
  const amountBs = requirePositiveMoney(payload?.amountBs, 'ingreso de fondos');
  const description = cashText(payload?.description);
  const payerName = cashText(payload?.payerName);
  if (!description || !payerName) throw economicMutationError('Indica el concepto y quién entrega los fondos.');
  const method = cashText(payload?.method) || 'cash';
  if (!['cash', 'qr', 'transfer'].includes(method)) throw economicMutationError('Medio de pago inválido.');
  const entry = {
    id: makeLincolnId('ING'), code: nextLincolnCode('ING', state.incomeEntries),
    cashOperation: 'fund_income', category: 'INGRESO DE FONDOS', eventId: null,
    date: requireCashDate(payload?.date), amountBs, method, destination: cashText(payload?.destination) || 'CAJA CHICA',
    description, payerName, reference: cashText(payload?.reference), createdAt: nowIso(),
    createdById: actor.id || null, createdByName: actor.name || null,
  };
  state.incomeEntries.unshift(entry);
  const receipt = appendCashDocument(state, entry, 'income', actor);
  appendLincolnAudit(state, { action: 'cash.funds.create', entityType: 'incomeEntries', entityId: entry.id, amountBs, actorId: actor.id || null, actorName: actor.name || null });
  return { entry, receipt };
});

export const registerLincolnCashRendition = (payload, revision, actor = {}) => mutateLincolnState(revision, state => {
  const mode = cashText(payload?.mode);
  if (!['accounting', 'delivery'].includes(mode)) throw economicMutationError('Selecciona rendición o entrega de fondos.');
  const date = requireCashDate(payload?.date);
  const recipientName = cashText(payload?.recipientName);
  const destination = cashText(payload?.destination) || 'CAJA CHICA';
  if (!recipientName) throw economicMutationError('Indica quién recibe la rendición o los fondos.');
  const keys = [...new Set(Array.isArray(payload?.movementKeys) ? payload.movementKeys.map(String) : [])];
  const allRows = buildLincolnCashLedger(state).rows;
  const rows = keys.map(key => {
    const row = allRows.find(item => item.key === key);
    if (!row || row.cashRenditionId) throw economicMutationError('Algún movimiento ya fue rendido o dejó de estar disponible. Actualiza la caja.');
    if (row.destination !== destination) throw economicMutationError('Rinde movimientos de una misma caja o destino.');
    if (row.date > date) throw economicMutationError('La fecha de rendición debe ser igual o posterior a los movimientos seleccionados.');
    return row;
  });
  const cashBs = cashMoney(payload?.cashBs), digitalBs = cashMoney(payload?.digitalBs);
  if (cashBs < 0 || digitalBs < 0) throw economicMutationError('Los montos de entrega no pueden ser negativos.');
  if (mode === 'accounting' && !rows.length) throw economicMutationError('Selecciona los movimientos que se rendirán.');
  if (mode === 'accounting' && (cashBs || digitalBs)) throw economicMutationError('La rendición sin entrega no retira dinero de caja.');
  if (mode === 'delivery' && cashBs + digitalBs <= 0) throw economicMutationError('Indica el monto efectivo o digital a entregar.');
  const balance = buildLincolnCashLedger(state, { destination, to: date }).closing;
  if (mode === 'delivery' && (cashBs > Math.max(0, balance.cashBs) || digitalBs > Math.max(0, balance.digitalBs))) throw economicMutationError('La entrega supera el fondo disponible para esa fecha y caja.');
  const rendition = {
    id: makeLincolnId('RCJ'), code: nextLincolnCode('RCJ', state.cashRenditions), mode, date, destination, recipientName,
    notes: cashText(payload?.notes), movementKeys: keys, movements: structuredClone(rows),
    incomeBs: cashMoney(rows.reduce((sum, row) => sum + row.incomeBs, 0)),
    expenseBs: cashMoney(rows.reduce((sum, row) => sum + row.expenseBs, 0)),
    deliveredCashBs: mode === 'delivery' ? cashBs : 0, deliveredDigitalBs: mode === 'delivery' ? digitalBs : 0,
    balanceBefore: balance, balanceAfter: { cashBs: cashMoney(balance.cashBs - cashBs), digitalBs: cashMoney(balance.digitalBs - digitalBs) },
    createdAt: nowIso(), createdById: actor.id || null, createdByName: actor.name || null, receipts: [],
  };
  for (const row of rows) {
    const entry = state[row.direction === 'income' ? 'incomeEntries' : 'expenseEntries'].find(item => item.id === row.id);
    Object.assign(entry, { cashRenditionId: rendition.id, cashRenditionCode: rendition.code, cashRenderedAt: rendition.createdAt });
    const receipt = state.receipts.find(item => item.id === row.receiptId);
    if (receipt) Object.assign(receipt, { cashRenditionId: rendition.id, cashRenditionCode: rendition.code });
  }
  for (const [method, amountBs] of [['cash', cashBs], ['transfer', digitalBs]]) {
    if (mode !== 'delivery' || amountBs <= 0) continue;
    const entry = {
      id: makeLincolnId('EGR'), code: nextLincolnCode('EGR', state.expenseEntries), cashOperation: 'fund_delivery',
      cashRenditionId: rendition.id, cashRenditionCode: rendition.code, cashRenderedAt: rendition.createdAt,
      eventId: null, category: 'ENTREGA DE FONDOS', date, amountBs, method, destination,
      supplierName: recipientName, description: `Entrega de fondos a ${recipientName} · ${rendition.code}`, reference: rendition.notes,
      createdAt: rendition.createdAt, createdById: actor.id || null, createdByName: actor.name || null,
    };
    state.expenseEntries.unshift(entry);
    const receipt = appendCashDocument(state, entry, 'expense', actor);
    Object.assign(receipt, { cashRenditionId: rendition.id, cashRenditionCode: rendition.code });
    rendition.receipts.push(receipt.id);
  }
  state.cashRenditions.unshift(rendition);
  appendLincolnAudit(state, { action: 'cash.rendition.create', entityType: 'cashRenditions', entityId: rendition.id, entityCode: rendition.code, actorId: actor.id || null, actorName: actor.name || null, movementKeys: keys, cashBs, digitalBs });
  return { rendition };
});

export const getLincolnStateStoreInfo = () => ({ storage: 'file', stateFilePath });
