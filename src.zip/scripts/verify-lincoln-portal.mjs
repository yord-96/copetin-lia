// Isolated browser smoke test. Requires npm run build; never reads or edits business data.
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import express from 'express';
import bcrypt from 'bcryptjs';
import puppeteer from 'puppeteer-core';
import { build } from 'vite';
import react from '@vitejs/plugin-react';
import { createRequire } from 'node:module';

const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'lincoln-portal-ui-'));
process.env.APP_STATE_FILE = path.join(temporary, 'app.json');
process.env.LINCOLN_STATE_FILE = path.join(temporary, 'lincoln.json');
process.env.LINCOLN_PORTAL_FILE = path.join(temporary, 'portal.json');
let browser, server;
try {
  await fs.writeFile(process.env.APP_STATE_FILE, JSON.stringify({ state: { users: [{ id: 'staff-demo', username: 'admin', fullName: 'Coordinación Lincoln', role: 'developer', status: 'active', passwordHash: await bcrypt.hash('staff-password', 4) }] }, version: 1 }));
  await fs.writeFile(process.env.LINCOLN_STATE_FILE, JSON.stringify({ state: { events: [{ id: 'demo', code: '0024', clientName: 'Evento de prueba', eventType: 'Boda', roomName: 'Salón Grande', eventDate: '2026-10-24' }] }, version: 1 }));
  await fs.writeFile(process.env.LINCOLN_PORTAL_FILE, JSON.stringify({ accounts: [{ id: 'client-demo', username: 'demo', name: 'Cliente de prueba', eventId: 'demo', credentialVersion: 1, active: true, passwordHash: await bcrypt.hash('demo-password', 4) }], plans: {}, sessions: [] }));
  const { default: routes } = await import('../server/routes/lincolnPortal.js');
  // Mount the actual admin component in an isolated fixture to verify screen transitions.
  const require = createRequire(import.meta.url);
  const modulePath = (file) => JSON.stringify(file.replaceAll('\\', '/'));
  const entry = path.join(temporary, 'admin-entry.mjs');
  await fs.writeFile(entry, `import React from ${modulePath(require.resolve('react'))};
import {createRoot} from ${modulePath(require.resolve('react-dom/client'))};
import Admin from ${modulePath(path.resolve('src/components/lincoln/portal/LincolnEventPortalAdmin.jsx'))};
createRoot(document.getElementById('root')).render(React.createElement(Admin,{currentUser:{id:'staff-demo',username:'admin'},state:{events:[{id:'demo',code:'0024',clientName:'Evento de prueba',eventDate:'2026-10-24'},{id:'other-demo',code:'0025',clientName:'Otro evento',eventDate:'2026-11-01'}]}}));`);
  const fixtureDist = path.join(temporary, 'admin-dist');
  await build({ configFile: false, plugins: [react()], base: '/admin-fixture/', logLevel: 'error', build: { outDir: fixtureDist, emptyOutDir: false, rollupOptions: { input: entry, output: { entryFileNames: 'admin.js', assetFileNames: '[name][extname]' } } } });
  const fixtureCss = (await fs.readdir(fixtureDist)).filter((file) => file.endsWith('.css')).map((file) => `<link rel="stylesheet" href="/admin-fixture/${file}">`).join('');
  const app = express(); app.use(express.json()); app.use(routes);
  app.use('/admin-fixture', express.static(fixtureDist));
  app.get('/__portal-admin-test', (_req, res) => res.send(`<html><head><meta name="viewport" content="width=device-width,initial-scale=1">${fixtureCss}</head><body style="margin:0"><div id="root"></div><script type="module" src="/admin-fixture/admin.js"></script></body></html>`));
  app.use(express.static(path.resolve('dist'))); app.get('/lincoln/mi-evento', (_req, res) => res.sendFile(path.resolve('dist/index.html')));
  server = app.listen(0, '127.0.0.1'); await new Promise((resolve) => server.once('listening', resolve));
  browser = await puppeteer.launch({ executablePath: process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true });
  const page = await browser.newPage(); await page.setViewport({ width: 1440, height: 1000 });
  // A production build can contain VITE_API_URL. Redirect all portal calls to the fixture server.
  await page.evaluateOnNewDocument((origin) => {
    const fetch = window.fetch.bind(window);
    window.fetch = (input, init) => {
      const url = new URL(String(input), window.location.origin);
      return fetch(url.pathname.startsWith('/api/lincoln-portal') || url.pathname.startsWith('/__lincoln_db/portal') ? `${origin}${url.pathname}${url.search}` : input, init);
    };
  }, `http://127.0.0.1:${server.address().port}`);
  const errors = []; page.on('pageerror', (error) => errors.push(error.message));
  const clickText = async (text) => {
    const handles = await page.$$('button');
    for (const handle of handles) { if (await handle.evaluate((node, label) => node.textContent.trim() === label || node.querySelector('span')?.textContent.trim() === label, text)) { await handle.click(); return; } }
    throw new Error(`Button not found: ${text}`);
  };
  await page.goto(`http://127.0.0.1:${server.address().port}/lincoln/mi-evento`);
  await page.type('input[autocomplete=username]', 'demo'); await page.type('input[type=password]', 'demo-password'); await clickText('Ingresar');
  await page.waitForSelector('.lp-editor', { timeout: 10000 }).catch(async (error) => { console.log(await page.$eval('body', (node) => node.innerText)); throw error; });
  await page.screenshot({ path: path.join(temporary, 'overview.png'), fullPage: true });
  await page.setViewport({ width: 1920, height: 1000 });
  await clickText('Especificaciones');
  assert.ok(await page.$eval('.lp-record-board', (node) => node.scrollWidth <= node.clientWidth + 1));
  assert.ok(await page.$eval('.lp-record-fields textarea', (node) => node.getBoundingClientRect().height < 60));
  await page.screenshot({ path: path.join(temporary, 'compact-specifications.png'), fullPage: true });
  for (const width of [390, 1024, 1440, 1920]) {
    await page.setViewport({ width, height: 1000 });
    for (const label of ['Actividades', 'Revisión de proveedores', 'Especificaciones', 'Protocolo', 'Invitados', 'Proveedores']) {
      await clickText(label);
      const overflow = await page.evaluate(() => [...document.querySelectorAll('.lp-workspace-main, .lp-workspace-content, .lp-record-board, .lp-record-list, .lp-record-detail, .lp-record-fields')].some((node) => node.scrollWidth > node.clientWidth + 1));
      assert.equal(overflow, false, `${label} at ${width}px must not scroll horizontally`);
      assert.equal(await page.$$('table').then((nodes) => nodes.length), 0);
    }
  }
  await page.setViewport({ width: 1440, height: 1000 });
  await clickText('Actividades');
  await page.screenshot({ path: path.join(temporary, 'record-workspace.png'), fullPage: true });
  assert.equal(await page.$$eval('.lp-record-list > button', (rows) => rows.length), 5);
  await page.type('textarea[aria-label="Observaciones"]', '\n'.repeat(8) + 'Texto largo para comprobar crecimiento del campo');
  assert.equal(await page.$eval('textarea[aria-label="Observaciones"]', (node) => node.scrollHeight <= node.clientHeight + 1), true);
  await page.$eval('textarea[aria-label="Observaciones"]', (node) => node.focus());
  await page.keyboard.down('Control'); await page.keyboard.press('KeyA'); await page.keyboard.up('Control'); await page.keyboard.press('Backspace');
  await page.emulateMediaType('print');
  assert.equal(await page.$$eval('.lp-record-print article', (nodes) => nodes.length), 5);
  assert.equal(await page.$eval('.lp-record-board', (node) => getComputedStyle(node).display), 'none');
  await page.emulateMediaType('screen');
  await clickText('Invitados'); await clickText('+ Agregar'); await page.type('textarea[aria-label="Nombre completo"]', 'Invitado de prueba');
  await page.select('select[aria-label="Confirmación"]', 'Sí');
  await clickText('Croquis del salón'); await clickText('+ Mesa redonda'); await clickText('+ Escenario'); await clickText('+ Pista de baile');
  await page.$eval('.lp-properties input', (input) => input.focus());
  await page.keyboard.down('Control'); await page.keyboard.press('KeyA'); await page.keyboard.up('Control'); await page.keyboard.type('Pista central');
  await clickText('+ Silla');
  const initialPosition = await page.$eval('.lp-plan g[role=button]:last-of-type', (node) => node.getAttribute('transform'));
  const position = await page.$eval('.lp-plan g[role=button]:last-of-type', (node) => { const r = node.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; });
  await page.mouse.move(position.x, position.y); await page.mouse.down(); await page.mouse.move(position.x + 100, position.y + 60, { steps: 5 }); await page.mouse.up();
  await clickText('Guardar cambios'); await page.waitForSelector('.lp-success');
  const state = JSON.parse(await fs.readFile(process.env.LINCOLN_PORTAL_FILE, 'utf8'));
  assert.equal(state.plans.demo.plan.guests[0].name, 'Invitado de prueba');
  assert.equal(state.plans.demo.plan.layout.objects.length, 4);
  assert.notEqual(`translate(${state.plans.demo.plan.layout.objects.find((item) => item.type === 'chair').x} ${state.plans.demo.plan.layout.objects.find((item) => item.type === 'chair').y}) rotate(0)`, initialPosition);
  await page.screenshot({ path: path.join(temporary, 'desktop.png'), fullPage: true });
  await page.reload(); await page.waitForSelector('.lp-editor'); await clickText('Croquis del salón');
  assert.equal(await page.$$eval('.lp-plan g[role=button]', (nodes) => nodes.length), 4);
  await page.setViewport({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), true);
  await page.screenshot({ path: path.join(temporary, 'mobile.png'), fullPage: true });
  await clickText('Invitados');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), true);
  assert.equal(await page.$eval('.lp-record-fields', (node) => getComputedStyle(node).display), 'grid');
  await page.screenshot({ path: path.join(temporary, 'compact-mobile-guests.png'), fullPage: true });
  await page.setViewport({ width: 1440, height: 1000 });
  await page.goto(`http://127.0.0.1:${server.address().port}/__portal-admin-test`);
  await page.waitForSelector('input[type=password]'); await page.type('input[type=password]', 'staff-password'); await clickText('Ingresar');
  await page.waitForSelector('[aria-label="Directorio de accesos"] tbody tr');
  assert.equal(await page.$eval('.lp-admin select', (node) => node.value), '');
  assert.ok(await page.$eval('[aria-label="Directorio de accesos"]', (node) => node.textContent.includes('demo') && node.textContent.includes('0024')));
  await clickText('Cambiar contraseña'); await page.type('input[autocomplete="new-password"]', 'changed-password'); await clickText('Guardar contraseña'); await page.waitForSelector('.lp-success');
  const loginCheck = await page.evaluate(async () => { const response = await fetch('/__lincoln_db/portal/login', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'demo',password:'changed-password'})}); return response.status; });
  assert.equal(loginCheck, 200);
  await page.select('.lp-admin select', 'other-demo');
  await page.type('.lp-access-form input[autocomplete="off"]', 'demo');
  await page.waitForSelector('.lp-access-form + .lp-error');
  assert.ok(await page.$eval('.lp-access-form + .lp-error', (node) => node.textContent.includes('0024')));
  await clickText('Ver acceso existente');
  assert.equal(await page.$eval('.lp-admin select', (node) => node.value), 'demo');
  await clickText('Abrir planificación');
  await page.waitForSelector('.lp-planner-screen .lp-workspace');
  assert.equal(await page.$$('.lp-access-form').then((nodes) => nodes.length), 0);
  assert.equal(await page.$eval('#root', (node) => node.inert), true);
  assert.equal(await page.$eval('.lp-planner-screen', (node) => node.getBoundingClientRect().height), 1000);
  await page.screenshot({ path: path.join(temporary, 'admin-workspace.png'), fullPage: true });
  await clickText('Notas generales'); await page.type('.lp-tab-content textarea', 'Nota sin guardar');
  const rejectExit = (dialog) => dialog.dismiss(); page.once('dialog', rejectExit); await clickText('Portal de eventos');
  assert.ok(await page.$('.lp-planner-screen'));
  assert.equal(await page.$eval('.lp-tab-content textarea', (node) => node.value), 'Nota sin guardar');
  await clickText('Guardar cambios'); await page.waitForSelector('.lp-success'); await clickText('Portal de eventos');
  await page.waitForSelector('.lp-access-form'); assert.equal(await page.$('.lp-planner-screen'), null);
  assert.equal(await page.$eval('.lp-admin select', (node) => node.value), 'demo');
  assert.equal(await page.evaluate(() => document.body.style.overflow), '');
  assert.equal(await page.$eval('#root', (node) => node.inert), false);
  await clickText('Abrir planificación'); await page.waitForSelector('.lp-planner-screen .lp-workspace');
  await page.setViewport({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), true);
  await page.screenshot({ path: path.join(temporary, 'admin-mobile.png'), fullPage: true });
  assert.deepEqual(errors, []);
  console.log(JSON.stringify({ result: 'Client editing, admin fullscreen workspace, unsaved-change protection, return to access management and mobile layout verified', screenshots: temporary }));
} finally {
  if (browser) await browser.close();
  if (server) await new Promise((resolve) => server.close(resolve));
  // Keep screenshots for visual inspection. Isolated fixture files stay in the OS temp directory.
}
