import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getCommercialContractCode,
  getRentalReceivableEventDate,
  isRentalExcludedFromReceivables,
  createRentalReceivableExclusionMatcher,
} from './accountingRentals.js';

test('el índice conserva las prioridades de vínculos activos, eliminados y órdenes reutilizadas', () => {
  const active = Array.from({ length: 40 }, (_, i) => ({ id: `contract-${i}`, rentalId: `rental-${i}`, orderCode: `order-${i % 5}` }));
  const deleted = Array.from({ length: 40 }, (_, i) => ({ id: `deleted-${i}`, rentalId: `old-${i}`, orderCode: `order-${i % 10}`, deletedAt: '2026-10-01' }));
  const matches = createRentalReceivableExclusionMatcher(deleted, active);
  for (let i = 0; i < 50; i++) {
    for (const rental of [
      { id: `rental-${i}`, contractId: `deleted-${i}` },
      { id: `old-${i}`, contractId: `contract-${i}` },
      { id: ` OLD-${i} `, orderCode: `order-${i % 10}` },
      { id: `unlinked-${i}`, orderCode: `order-${i % 10}` },
      { id: `old-${i}`, contractCode: '100', status: i % 2 ? 'active' : 'cancelled' },
      { id: `rental-${i}`, receivablesExclusionReason: 'deleted_contract' },
    ]) assert.equal(matches(rental), isRentalExcludedFromReceivables(rental, deleted, active));
  }
});

test('solo acepta referencias comerciales en la columna contrato', () => {
  assert.equal(getCommercialContractCode('595'), '595');
  assert.equal(getCommercialContractCode(' 1523 '), '1523');
  assert.equal(getCommercialContractCode('OS-00002'), '');
  assert.equal(getCommercialContractCode('os_00839'), '');
});

const deletedContract = {
  id: 'deleted-contract',
  rentalId: 'orphan-rental',
  contractCode: '1563',
  orderCode: 'OS-00048',
  eventDate: '2026-07-04',
  deletedAt: '2026-06-27T21:38:30.839Z',
};

test('excludes a returned rental whose original contract was deleted', () => {
  const rental = {
    id: 'orphan-rental',
    contractId: null,
    contractCode: null,
    orderCode: 'OS-00048',
    status: 'returned',
  };
  assert.equal(isRentalExcludedFromReceivables(rental, [deletedContract], []), true);
});

test('does not exclude a rental owned by an active contract', () => {
  const rental = { id: 'active-rental', orderCode: 'OS-00999', status: 'returned' };
  const activeContract = { id: 'active-contract', rentalId: 'active-rental', orderCode: 'OS-00999' };
  assert.equal(isRentalExcludedFromReceivables(rental, [deletedContract], [activeContract]), false);
});

test('an exact deleted rental link wins over a reused active order code', () => {
  const rental = { id: 'orphan-rental', orderCode: 'OS-00048', status: 'returned' };
  const activeContract = { id: 'new-contract', rentalId: 'new-rental', orderCode: 'OS-00048' };
  assert.equal(isRentalExcludedFromReceivables(rental, [deletedContract], [activeContract]), true);
});

test('uses the commercial rental date before the creation timestamp', () => {
  const rental = {
    rentalDate: '2026-07-04',
    createdAt: '2026-06-27T21:37:05.343Z',
  };
  assert.equal(getRentalReceivableEventDate(rental), '2026-07-04');
});
