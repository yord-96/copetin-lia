import { buildPersonnelOverview } from '../utils/personnelOverview.js';
import { buildPettyCashFundTimeline } from '../utils/pettyCashFund.js';
import { compareCashLedgerOrder } from '../utils/cashLedgerOrder.js';
import { addPettyExpenseCategory } from '../utils/pettyExpenseCategories.js';
import { getWebBridge, getWebRuntimeInfo, WEB_DB_STORAGE_KEY } from './webBridge.js';
import { buildContractCollectionGroups } from '../utils/contractCollectionGroups.js';
import { buildInventoryKardexRows, filterInventoryKardexMovements, getMovementAvailableDelta, getMovementPhysicalDelta } from '../utils/inventoryKardex.js';

const SERVER_STATE_ENDPOINT = '/__copetin_db';
const DEFERRED_BOOTSTRAP_COLLECTIONS = Object.freeze([
  'inventoryMovements',
  'stockRecoveries',
  'legacyContracts',
  'cashMovements',
  'cashDebts',
  'generatedReports',
  'systemAuditLog',
  'attendanceRecords',
  'personnelAttendance',
  'personnelIncidents',
]);
const SUMMARIZED_BOOTSTRAP_COLLECTIONS = Object.freeze(['contracts', 'rentals']);
const PARTIAL_BOOTSTRAP_COLLECTIONS = Object.freeze([
  ...DEFERRED_BOOTSTRAP_COLLECTIONS,
  ...SUMMARIZED_BOOTSTRAP_COLLECTIONS,
]);
const CONTRACT_CREATE_PATCH_COLLECTIONS = Object.freeze([
  'clients',
  'items',
  'contracts',
  'systemAuditLog',
]);

const QUOTE_MUTATION_PATCH_COLLECTIONS = Object.freeze([
  'clients',
  'items',
  'quotes',
]);
const CONTRACT_UPDATE_PATCH_COLLECTIONS = Object.freeze([
  'clients',
  'items',
  'contracts',
  'rentals',
  'deliveries',
  'transportRoutes',
  'calendarEvents',
  'generatedReports',
  'inventoryMovements',
  'systemAuditLog',
]);
const CONTRACT_REMOVE_PATCH_COLLECTIONS = Object.freeze([
  'items',
  'quotes',
  'contracts',
  'rentals',
  'deliveries',
  'transportRoutes',
  'inventoryMovements',
  'stockRecoveries',
  'cashMovements',
  'cashDebts',
  'generatedReports',
  'systemAuditLog',
]);
const CASH_MOVEMENT_PATCH_COLLECTIONS = Object.freeze([
  'cashSessions',
  'cashMovements',
  'contracts',
  'rentals',
]);
const CASH_DEBT_PATCH_COLLECTIONS = Object.freeze([
  'cashSessions',
  'cashMovements',
  'cashDebts',
]);
const RENTAL_CANCEL_PATCH_COLLECTIONS = Object.freeze([
  'items',
  'contracts',
  'rentals',
  'deliveries',
]);
const RENTAL_OPERATIONAL_PATCH_COLLECTIONS = Object.freeze([
  'rentals',
]);
const RENTAL_RETURN_PATCH_COLLECTIONS = Object.freeze([
  'items',
  'rentals',
  'deliveries',
  'inventoryMovements',
  'cashMovements',
]);
const INVENTORY_MOVEMENT_PATCH_COLLECTIONS = Object.freeze([
  'items',
  'inventoryMovements',
]);
const INVENTORY_RECOVERY_PATCH_COLLECTIONS = Object.freeze([
  'items',
  'inventoryMovements',
  'stockRecoveries',
]);
const INVENTORY_ITEM_PATCH_COLLECTIONS = Object.freeze([
  'items',
  'categories',
  'systemAuditLog',
]);
const INVENTORY_COMBO_PATCH_COLLECTIONS = Object.freeze([
  'inventoryCombos',
]);
const USER_PATCH_COLLECTIONS = Object.freeze([
  'users',
]);

const SYNC_CHANNEL_NAME = 'copetin-data-sync-v1';
const SERVER_REVISION_STORAGE_KEY = `${WEB_DB_STORAGE_KEY}:server-revision`;
const SYNC_THROTTLE_MS = 2000;
const REMOTE_POLL_MS = 30000;
const REMOTE_POLL_TICK_MS = 5000;
const REMOTE_BACKOFF_BASE_MS = 30000;
const REMOTE_BACKOFF_MAX_MS = 180000;
const MUTATION_CONFLICT_RETRIES = 3;
const MUTATION_TRANSIENT_RETRIES = 4;
const SAVE_TRANSIENT_RETRIES = 4;
const DIRECT_STATE_SAVE_MAX_BYTES = 700 * 1024;
const STATE_CHUNK_BYTES = 480 * 1024;
const REMOTE_API_BASE_URL = String(import.meta.env?.VITE_API_URL ?? '').replace(/\/+$/, '');
const INTERNAL_KEY = String(
  import.meta.env?.VITE_APP_INTERNAL_KEY
    ?? import.meta.env?.APP_INTERNAL_KEY
    ?? '',
).trim();

const browserTabId =
  typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : `tab-${Date.now()}-${Math.random().toString(16).slice(2)}`;

let sharedSyncPromise = null;
let lastSharedSyncAt = 0;
let lastSharedRevision = null;
let hasLoadedServerState = false;
let serverStateFetchCount = 0;
let lastRemotePollAt = 0;
let remotePollInFlight = false;
let remotePollBackoffUntil = 0;
let remotePollBackoffMs = 0;
let syncChannel = null;
let syncListenersReady = false;
let syncPollTimer = null;
const syncSubscribers = new Set();
const inFlightMutations = new Map();
let mutationQueue = Promise.resolve();
let remotePresenceUnsupported = false;
let mutationBatchDepth = 0;
let mutationBatchPreflightPromise = null;
let mutationBatchDirty = false;
let mutationBatchCollections = null;
let mutationBatchBeforeState = null;
const loadedServerCollections = new Set();
let serverStateIsPartial = false;
let localServerCommitSerial = 0;

const FULL_RECORD_CACHE_TTL_MS = 30 * 1000;
const fullContractCache = new Map();
const fullRentalCache = new Map();
const fullContractRequests = new Map();
const fullRentalRequests = new Map();
const SUPPLIER_OVERVIEW_CACHE_TTL_MS = 10 * 1000;
let supplierOverviewCache = null;
let supplierOverviewRequest = null;

const invalidateSupplierOverviewCache = () => {
  supplierOverviewCache = null;
};


const readFreshFullRecordCache = (cache, identifier) => {
  const key = String(identifier ?? '').trim();
  if (!key) return null;
  const cached = cache.get(key);
  if (!cached || Date.now() - cached.cachedAt > FULL_RECORD_CACHE_TTL_MS) {
    if (cached) cache.delete(key);
    return null;
  }
  if (cached.record?._summaryOnly) {
    cache.delete(key);
    return null;
  }
  return cached.record;
};

const rememberFullRecordCache = (cache, record, identifiers = []) => {
  if (!record?.id || record?._summaryOnly) return;
  const entry = { record, cachedAt: Date.now() };
  [
    record.id,
    record.contractId,
    record.rentalId,
    record.contractCode,
    record.orderCode,
    record.number,
    ...identifiers,
  ].forEach((identifier) => {
    const key = String(identifier ?? '').trim();
    if (key) cache.set(key, entry);
  });
};

const forgetFullRecordCache = (cache, recordOrIdentifiers = []) => {
  const identifiers = Array.isArray(recordOrIdentifiers)
    ? recordOrIdentifiers
    : [
      recordOrIdentifiers?.id,
      recordOrIdentifiers?.contractId,
      recordOrIdentifiers?.rentalId,
      recordOrIdentifiers?.contractCode,
      recordOrIdentifiers?.orderCode,
      recordOrIdentifiers?.number,
    ];
  const keys = new Set(identifiers.map((identifier) => String(identifier ?? '').trim()).filter(Boolean));
  if (!keys.size) {
    cache.clear();
    return;
  }
  cache.forEach((entry, key) => {
    const record = entry?.record ?? {};
    const entryKeys = [
      key,
      record.id,
      record.contractId,
      record.rentalId,
      record.contractCode,
      record.orderCode,
      record.number,
    ].map((identifier) => String(identifier ?? '').trim()).filter(Boolean);
    if (entryKeys.some((entryKey) => keys.has(entryKey))) {
      cache.delete(key);
    }
  });
};

const getBridge = () => getWebBridge();

const getServerStateUrl = (suffix = '') =>
  REMOTE_API_BASE_URL
    ? `${REMOTE_API_BASE_URL}${SERVER_STATE_ENDPOINT}${suffix}`
    : `${SERVER_STATE_ENDPOINT}${suffix}`;

const getApiUrl = (path) =>
  REMOTE_API_BASE_URL
    ? `${REMOTE_API_BASE_URL}${path}`
    : path;

const getInternalHeaders = (extraHeaders = {}) => {
  const headers = { ...extraHeaders };
  if (INTERNAL_KEY) {
    headers['X-App-Internal-Key'] = INTERNAL_KEY;
  }
  return headers;
};

const isLocalHost = () => {
  if (typeof window === 'undefined') return false;
  return ['localhost', '127.0.0.1', '::1'].includes(window.location.hostname);
};

const shouldUseServerState = () => {
  if (typeof window === 'undefined' || window.location.protocol === 'file:') return false;
  return true;
};

const normalizePresenceList = (value) => {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.active)) return value.active;
  if (Array.isArray(value?.presence)) return value.presence;
  return [];
};

const createServerStateError = async (response, fallbackMessage) => {
  const payload = await response.json().catch(() => null);
  const error = new Error(payload?.error || fallbackMessage);
  error.status = response.status;
  error.payload = payload;
  const retryAfterSeconds = Number(response.headers.get('Retry-After') ?? 0);
  if (Number.isFinite(retryAfterSeconds) && retryAfterSeconds > 0) {
    error.retryAfterMs = retryAfterSeconds * 1000;
  }
  return error;
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const isTransientServerError = (error) =>
  error?.status === 429 || error?.status === 503 || error?.status === 504;

const isRevisionConflictError = (error) =>
  error?.status === 409
  && !error?.payload?.code
  && (
    Object.prototype.hasOwnProperty.call(error?.payload ?? {}, 'currentRevision')
    || Object.prototype.hasOwnProperty.call(error?.payload ?? {}, 'providedRevision')
    || /revision|actualiz/i.test(String(error?.message ?? ''))
  );

const getRetryDelayMs = (error, attempt) => {
  if (error?.retryAfterMs) {
    return Math.min(Math.max(error.retryAfterMs, 500), 8000);
  }
  return Math.min(700 * (attempt + 1), 3500);
};

const getSaveErrorMessage = (error, fallback) => {
  if (error instanceof TypeError && /fetch/i.test(error.message ?? '')) {
    return isLocalHost()
      ? 'No se pudo conectar con la base local. Reinicia npm run dev y vuelve a intentar la importacion.'
      : 'No se pudo conectar con el servidor. Verifica la conexion e intenta nuevamente.';
  }
  if (error?.status === 413) {
    return 'La copia de seguridad supera el tamano permitido por el servidor.';
  }
  if (error?.status === 429) {
    return 'El servidor esta recibiendo muchas operaciones al mismo tiempo. Espera unos segundos e intenta guardar otra vez.';
  }
  if (error?.status === 409) {
    if (error?.payload?.code) {
      return error.message || fallback;
    }
    return 'Otro usuario actualizo datos al mismo tiempo. Vuelve a intentar para guardar con la informacion mas reciente.';
  }
  return error?.message || fallback;
};

const resetRemoteBackoff = () => {
  remotePollBackoffUntil = 0;
  remotePollBackoffMs = 0;
};

const applyRemoteBackoff = (error) => {
  if (error?.status !== 429) return;
  remotePollBackoffMs = remotePollBackoffMs
    ? Math.min(remotePollBackoffMs * 2, REMOTE_BACKOFF_MAX_MS)
    : REMOTE_BACKOFF_BASE_MS;
  remotePollBackoffUntil = Date.now() + remotePollBackoffMs;
};

const businessCollections = [
  'categories',
  'clients',
  'users',
  'items',
  'inventoryCombos',
  'quotes',
  'contracts',
  'suppliers',
  'supplierQuotes',
  'supplierLoans',
  'personnelEmployees',
  'personnelAttendance',
  'personnelIncidents',
  'rentals',
  'deliveries',
  'transportRoutes',
  'vehicles',
  'drivers',
  'calendarEvents',
  'calendarBoardNotes',
  'generatedReports',
  'cashSessions',
  'cashMovements',
  'cashDebts',
  'attendanceRecords',
  'resetLogs',
  'inventoryMovements',
  'stockRecoveries',
  'legacyContracts',
  'systemAuditLog',
];
const PATCHABLE_COLLECTIONS = businessCollections;
const PATCH_MAX_CHANGED_ROWS = 250;
const PATCH_MAX_BYTES = 650 * 1024;

const hasBusinessData = (state) =>
  Boolean(
    state &&
      businessCollections.some((key) => Array.isArray(state[key]) && state[key].length > 0),
  );

const getLocalStorageBridge = () => getWebBridge().__storage;

const canUseBrowserStorage = () => {
  try {
    return typeof window !== 'undefined' && Boolean(window.localStorage);
  } catch {
    return false;
  }
};

const getCachedServerRevision = () => {
  if (!canUseBrowserStorage()) return null;
  return window.localStorage.getItem(SERVER_REVISION_STORAGE_KEY);
};

const setCachedServerRevision = (revision) => {
  if (!canUseBrowserStorage() || !revision) return;
  window.localStorage.setItem(SERVER_REVISION_STORAGE_KEY, String(revision));
};

const hasCachedLocalState = () => {
  if (!canUseBrowserStorage()) return false;
  return Boolean(window.localStorage.getItem(WEB_DB_STORAGE_KEY));
};

const isSummaryOnlyRow = (row) =>
  Boolean(row && typeof row === 'object' && !Array.isArray(row) && row._summaryOnly);

const mergeSummaryRecordDetails = (incomingRecord, currentRecord, detailKeys = []) => {
  if (!isSummaryOnlyRow(incomingRecord) || !currentRecord || isSummaryOnlyRow(currentRecord)) {
    return incomingRecord;
  }
  const merged = { ...incomingRecord };
  detailKeys.forEach((key) => {
    const incomingValue = incomingRecord[key];
    const currentValue = currentRecord[key];
    const incomingIsEmptyArray = Array.isArray(incomingValue) && incomingValue.length === 0;
    const incomingIsEmptyObject = incomingValue
      && typeof incomingValue === 'object'
      && !Array.isArray(incomingValue)
      && Object.keys(incomingValue).length === 0;
    const incomingIsEmpty = incomingValue == null || incomingIsEmptyArray || incomingIsEmptyObject;
    if (incomingIsEmpty && currentValue != null) {
      merged[key] = currentValue;
    }
  });
  return merged;
};

const preserveLocalDetailsInSummaries = async (state) => {
  if (!state || typeof state !== 'object' || Array.isArray(state)) return state;
  const hasSummarizedContracts = Array.isArray(state.contracts) && state.contracts.some(isSummaryOnlyRow);
  const hasSummarizedRentals = Array.isArray(state.rentals) && state.rentals.some(isSummaryOnlyRow);
  if (!hasSummarizedContracts && !hasSummarizedRentals) return state;

  const current = await exportLocalCollections([
    ...(hasSummarizedContracts ? ['contracts'] : []),
    ...(hasSummarizedRentals ? ['rentals'] : []),
  ]);
  const nextState = { ...state };

  if (hasSummarizedContracts) {
    const currentContractsById = new Map((Array.isArray(current?.contracts) ? current.contracts : [])
      .map((row) => [String(row?.id ?? '').trim(), row])
      .filter(([id]) => id));
    nextState.contracts = state.contracts.map((row) => {
      const currentRow = currentContractsById.get(String(row?.id ?? '').trim());
      const incomingIsResetAuthoritative = Boolean(row?.economicResetAt)
        || Number(row?.economicResetVersion ?? 0) >= 1;
      return mergeSummaryRecordDetails(
        row,
        currentRow,
        [
          ...(incomingIsResetAuthoritative ? [] : ['economicLedger']),
          'revisionHistory',
          'supplierFulfillmentPlan',
          'pricingPlan',
          'deletionSnapshot',
        ],
      );
    });
  }

  if (hasSummarizedRentals) {
    const currentRentalsById = new Map((Array.isArray(current?.rentals) ? current.rentals : [])
      .map((row) => [String(row?.id ?? '').trim(), row])
      .filter(([id]) => id));
    nextState.rentals = state.rentals.map((row) => mergeSummaryRecordDetails(
      row,
      currentRentalsById.get(String(row?.id ?? '').trim()),
      [
        'inventoryAvailabilityAssumptions',
        'returnReport',
        'returnSettlement',
        'supplierFulfillmentPlan',
      ],
    ));
  }

  return nextState;
};

const replaceLocalState = async (state) => {
  const storage = getLocalStorageBridge();
  if (storage?.applyServerState && state) {
    await storage.applyServerState(await preserveLocalDetailsInSummaries(state), { replace: true });
    return;
  }
  if (storage?.replaceState && state) {
    await storage.replaceState(await preserveLocalDetailsInSummaries(state));
  }
};

const mergeLocalState = async (state) => {
  const storage = getLocalStorageBridge();
  if (storage?.applyServerState && state) {
    await storage.applyServerState(await preserveLocalDetailsInSummaries(state));
    return;
  }
  if (storage?.mergeState && state) {
    await storage.mergeState(await preserveLocalDetailsInSummaries(state));
    return;
  }
  const currentState = await exportLocalState();
  await replaceLocalState(await preserveLocalDetailsInSummaries({ ...(currentState ?? {}), ...(state ?? {}) }));
};

const exportLocalState = async () => {
  const storage = getLocalStorageBridge();
  if (!storage?.exportState) {
    return null;
  }
  return storage.exportState();
};

const exportLocalCollections = async (names = []) => {
  const storage = getLocalStorageBridge();
  if (storage?.exportCollections) {
    return storage.exportCollections(names);
  }
  const state = await exportLocalState();
  if (!state) return null;
  const snapshot = { settings: state.settings ?? {} };
  for (const name of names) {
    if (Object.prototype.hasOwnProperty.call(state, name)) {
      snapshot[name] = state[name];
    }
  }
  return snapshot;
};

// El limite incluye la lectura del cuerpo de la respuesta.
const fetchServerJson = async (url, errorMessage) => {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 20000);
  try {
    const response = await fetch(url, {
      cache: 'no-store',
      headers: getInternalHeaders(),
      signal: controller.signal,
    });
    if (!response.ok) throw await createServerStateError(response, errorMessage);
    return await response.json();
  } catch (error) {
    if (controller.signal.aborted) {
      const timeoutError = new Error('El servidor esta tardando demasiado. Vuelve a intentar la operacion.');
      timeoutError.code = 'ETIMEDOUT';
      throw timeoutError;
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
};

const fetchServerState = async (reason = 'sync', { bootstrap = false } = {}) => {
  serverStateFetchCount += 1;
  const requestNumber = serverStateFetchCount;
  const startedAt = typeof performance !== 'undefined' ? performance.now() : Date.now();
  console.info(`[copetin-sync] GET ${SERVER_STATE_ENDPOINT} #${requestNumber} iniciado`, { reason });
  const payload = await fetchServerJson(getServerStateUrl(bootstrap ? '?bootstrap=1' : ''), 'No se pudo leer la base de datos del sistema.');
  const finishedAt = typeof performance !== 'undefined' ? performance.now() : Date.now();
  console.info(`[copetin-sync] GET ${SERVER_STATE_ENDPOINT} #${requestNumber} completado`, {
    reason,
    durationMs: Math.round(finishedAt - startedAt),
    revision: payload?.revision ?? null,
  });
  if (payload && Object.prototype.hasOwnProperty.call(payload, 'revision')) {
    lastSharedRevision = payload.revision;
    setCachedServerRevision(payload.revision);
  }
  return payload;
};

const fetchServerCollections = async (names, reason = 'deferred-load') => {
  const requestedNames = [...new Set((Array.isArray(names) ? names : [])
    .map((name) => String(name ?? '').trim())
    .filter(Boolean))];
  if (!requestedNames.length) return {};
  const payload = await fetchServerJson(getServerStateUrl(`/collections?names=${encodeURIComponent(requestedNames.join(','))}`), 'No se pudieron cargar los datos adicionales del sistema.');
  if (payload?.revision) {
    lastSharedRevision = payload.revision;
    setCachedServerRevision(payload.revision);
  }
  await mergeLocalState(payload?.collections ?? {});
  requestedNames.forEach((name) => loadedServerCollections.add(name));
  serverStateIsPartial = PARTIAL_BOOTSTRAP_COLLECTIONS.some((name) => !loadedServerCollections.has(name));
  console.info('[copetin-sync] Colecciones diferidas cargadas.', { reason, collections: requestedNames });
  return payload?.collections ?? {};
};


const fetchMobileCalendarOverview = async () => {
  const payload = await fetchServerJson(getServerStateUrl('/calendar/mobile-overview'), 'No se pudo cargar el resumen movil del calendario.');
  if (payload?.revision) {
    lastSharedRevision = payload.revision;
    setCachedServerRevision(payload.revision);
  }
  const overview = payload?.overview ?? { contracts: [], rentals: [], deliveries: [], calendarEvents: [] };
  // Calendario es una vista efimera. No mezclamos sus cientos de resumenes en
  // webBridge porque esa reconciliacion bloquea el hilo principal y puede
  // provocar cargas completas de contratos/rentals al cambiar de modulo.
  serverStateIsPartial = true;
  return overview;
};


const fetchMobileOrdersOverview = async () => {
  const payload = await fetchServerJson(getServerStateUrl('/orders/mobile-overview'), 'No se pudo cargar el resumen movil de Ordenes.');
  if (payload?.revision) {
    lastSharedRevision = payload.revision;
    setCachedServerRevision(payload.revision);
  }
  const overview = payload?.overview ?? {
    contracts: [],
    hiddenContracts: [],
    rentals: [],
    deliveries: [],
    quotes: [],
    clients: [],
    items: [],
    inventoryCombos: [],
    suppliers: [],
    supplierQuotes: [],
    supplierLoans: [],
    vehicles: [],
    drivers: [],
    users: [],
    personnelEmployees: [],
    settings: {},
  };
  // Este resumen vive directamente en React. No lo copiamos al bridge/local state:
  // evita serializar varios MB antes de que la tabla pueda pintarse.
  serverStateIsPartial = true;
  return overview;
};

const fetchAccountingBaseOverview = async ({ includeCommercial = true } = {}) => {
  if (!shouldUseServerState()) {
    const [contracts, rentals, clients, cashSessions] = await Promise.all([
      callBridge('contracts', 'list', false),
      callBridge('rentals', 'list', false),
      callBridge('clients', 'list', false),
      callBridge('cash', 'listSessions', false),
    ]);
    return { contracts, rentals, clients, cashSessions };
  }
  const suffix = includeCommercial ? '' : '?scope=petty';
  const response = await fetch(getServerStateUrl(`/accounting/base-overview${suffix}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo cargar el resumen rapido de Contabilidad.');
  }
  const payload = await response.json();
  if (payload?.revision) rememberServerRevision(payload.revision);
  const overview = payload?.overview ?? {
    contracts: [], rentals: [], clients: [], cashSessions: [],
  };
  // Igual que Ordenes, el resumen se entrega directamente a React. No se
  // serializa en el bridge local ni sustituye registros completos ya cargados.
  serverStateIsPartial = true;
  return overview;
};

const fetchFastAccountingSummary = async () => {
  if (!shouldUseServerState()) return callBridge('cash', 'getSummary', false);
  const response = await fetch(getServerStateUrl('/accounting/summary'), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo consultar el saldo oficial de las cajas.');
  }
  const summary = await response.json();
  if (summary?.revision) rememberServerRevision(summary.revision);
  return {
    ...summary,
    operationalBigCashBs: Number(summary?.bigCashBalanceBs ?? 0),
    treasuryAccounts: [],
    treasuryAllocatedBs: 0,
    treasuryUnassignedBs: Number(summary?.bigCashBalanceBs ?? 0),
  };
};

const fetchClientsOverview = async () => {
  if (!shouldUseServerState()) {
    const clients = await callBridge('clients', 'list', false);
    return { clients, stats: null };
  }
  const payload = await fetchServerJson(getServerStateUrl('/clients/overview'), 'No se pudo cargar el resumen de Clientes.');
  if (payload?.revision) rememberServerRevision(payload.revision);
  serverStateIsPartial = true;
  return payload?.overview ?? { clients: [], stats: null };
};

const fetchOrdersEditorOverview = async () => {
  const payload = await fetchServerJson(getServerStateUrl('/orders/editor-overview'), 'No se pudieron cargar los datos del editor de Ordenes.');
  if (payload?.revision) rememberServerRevision(payload.revision);
  const overview = payload?.overview ?? {};
  // Los datos de edición sí se mezclan en el bridge porque las mutaciones y
  // selectores los reutilizan después de abrir el wizard.
  await mergeLocalState(overview);
  serverStateIsPartial = true;
  return overview;
};

const fetchAvailabilityOverview = async () => {
  const payload = await fetchServerJson(getServerStateUrl('/availability/overview'), 'No se pudo cargar la informacion de disponibilidad.');
  if (payload?.revision) {
    lastSharedRevision = payload.revision;
    setCachedServerRevision(payload.revision);
  }
  const overview = payload?.overview ?? {
    contracts: [], rentals: [], quotes: [], clients: [], items: [], categories: [],
  };
  // Esta respuesta esta reducida exclusivamente para la vista de
  // Disponibilidad. No reemplazamos el bridge compartido con estos resúmenes:
  // los módulos de edición cargan sus colecciones completas al abrirse.
  serverStateIsPartial = true;
  return overview;
};

const fetchInventoryMovementsOverview = async ({
  from = '',
  to = '',
  query = '',
  historyQuery = '',
  historyFrom = '',
  historyTo = '',
  historyType = 'all',
  historyUser = 'all',
} = {}) => {
  if (!shouldUseServerState()) {
    await ensureServerCollectionsLoaded(['inventoryMovements'], 'inventory-movements');
    return {
      items: await callBridge('inventory', 'list', false),
      inventoryCombos: await callBridge('inventory', 'listCombos', false),
      inventoryMovements: await callBridge('inventory', 'listMovements', false),
      movementStats: null,
    };
  }
  const params = new URLSearchParams();
  if (from) params.set('from', String(from).slice(0, 10));
  if (to) params.set('to', String(to).slice(0, 10));
  if (String(query ?? '').trim()) params.set('query', String(query).trim());
  if (String(historyQuery ?? '').trim()) params.set('movementQuery', String(historyQuery).trim());
  if (historyFrom) params.set('movementFrom', String(historyFrom).slice(0, 10));
  if (historyTo) params.set('movementTo', String(historyTo).slice(0, 10));
  if (historyType && historyType !== 'all') params.set('movementType', String(historyType));
  if (historyUser && historyUser !== 'all') params.set('movementUser', String(historyUser));
  const suffix = params.toString() ? `?${params.toString()}` : '';
  const response = await fetch(getServerStateUrl(`/inventory/movements-overview${suffix}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo cargar el resumen de movimientos de inventario.');
  }
  const payload = await response.json();
  if (payload?.revision) rememberServerRevision(payload.revision);
  const overview = payload?.overview ?? {
    items: [], inventoryCombos: [], categories: [], contracts: [], rentals: [],
    deliveries: [], inventoryMovements: [], movementStats: null,
  };
  // Este overview es efímero y específico de la pantalla. No se mezcla en
  // webBridge: hacerlo obligaba a reconciliar contratos/rentals resumidos y
  // disparaba trabajo adicional con decenas de MB en el navegador.
  serverStateIsPartial = true;
  return overview;
};


const fetchInventoryMovementHistory = async ({
  query = '',
  from = '',
  to = '',
  type = 'all',
  user = 'all',
  limit = 650,
  offset = 0,
} = {}) => {
  if (!shouldUseServerState()) {
    await ensureServerCollectionsLoaded(['inventoryMovements'], 'inventory-movements-history');
    const rows = await callBridge('inventory', 'listMovements', false);
    return {
      rows: Array.isArray(rows) ? rows : [],
      total: Array.isArray(rows) ? rows.length : 0,
      offset: 0,
      limit: Array.isArray(rows) ? rows.length : 0,
      hasMore: false,
    };
  }
  const params = new URLSearchParams();
  if (String(query ?? '').trim()) params.set('query', String(query).trim());
  if (from) params.set('from', String(from).slice(0, 10));
  if (to) params.set('to', String(to).slice(0, 10));
  if (type && type !== 'all') params.set('type', String(type));
  if (user && user !== 'all') params.set('user', String(user));
  params.set('limit', String(Math.max(1, Number(limit) || 650)));
  params.set('offset', String(Math.max(0, Number(offset) || 0)));
  const response = await fetch(getServerStateUrl(`/inventory/movements-history?${params.toString()}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo buscar el historial completo de inventario.');
  }
  const payload = await response.json();
  if (payload?.revision) rememberServerRevision(payload.revision);
  return {
    rows: Array.isArray(payload?.rows) ? payload.rows : [],
    total: Number(payload?.total ?? 0),
    offset: Number(payload?.offset ?? 0),
    limit: Number(payload?.limit ?? limit),
    hasMore: Boolean(payload?.hasMore),
  };
};


const fetchLegacyContracts = async () => {
  const response = await fetch(getServerStateUrl('/inventory/legacy-contracts'), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudieron cargar los contratos rezagados.');
  const payload = await response.json();
  if (payload?.revision) rememberServerRevision(payload.revision);
  return Array.isArray(payload?.rows) ? payload.rows : [];
};

const mutateLegacyContract = async (method, path, payload = {}) => {
  const response = await fetch(getServerStateUrl(`/inventory/legacy-contracts${path}`), {
    method,
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo actualizar el contrato rezagado.');
  const result = await response.json();
  if (result?.revision) rememberServerRevision(result.revision);
  markServerStateStale('inventory.legacyContracts');
  return result;
};

const postLegacyContract = (path, payload = {}) => mutateLegacyContract('POST', path, payload);

const settleLegacyContract = async (id, payload = {}) => {
  const result = await callDirectCashOperation(`/inventory/legacy-contracts/${encodeURIComponent(id)}/settle`, payload);
  await applyDirectCashResultLocally(result);
  markServerStateStale('inventory.legacyContracts.settle');
  return result;
};

const fetchInventoryDamageLossOverview = async () => {
  if (!shouldUseServerState()) return { rows: [], total: 0, summary: {} };
  const response = await fetch(getServerStateUrl('/inventory/damage-loss-overview'), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo cargar el kardex de daños y faltantes.');
  const payload = await response.json();
  if (payload?.revision) rememberServerRevision(payload.revision);
  return payload;
};

const fetchProductsKardex = async () => {
  if (!shouldUseServerState()) {
    const [items, movements] = await Promise.all([
      callBridge('inventory', 'list', false),
      callBridge('inventory', 'listMovements', false),
    ]);
    return { rows: buildInventoryKardexRows(items, movements) };
  }
  const response = await fetch(getServerStateUrl('/inventory/products-kardex'), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo cargar el kardex de productos.');
  return response.json();
};

const fetchProductKardexHistory = async ({ itemId, metric = 'current' } = {}) => {
  const normalizedItemId = String(itemId ?? '').trim();
  if (!normalizedItemId) throw new Error('Debes seleccionar un producto.');
  if (!shouldUseServerState()) {
    const [items, movements] = await Promise.all([
      callBridge('inventory', 'list', false),
      callBridge('inventory', 'listMovements', false),
    ]);
    const item = items.find((entry) => String(entry?.id ?? '') === normalizedItemId);
    const itemMovements = movements.filter((entry) => String(entry?.itemId ?? '') === normalizedItemId);
    const matching = filterInventoryKardexMovements(itemMovements, metric)
      .sort((a, b) => new Date(b?.createdAt ?? b?.operationDate ?? 0) - new Date(a?.createdAt ?? a?.operationDate ?? 0));
    return {
      item,
      metric,
      summary: buildInventoryKardexRows(item ? [item] : [], itemMovements)[0] ?? null,
      movements: matching.slice(0, 200).map((movement) => ({
        ...movement,
        physicalDelta: getMovementPhysicalDelta(movement),
        availableDelta: getMovementAvailableDelta(movement),
      })),
      totalMatches: matching.length,
      truncated: matching.length > 200,
    };
  }
  const query = new URLSearchParams({ metric: String(metric ?? 'current') });
  const response = await fetch(getServerStateUrl(`/inventory/products/${encodeURIComponent(normalizedItemId)}/kardex?${query}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo cargar el historial del producto.');
  return response.json();
};

const ensureServerCollectionsLoaded = async (names, reason = 'deferred-load') => {
  if (!shouldUseServerState()) return;
  const missingNames = (Array.isArray(names) ? names : [])
    .filter((name) => PARTIAL_BOOTSTRAP_COLLECTIONS.includes(name) || name === 'cashSessions')
    .filter((name) => !loadedServerCollections.has(name));
  if (!missingNames.length) return;
  await fetchServerCollections(missingNames, reason);
};


const fetchFullServerContract = async (identifier, reason = 'contract-full-load') => {
  const requestedId = String(identifier ?? '').trim();
  if (!requestedId) {
    throw new Error('Debes indicar el contrato que deseas cargar.');
  }

  const cachedContract = readFreshFullRecordCache(fullContractCache, requestedId);
  if (cachedContract) return cachedContract;
  if (fullContractRequests.has(requestedId)) return fullContractRequests.get(requestedId);

  const requestPromise = (async () => {
  const response = await fetch(getServerStateUrl(`/contracts/${encodeURIComponent(requestedId)}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo cargar el contrato completo.');
  }

  const payload = await response.json();
  const contract = payload?.contract ?? null;
  if (!contract?.id) {
    throw new Error('El servidor no devolvio el contrato completo.');
  }
  if (contract._summaryOnly) {
    throw new Error('El servidor devolvio un resumen del contrato. La edicion fue bloqueada para proteger precios, notas y subalquileres.');
  }

  if (payload?.revision) {
    rememberServerRevision(payload.revision);
  }

  const isTransientDocumentsHistoryLoad = ['documents-history', 'edit-contract'].includes(reason);

  if (!isTransientDocumentsHistoryLoad) {
    const localSnapshot = await exportLocalCollections(['contracts']);
    const currentContracts = Array.isArray(localSnapshot?.contracts) ? localSnapshot.contracts : [];
    const nextContracts = currentContracts.some((entry) => String(entry?.id ?? '') === String(contract.id))
      ? currentContracts.map((entry) => (
        String(entry?.id ?? '') === String(contract.id) ? contract : entry
      ))
      : [contract, ...currentContracts];

    await mergeLocalState({ contracts: nextContracts });
  }

  rememberFullRecordCache(fullContractCache, contract, [requestedId]);
  console.info('[copetin-sync] Contrato completo cargado.', {
    reason,
    contractId: contract.id,
    contractCode: contract.contractCode ?? null,
  });
  return contract;
  })();

  fullContractRequests.set(requestedId, requestPromise);
  try {
    return await requestPromise;
  } finally {
    fullContractRequests.delete(requestedId);
  }
};

const fetchFullServerRental = async (identifier, reason = 'rental-full-load') => {
  const requestedId = String(identifier ?? '').trim();
  if (!requestedId) {
    throw new Error('Debes indicar la orden que deseas cargar.');
  }

  const cachedRental = readFreshFullRecordCache(fullRentalCache, requestedId);
  if (cachedRental) return cachedRental;
  if (fullRentalRequests.has(requestedId)) return fullRentalRequests.get(requestedId);

  const requestPromise = (async () => {
  const response = await fetch(getServerStateUrl(`/rentals/${encodeURIComponent(requestedId)}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo cargar la orden completa.');
  }

  const payload = await response.json();
  const rental = payload?.rental ?? null;
  if (!rental?.id) {
    throw new Error('El servidor no devolvio la orden completa.');
  }
  if (rental._summaryOnly) {
    throw new Error('El servidor devolvio un resumen de la orden. La edicion fue bloqueada para proteger sus datos.');
  }

  if (payload?.revision) {
    rememberServerRevision(payload.revision);
  }

  const isTransientEditRentalLoad = reason === 'edit-contract';

  if (!isTransientEditRentalLoad) {
    const localSnapshot = await exportLocalCollections(['rentals']);
    const currentRentals = Array.isArray(localSnapshot?.rentals) ? localSnapshot.rentals : [];
    const nextRentals = currentRentals.some((entry) => String(entry?.id ?? '') === String(rental.id))
      ? currentRentals.map((entry) => (
        String(entry?.id ?? '') === String(rental.id) ? rental : entry
      ))
      : [rental, ...currentRentals];

    await mergeLocalState({ rentals: nextRentals });
  }

  rememberFullRecordCache(fullRentalCache, rental, [requestedId]);
  console.info('[copetin-sync] Orden completa cargada.', {
    reason,
    rentalId: rental.id,
    orderCode: rental.orderCode ?? null,
    contractCode: rental.contractCode ?? null,
  });
  return rental;
  })();

  fullRentalRequests.set(requestedId, requestPromise);
  try {
    return await requestPromise;
  } finally {
    fullRentalRequests.delete(requestedId);
  }
};


const fetchAttendanceRecordsDirect = async (filters = {}) => {
  if (!shouldUseServerState()) {
    const records = await callBridge('attendance', 'listRecords', false);
    return filters.userId ? records.filter((record) => String(record.userId) === String(filters.userId)) : records;
  }
  const params = new URLSearchParams();
  const dateFrom = String(filters?.dateFrom ?? '').trim();
  const dateTo = String(filters?.dateTo ?? '').trim();
  const type = String(filters?.type ?? 'all').trim();
  const query = String(filters?.query ?? '').trim();
  if (dateFrom) params.set('dateFrom', dateFrom);
  if (dateTo) params.set('dateTo', dateTo);
  if (type) params.set('type', type);
  if (query) params.set('query', query);
  if (filters.userId) params.set('userId', String(filters.userId));
  // Attendance reports always use Bolivia time, regardless of the viewer's device.
  params.set('timezoneOffsetMinutes', '240');
  params.set('limit', String(Math.min(1000, Math.max(20, Number(filters?.limit ?? 300) || 300))));

  const response = await fetch(getServerStateUrl(`/attendance?${params.toString()}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo cargar la asistencia.');
  }
  const result = await response.json();
  if (result?.revision) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
  }
  return Array.isArray(result?.records) ? result.records : [];
};

const fetchAttendanceUsersDirect = async () => {
  if (!shouldUseServerState()) {
    return callBridge('users', 'list', false);
  }
  const response = await fetch(getServerStateUrl('/attendance/users'), {
    cache: 'default',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudieron cargar los usuarios de asistencia.');
  }
  const result = await response.json();
  if (result?.revision) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
  }
  return Array.isArray(result?.users) ? result.users : [];
};

const fetchLincolnCommercialOverview = ({ query = '', status = 'all', from = '', to = '' } = {}) => {
  const params = new URLSearchParams();
  if (query) params.set('query', String(query));
  if (status) params.set('status', String(status));
  if (from) params.set('from', String(from));
  if (to) params.set('to', String(to));
  return fetchLincolnQuery(`/__lincoln_db/commercial?${params.toString()}`, 'No se pudo cargar Reservas y Contratos de Lincoln.');
};

const fetchLincolnContractPdf = async ({ identifier }) => {
  const requestedId = String(identifier ?? '').trim();
  if (!requestedId) throw new Error('No se pudo identificar el contrato Lincoln.');
  const response = await fetch(getApiUrl(`/__lincoln_db/contracts/${encodeURIComponent(requestedId)}/pdf`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo generar el PDF del contrato Lincoln.');
  }
  const pdfBlob = await response.blob();
  if (pdfBlob.type && pdfBlob.type !== 'application/pdf') {
    throw new Error('El servidor no devolvió un PDF válido para el contrato Lincoln.');
  }
  return {
    blobUrl: URL.createObjectURL(pdfBlob),
    mimeType: 'application/pdf',
    cacheStatus: response.headers.get('X-Document-Cache') ?? '',
    durationMs: Number(response.headers.get('X-Document-Duration-Ms') ?? 0),
  };
};

const fetchLincolnClientsOverview = ({ query = '', status = 'all' } = {}) => {
  const params = new URLSearchParams();
  if (query) params.set('query', String(query));
  if (status) params.set('status', String(status));
  return fetchLincolnQuery(`/__lincoln_db/clients/overview?${params.toString()}`, 'No se pudo cargar la base de clientes de Lincoln.');
};

const fetchLincolnRoomsOverview = ({ query = '', status = 'all' } = {}) => {
  const params = new URLSearchParams();
  if (query) params.set('query', String(query));
  if (status) params.set('status', String(status));
  return fetchLincolnQuery(`/__lincoln_db/rooms/overview?${params.toString()}`, 'No se pudo cargar Salones Lincoln.');
};

const fetchLincolnPackagesOverview = ({ query = '', status = 'all', roomId = '' } = {}) => {
  const params = new URLSearchParams();
  if (query) params.set('query', String(query));
  if (status) params.set('status', String(status));
  if (roomId) params.set('roomId', String(roomId));
  return fetchLincolnQuery(`/__lincoln_db/packages/overview?${params.toString()}`, 'No se pudo cargar Paquetes Lincoln.');
};



const fetchLincolnAgendaMonth = async ({ year, month }) => {
  const query = new URLSearchParams({ year: String(year), month: String(month) });
  const response = await fetch(getApiUrl(`/__lincoln_db/agenda/month?${query.toString()}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo cargar la agenda mensual de Lincoln.');
  }
  return response.json();
};

const fetchLincolnAgendaYear = async ({ year }) => {
  const query = new URLSearchParams({ year: String(year) });
  const response = await fetch(getApiUrl(`/__lincoln_db/agenda/year?${query.toString()}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo cargar el radar anual de Lincoln.');
  }
  return response.json();
};


const fetchLincolnQuery = async (path, fallback) => {
  const response = await fetch(getApiUrl(path), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) throw await createServerStateError(response, fallback);

  const contentType = String(response.headers.get('content-type') ?? '').toLowerCase();
  if (!contentType.includes('application/json')) {
    const body = await response.text().catch(() => '');
    const looksLikeHtml = /<!doctype|<html/i.test(body);
    const error = new Error(
      looksLikeHtml
        ? 'El servidor local todavía no cargó esta ruta de Lincoln. Reinicia el proceso de desarrollo del servidor y vuelve a abrir la vista.'
        : fallback,
    );
    error.status = response.status;
    throw error;
  }

  return response.json();
};

const fetchLincolnSettlements = ({ year = '', status = 'all', query = '' } = {}) => {
  const params = new URLSearchParams();
  if (year) params.set('year', String(year));
  if (status) params.set('status', String(status));
  if (query) params.set('query', String(query));
  return fetchLincolnQuery(`/__lincoln_db/settlements?${params.toString()}`, 'No se pudieron cargar las rendiciones Lincoln.');
};

const fetchLincolnSettlementDetail = ({ eventId }) => fetchLincolnQuery(
  `/__lincoln_db/settlements/${encodeURIComponent(eventId)}`,
  'No se pudo cargar la rendición del evento Lincoln.',
);

const fetchLincolnMonthlyReport = ({ year, month }) => fetchLincolnQuery(
  `/__lincoln_db/reports/monthly?${new URLSearchParams({ year: String(year), month: String(month) }).toString()}`,
  'No se pudo cargar el reporte mensual Lincoln.',
);

const fetchLincolnAnnualReport = ({ year }) => fetchLincolnQuery(
  `/__lincoln_db/reports/annual?${new URLSearchParams({ year: String(year) }).toString()}`,
  'No se pudo cargar el reporte anual Lincoln.',
);

const fetchLincolnEventReport = ({ eventId }) => fetchLincolnQuery(
  `/__lincoln_db/reports/events/${encodeURIComponent(eventId)}`,
  'No se pudo cargar el reporte del evento Lincoln.',
);

const postLincolnAdmin = async (path, payload, fallback) => {
  const response = await fetch(getApiUrl(path), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload ?? {}),
  });
  if (!response.ok) throw await createServerStateError(response, fallback);
  return response.json();
};

const verifyLincolnResetAccess = (payload) => postLincolnAdmin(
  '/__lincoln_db/admin/reset/verify',
  payload,
  'No se pudo validar el acceso al Panel Reset de Lincoln.',
);

const analyzeLincolnReset = (payload) => postLincolnAdmin(
  '/__lincoln_db/admin/reset/analyze',
  payload,
  'No se pudo analizar el reset de Lincoln.',
);

const executeLincolnReset = (payload) => postLincolnAdmin(
  '/__lincoln_db/admin/reset/execute',
  payload,
  'No se pudo ejecutar el reset de Lincoln.',
);

const exportLincolnDatabase = async (payload) => {
  const response = await fetch(getApiUrl('/__lincoln_db/admin/database/export'), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload ?? {}),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo descargar la base independiente de Lincoln.');
  }
  const disposition = String(response.headers.get('content-disposition') ?? '');
  const fileMatch = disposition.match(/filename="?([^";]+)"?/i);
  return {
    blob: await response.blob(),
    filename: fileMatch?.[1] || `lincoln-base-datos-${new Date().toISOString().replace(/[:.]/g, '-')}.json`,
    revision: response.headers.get('X-Lincoln-Revision') ?? '',
  };
};

const fetchLincolnState = async () => {
  const response = await fetch(getApiUrl('/__lincoln_db'), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo abrir la base independiente de Lincoln.');
  }
  return response.json();
};

const replaceLincolnState = async ({ state, revision }) => {
  const response = await fetch(getApiUrl('/__lincoln_db'), {
    method: 'PUT',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ state, revision }),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo guardar la base independiente de Lincoln.');
  }
  return response.json();
};


const mutateLincolnRecord = async ({ collection, id = '', record, revision, actor }) => {
  const suffix = id
    ? `/__lincoln_db/${encodeURIComponent(collection)}/${encodeURIComponent(id)}`
    : `/__lincoln_db/${encodeURIComponent(collection)}`;
  const response = await fetch(getApiUrl(suffix), {
    method: id ? 'PUT' : 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ record, revision, actor }),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo guardar el registro de Lincoln.');
  }
  return response.json();
};

const convertLincolnReservation = async ({ reservationId, event, revision, actor }) => {
  const response = await fetch(getApiUrl(`/__lincoln_db/reservations/${encodeURIComponent(reservationId)}/convert`), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ event, revision, actor }),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo convertir la reserva en evento.');
  }
  return response.json();
};


const callLincolnMutation = async (path, { method = 'POST', body = {}, fallback = 'No se pudo completar la operación de Lincoln.' } = {}) => {
  const response = await fetch(getApiUrl(path), {
    method,
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw await createServerStateError(response, fallback);
  }
  return response.json();
};

const createLincolnEventPayment = ({ eventId, payment, revision, actor }) => callLincolnMutation(
  `/__lincoln_db/events/${encodeURIComponent(eventId)}/payments`,
  { body: { payment, revision, actor }, fallback: 'No se pudo registrar el pago del evento Lincoln.' },
);

const createLincolnEconomicEntry = ({ eventId, entry, revision, actor }) => callLincolnMutation(
  `/__lincoln_db/events/${encodeURIComponent(eventId)}/economic-ledger`,
  { body: { entry, revision, actor }, fallback: 'No se pudo registrar el movimiento económico Lincoln.' },
);

const resetLincolnEventEconomics = ({ eventId, confirmation, reason, revision, actor }) => callLincolnMutation(
  `/__lincoln_db/events/${encodeURIComponent(eventId)}/economic-reset`,
  { body: { confirmation, reason, revision, actor }, fallback: 'No se pudo ejecutar el Reset económico del evento.' },
);

const voidLincolnEventPayment = ({ paymentId, reason, revision, actor }) => callLincolnMutation(
  `/__lincoln_db/payments/${encodeURIComponent(paymentId)}/void`,
  { body: { reason, revision, actor }, fallback: 'No se pudo anular el pago de Lincoln.' },
);

const returnLincolnEventGuarantee = ({ eventId, refund, revision, actor }) => callLincolnMutation(
  `/__lincoln_db/events/${encodeURIComponent(eventId)}/guarantee-return`,
  { body: { refund, revision, actor }, fallback: 'No se pudo registrar la devolución de garantía.' },
);

const mutateLincolnExpense = ({ id = '', expense, revision, actor }) => callLincolnMutation(
  id ? `/__lincoln_db/cash/expenses/${encodeURIComponent(id)}` : '/__lincoln_db/cash/expenses',
  {
    method: id ? 'PUT' : 'POST',
    body: { expense, revision, actor },
    fallback: 'No se pudo guardar el egreso de Lincoln.',
  },
);


const setLincolnSettlementStatus = ({ eventId, settlement, revision, actor }) => callLincolnMutation(
  `/__lincoln_db/settlements/${encodeURIComponent(eventId)}/status`,
  {
    method: 'PUT',
    body: { settlement, revision, actor },
    fallback: 'No se pudo actualizar el estado de la rendición Lincoln.',
  },
);

const createAttendanceRecordDirect = async (payload = {}) => {
  if (!shouldUseServerState()) {
    return callBridge('attendance', 'createRecord', true, payload);
  }
  const response = await fetch(getServerStateUrl('/attendance'), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo registrar la asistencia.');
  }
  const result = await response.json();
  if (result?.revision) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
    lastSharedSyncAt = Date.now();
    hasLoadedServerState = true;
  }
  announceDataChange({
    domain: 'attendance',
    method: 'createRecord',
    collections: ['attendanceRecords'],
  });
  return result?.record ?? null;
};

const fetchServerMeta = async () => {
  return await fetchServerJson(getServerStateUrl('?meta=1'), 'No se pudo consultar la version del servidor.');
};

const getKnownLocalRevision = () => lastSharedRevision ?? getCachedServerRevision();

const getRevisionVersion = (revision) => {
  const match = String(revision ?? '').trim().match(/^(\d+)(?::|$)/);
  return match ? Number(match[1]) : null;
};

const isIncomingRevisionNewer = (incomingRevision, currentRevision = getKnownLocalRevision()) => {
  const incomingVersion = getRevisionVersion(incomingRevision);
  const currentVersion = getRevisionVersion(currentRevision);
  if (incomingVersion !== null && currentVersion !== null) {
    return incomingVersion > currentVersion;
  }
  return Boolean(incomingRevision && incomingRevision !== currentRevision);
};

const rememberServerRevision = (revision) => {
  if (!revision) return;
  lastSharedRevision = revision;
  setCachedServerRevision(revision);
  lastSharedSyncAt = Date.now();
  hasLoadedServerState = true;
};

const ensureServerStateReadyForMutation = async ({
  required = true,
  reason = 'mutation-preflight',
  requiredCollections = null,
} = {}) => {
  if (!shouldUseServerState()) {
    return;
  }

  const targeted = Array.isArray(requiredCollections) && requiredCollections.length > 0;
  if (!targeted && !hasLoadedServerState && !hasCachedLocalState()) {
    await syncServerState({ force: true, required, reason });
  }

  if (serverStateIsPartial || targeted) {
    const requestedCollections = Array.isArray(requiredCollections) && requiredCollections.length
      ? requiredCollections
      : PARTIAL_BOOTSTRAP_COLLECTIONS;
    const missingCollections = requestedCollections.filter(
      (name) => !loadedServerCollections.has(name),
    );
    if (missingCollections.length) {
      await fetchServerCollections(missingCollections, `${reason}:load-required-collections`);
    }
  }

  const meta = await fetchServerMeta();
  resetRemoteBackoff();
  const remoteRevision = meta?.revision ?? null;
  const localRevision = getKnownLocalRevision();

  if (remoteRevision && localRevision && remoteRevision === localRevision) {
    lastSharedRevision = remoteRevision;
    setCachedServerRevision(remoteRevision);
    lastSharedSyncAt = Date.now();
    hasLoadedServerState = true;
    return;
  }

  if (targeted) {
    loadedServerCollections.clear();
    serverStateIsPartial = true;
    await fetchServerCollections(requiredCollections, `${reason}:revision-mismatch`);
  } else {
    await syncServerState({ force: true, required, reason: `${reason}:revision-mismatch` });
  }
};

const bytesToBase64 = (bytes) => {
  let binary = '';
  const batchSize = 16 * 1024;
  for (let offset = 0; offset < bytes.length; offset += batchSize) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + batchSize));
  }
  return btoa(binary);
};

const postChunkedStateRequest = async (suffix, payload) => {
  const response = await fetch(getServerStateUrl(`/chunked/${suffix}`), {
    method: 'POST',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo completar el guardado fragmentado.');
  }
  return response.json().catch(() => null);
};

const pushServerStateInChunks = async (state) => {
  const serializedState = JSON.stringify(state);
  const bytes = new TextEncoder().encode(serializedState);
  const totalChunks = Math.ceil(bytes.length / STATE_CHUNK_BYTES);
  const started = await postChunkedStateRequest('start', {
    revision: lastSharedRevision ?? null,
    totalChunks,
    totalBytes: bytes.length,
  });
  const uploadId = started?.uploadId;
  if (!uploadId) {
    throw new Error('El servidor no inicio correctamente el guardado fragmentado.');
  }

  for (let index = 0; index < totalChunks; index += 1) {
    const start = index * STATE_CHUNK_BYTES;
    const chunk = bytes.subarray(start, Math.min(bytes.length, start + STATE_CHUNK_BYTES));
    await postChunkedStateRequest('chunk', {
      uploadId,
      index,
      data: bytesToBase64(chunk),
    });
  }

  return postChunkedStateRequest('commit', { uploadId });
};

const pushServerState = async ({ attempt = 0 } = {}) => {
  if (!shouldUseServerState()) {
    return;
  }

  if (serverStateIsPartial) {
    await ensureServerCollectionsLoaded(PARTIAL_BOOTSTRAP_COLLECTIONS, 'full-save-preflight');
  }
  const state = await exportLocalState();
  if (!state) {
    return;
  }

  const serializedPayload = JSON.stringify({
    state,
    revision: lastSharedRevision ?? null,
  });
  if (!isLocalHost() && new TextEncoder().encode(serializedPayload).length > DIRECT_STATE_SAVE_MAX_BYTES) {
    const payload = await pushServerStateInChunks(state);
    if (payload?.revision) {
      rememberServerRevision(payload.revision);
      localServerCommitSerial += 1;
    }
    return payload;
  }

  const response = await fetch(getServerStateUrl(), {
    method: 'PUT',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: serializedPayload,
  });

  if (response.status === 409) {
    throw await createServerStateError(
      response,
      'Los datos fueron actualizados por otro usuario. Recarga la pagina antes de continuar.',
    );
  }

  if (!response.ok) {
    const error = await createServerStateError(response, 'No se pudo guardar en el servidor.');
    if (isTransientServerError(error) && attempt < SAVE_TRANSIENT_RETRIES) {
      applyRemoteBackoff(error);
      await sleep(getRetryDelayMs(error, attempt));
      return pushServerState({ attempt: attempt + 1 });
    }
    throw error;
  }

  const payload = await response.json().catch(() => null);
  if (payload?.revision) {
    rememberServerRevision(payload.revision);
    localServerCommitSerial += 1;
  }
  return payload;
};

const stableJson = (value) => JSON.stringify(value ?? null);

const buildSettingsPatch = (beforeSettings, afterSettings) => {
  const before = beforeSettings && typeof beforeSettings === 'object' && !Array.isArray(beforeSettings)
    ? beforeSettings
    : {};
  const after = afterSettings && typeof afterSettings === 'object' && !Array.isArray(afterSettings)
    ? afterSettings
    : {};
  const patch = {};

  Object.keys(after).forEach((key) => {
    if (key === 'numbering') {
      const beforeNumbering = before.numbering && typeof before.numbering === 'object' && !Array.isArray(before.numbering)
        ? before.numbering
        : {};
      const afterNumbering = after.numbering && typeof after.numbering === 'object' && !Array.isArray(after.numbering)
        ? after.numbering
        : {};
      const numberingPatch = {};
      Object.keys(afterNumbering).forEach((numberingKey) => {
        if (stableJson(beforeNumbering[numberingKey]) !== stableJson(afterNumbering[numberingKey])) {
          numberingPatch[numberingKey] = afterNumbering[numberingKey];
        }
      });
      if (Object.keys(numberingPatch).length > 0) patch.numbering = numberingPatch;
      return;
    }

    if (key === 'maintenance') {
      // Los marcadores de mantenimiento son internos del runtime y nunca deben
      // viajar como efecto colateral de una mutacion de usuario.
      return;
    }

    if (stableJson(before[key]) !== stableJson(after[key])) {
      patch[key] = after[key];
    }
  });

  return patch;
};

const buildStatePatch = (beforeState, afterState, collections = PATCHABLE_COLLECTIONS, { includeSettings = false } = {}) => {
  if (!beforeState || !afterState) return null;
  const upserts = {};
  const deletes = {};
  let changedRows = 0;

  for (const collection of collections) {
    const beforeRows = Array.isArray(beforeState[collection]) ? beforeState[collection] : [];
    const afterRows = Array.isArray(afterState[collection]) ? afterState[collection] : [];
    const beforeById = new Map();
    const afterIds = new Set();

    for (const row of beforeRows) {
      const id = String(row?.id ?? '').trim();
      if (!id) return null;
      beforeById.set(id, stableJson(row));
    }

    for (const row of afterRows) {
      const id = String(row?.id ?? '').trim();
      if (!id) return null;
      afterIds.add(id);
      if (isSummaryOnlyRow(row)) continue;
      if (beforeById.get(id) !== stableJson(row)) {
        if (!upserts[collection]) upserts[collection] = [];
        upserts[collection].push(row);
        changedRows += 1;
      }
    }

    const removedIds = beforeRows
      .map((row) => String(row?.id ?? '').trim())
      .filter((id) => id && !afterIds.has(id));
    if (removedIds.length > 0) {
      deletes[collection] = removedIds;
      changedRows += removedIds.length;
    }
  }

  const settingsPatch = includeSettings
    ? buildSettingsPatch(beforeState.settings, afterState.settings)
    : {};
  const settingsChanged = Object.keys(settingsPatch).length > 0;
  const patch = {
    upserts,
    deletes,
    ...(settingsChanged ? { settings: settingsPatch } : {}),
  };
  const hasChanges = changedRows > 0 || settingsChanged;
  if (!hasChanges) return { empty: true };
  if (changedRows > PATCH_MAX_CHANGED_ROWS) return null;
  const patchBytes = new TextEncoder().encode(JSON.stringify(patch)).length;
  if (patchBytes > PATCH_MAX_BYTES) return null;
  return patch;
};

const pushServerStatePatch = async ({
  beforeState,
  afterState,
  collections = PATCHABLE_COLLECTIONS,
  includeSettings = false,
  attempt = 0,
} = {}) => {
  if (!shouldUseServerState()) {
    return null;
  }

  const patch = buildStatePatch(beforeState, afterState, collections, { includeSettings });
  if (patch?.empty) {
    return null;
  }
  if (!patch) {
    return pushServerState({ attempt });
  }

  const response = await fetch(getServerStateUrl('/patch'), {
    method: 'POST',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({
      revision: lastSharedRevision ?? null,
      ...patch,
    }),
  });

  if (response.status === 404 || response.status === 405) {
    return pushServerState({ attempt });
  }

  if (response.status === 409) {
    const error = await createServerStateError(
      response,
      'Los datos fueron actualizados por otro usuario. Recarga la pagina antes de continuar.',
    );
    if (isRevisionConflictError(error) && attempt < MUTATION_CONFLICT_RETRIES) {
      const meta = await fetchServerMeta();
      if (meta?.revision) {
        rememberServerRevision(meta.revision);
      }
      await sleep(getRetryDelayMs(error, attempt));
      return pushServerStatePatch({ beforeState, afterState, collections, includeSettings, attempt: attempt + 1 });
    }
    throw error;
  }

  if (!response.ok) {
    const error = await createServerStateError(response, 'No se pudo guardar el cambio en el servidor.');
    if (isTransientServerError(error) && attempt < SAVE_TRANSIENT_RETRIES) {
      applyRemoteBackoff(error);
      await sleep(getRetryDelayMs(error, attempt));
      return pushServerStatePatch({ beforeState, afterState, collections, includeSettings, attempt: attempt + 1 });
    }
    throw error;
  }

  const payload = await response.json().catch(() => null);
  if (payload?.revision) {
    rememberServerRevision(payload.revision);
    localServerCommitSerial += 1;
  }
  return payload;
};

const fetchServerPresence = async () => {
  const response = await fetch(getServerStateUrl('/presence'), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });

  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo leer las sesiones activas.');
  }

  return response.json();
};

const postServerPresence = async (action, payload) => {
  const response = await fetch(getServerStateUrl(`/presence/${action}`), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload ?? {}),
  });

  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo actualizar las sesiones activas.');
  }

  return response.json();
};

const fetchServerUpdateNotice = async () => {
  const response = await fetch(getServerStateUrl('/update-notice'), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });

  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo leer el aviso de actualizacion.');
  }

  return response.json();
};

const postServerUpdateNotice = async (action, payload) => {
  const response = await fetch(getServerStateUrl(`/update-notice/${action}`), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload ?? {}),
  });

  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo publicar el aviso de actualizacion.');
  }

  const result = await response.json();
  announceDataChange({ domain: 'presence', method: `updateNotice.${action}` });
  return result;
};

const uploadProductImage = async (file, { itemId } = {}) => {
  if (!(file instanceof File)) {
    throw new Error('Selecciona una imagen valida para subir.');
  }
  const response = await fetch(getApiUrl('/api/uploads/products'), {
    method: 'POST',
    headers: getInternalHeaders({
      'Content-Type': file.type || 'application/octet-stream',
      'X-Product-Id': String(itemId ?? 'product').trim() || 'product',
    }),
    body: file,
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo subir la imagen del producto.');
  }
  return response.json();
};


const uploadEconomicReceiptImage = async (file, {
  contractId,
  ledgerEntryId,
  userId = '',
  userName = '',
} = {}) => {
  if (!(file instanceof File)) {
    throw new Error('Selecciona una imagen valida para subir.');
  }
  const safeContractId = String(contractId ?? '').trim();
  const safeLedgerEntryId = String(ledgerEntryId ?? '').trim();
  if (!safeContractId || !safeLedgerEntryId) {
    throw new Error('No se pudo identificar la linea economica para adjuntar el comprobante.');
  }
  const response = await fetch(getApiUrl('/api/uploads/economic-receipts'), {
    method: 'POST',
    headers: getInternalHeaders({
      'Content-Type': file.type || 'application/octet-stream',
      'X-Contract-Id': safeContractId,
      'X-Economic-Ledger-Id': safeLedgerEntryId,
      'X-Original-Filename': encodeURIComponent(String(file.name ?? 'comprobante')),
      'X-User-Id': String(userId ?? '').trim(),
      'X-User-Name': encodeURIComponent(String(userName ?? '').trim()),
    }),
    body: file,
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo adjuntar el comprobante.');
  }
  const result = await response.json();
  if (result?.revision) rememberServerRevision(result.revision);
  forgetFullRecordCache(fullContractCache, [safeContractId, result?.contract?.id]);
  markServerStateStale('contracts.economicReceiptImage:upload');
  announceDataChange({ domain: 'contracts', method: 'economicReceiptImage.upload' });
  return result;
};

const deleteEconomicReceiptImage = async ({
  contractId,
  ledgerEntryId,
  userId = '',
  userName = '',
} = {}) => {
  const safeContractId = String(contractId ?? '').trim();
  const safeLedgerEntryId = String(ledgerEntryId ?? '').trim();
  if (!safeContractId || !safeLedgerEntryId) {
    throw new Error('No se pudo identificar la linea economica del comprobante.');
  }
  const query = new URLSearchParams({
    userId: String(userId ?? '').trim(),
    userName: String(userName ?? '').trim(),
  });
  const response = await fetch(
    getApiUrl(`/api/uploads/economic-receipts/${encodeURIComponent(safeContractId)}/${encodeURIComponent(safeLedgerEntryId)}?${query.toString()}`),
    {
      method: 'DELETE',
      cache: 'no-store',
      headers: getInternalHeaders(),
    },
  );
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo quitar el comprobante.');
  }
  const result = await response.json();
  if (result?.revision) rememberServerRevision(result.revision);
  forgetFullRecordCache(fullContractCache, [safeContractId, result?.contract?.id]);
  markServerStateStale('contracts.economicReceiptImage:delete');
  announceDataChange({ domain: 'contracts', method: 'economicReceiptImage.delete' });
  return result;
};

const uploadLincolnRoomImage = async (file, { roomId } = {}) => {
  if (!(file instanceof File)) throw new Error('Selecciona una imagen válida para el salón.');
  const response = await fetch(getApiUrl('/api/uploads/lincoln/rooms'), {
    method: 'POST',
    headers: getInternalHeaders({
      'Content-Type': file.type || 'application/octet-stream',
      'X-Lincoln-Room-Id': String(roomId ?? 'room').trim() || 'room',
    }),
    body: file,
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo subir la imagen del salón.');
  return response.json();
};

const deleteLincolnRoomImage = async ({ filename } = {}) => {
  const safeFilename = String(filename ?? '').trim();
  if (!safeFilename) return { ok: true };
  const response = await fetch(getApiUrl(`/api/uploads/lincoln/rooms/${encodeURIComponent(safeFilename)}`), {
    method: 'DELETE',
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo eliminar la imagen del salón.');
  return response.json();
};

const uploadLincolnPackageImage = async (file, { packageId } = {}) => {
  if (!(file instanceof File)) throw new Error('Selecciona una imagen válida para el paquete.');
  const response = await fetch(getApiUrl('/api/uploads/lincoln/packages'), {
    method: 'POST',
    headers: getInternalHeaders({
      'Content-Type': file.type || 'application/octet-stream',
      'X-Lincoln-Package-Id': String(packageId ?? 'package').trim() || 'package',
    }),
    body: file,
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo subir la imagen del paquete.');
  return response.json();
};

const deleteLincolnPackageImage = async ({ filename } = {}) => {
  const safeFilename = String(filename ?? '').trim();
  if (!safeFilename) return { ok: true };
  const response = await fetch(getApiUrl(`/api/uploads/lincoln/packages/${encodeURIComponent(safeFilename)}`), {
    method: 'DELETE',
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo eliminar la imagen del paquete.');
  return response.json();
};


const uploadAttendancePhoto = async (file, { recordId } = {}) => {
  if (!(file instanceof Blob)) {
    throw new Error('Selecciona una foto valida para subir.');
  }
  const response = await fetch(getApiUrl('/api/uploads/attendance'), {
    method: 'POST',
    headers: getInternalHeaders({
      'Content-Type': file.type || 'application/octet-stream',
      'X-Attendance-Id': String(recordId ?? 'attendance').trim() || 'attendance',
    }),
    body: file,
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo subir la foto de asistencia.');
  }
  return response.json();
};

const callServerPresence = async (action, payload) => {
  if (!shouldUseServerState() || isLocalHost() || remotePresenceUnsupported) {
    return null;
  }

  try {
    if (action === 'listActive') {
      return await fetchServerPresence();
    }

    const result = await postServerPresence(action, payload);
    announceDataChange({ domain: 'presence', method: action });
    return action === 'leave' ? result?.active ?? [] : result;
  } catch (error) {
    if (error?.status === 404 || error?.status === 405) {
      remotePresenceUnsupported = true;
      return null;
    }
    applyRemoteBackoff(error);
    if (isLocalHost()) {
      return null;
    }
    throw error;
  }
};

const syncServerState = async ({ force = false, required = false, reason = 'sync', preferCache = false, notifyWhenUpdated = false } = {}) => {
  if (!shouldUseServerState()) {
    return;
  }

  const now = Date.now();
  if (required && sharedSyncPromise) {
    await sharedSyncPromise.catch(() => {});
  }
  if (sharedSyncPromise) {
    console.info(`[copetin-sync] Reutilizando carga en curso de ${SERVER_STATE_ENDPOINT}`, { reason });
    return sharedSyncPromise;
  }
  if (!force && hasLoadedServerState) {
    return;
  }
  if (!force && now - lastSharedSyncAt < SYNC_THROTTLE_MS) {
    return;
  }
  if (!force && preferCache && hasCachedLocalState() && !serverStateIsPartial) {
    lastSharedRevision = getCachedServerRevision();
    lastSharedSyncAt = now;
    hasLoadedServerState = true;
    window.setTimeout(() => {
      syncServerState({
        force: true,
        required: false,
        reason: `${reason}:background-refresh`,
        notifyWhenUpdated: true,
      }).catch((error) => {
        applyRemoteBackoff(error);
        console.warn('[copetin-sync] No se pudo refrescar la cache en segundo plano.', error);
      });
    }, 0);
    return;
  }

  sharedSyncPromise = (async () => {
  try {
    if (!force && hasCachedLocalState() && !serverStateIsPartial) {
      const meta = await fetchServerMeta();
      const remoteRevision = meta?.revision ?? null;
      const cachedRevision = getCachedServerRevision();
      if (remoteRevision && cachedRevision && remoteRevision === cachedRevision) {
        resetRemoteBackoff();
        lastSharedRevision = remoteRevision;
        lastSharedSyncAt = Date.now();
        hasLoadedServerState = true;
        return;
      }
    }

    const payload = await fetchServerState(reason, { bootstrap: true });
    resetRemoteBackoff();
    if (payload?.initialized && payload.state) {
      const previousRevision = lastSharedRevision ?? getCachedServerRevision();
      await replaceLocalState(payload.state);
      loadedServerCollections.clear();
      const excludedCollections = Array.isArray(payload.excludedCollections) ? payload.excludedCollections : [];
      const summarizedCollections = Array.isArray(payload.summarizedCollections) ? payload.summarizedCollections : [];
      Object.keys(payload.state).forEach((name) => {
        if (!excludedCollections.includes(name) && !summarizedCollections.includes(name)) {
          loadedServerCollections.add(name);
        }
      });
      serverStateIsPartial = Boolean(
        payload.partial && (excludedCollections.length || summarizedCollections.length),
      );
      if (payload.revision) {
        lastSharedRevision = payload.revision;
        setCachedServerRevision(payload.revision);
      }
      lastSharedSyncAt = Date.now();
      hasLoadedServerState = true;
      if (notifyWhenUpdated && payload.revision && payload.revision !== previousRevision) {
        notifySubscribers({ source: 'background-sync', reason, revision: payload.revision });
      }
      return;
    }

    const localState = await exportLocalState();
    if (hasBusinessData(localState)) {
      await pushServerState();
    }
    lastSharedSyncAt = Date.now();
    hasLoadedServerState = true;
  } catch (error) {
    applyRemoteBackoff(error);
    if (required) {
      throw error;
    }
    // In local/offline runs the endpoint may not exist.
    // The app can keep working with browser storage in that case.
    console.warn(error);
  } finally {
    sharedSyncPromise = null;
  }
  })();

  return sharedSyncPromise;
};

const notifySubscribers = (payload) => {
  syncSubscribers.forEach((callback) => {
    try {
      callback(payload);
    } catch (error) {
      console.warn(error);
    }
  });
};

const markServerStateStale = (reason) => {
  hasLoadedServerState = false;
  lastSharedSyncAt = 0;
  console.info(`[copetin-sync] Estado local marcado como pendiente de sincronizacion`, { reason });
};

const announceDataChange = ({ domain, method, collections = null }) => {
  const payload = {
    source: browserTabId,
    origin: 'local-mutation',
    domain,
    method,
    revision: domain === 'presence' ? null : lastSharedRevision,
    collections: Array.isArray(collections) ? collections : null,
    at: new Date().toISOString(),
  };

  if (syncChannel) {
    syncChannel.postMessage(payload);
  }
};

const normalizeForMutationKey = (value) => {
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (Array.isArray(value)) {
    return value.map(normalizeForMutationKey);
  }
  if (value && typeof value === 'object') {
    return Object.keys(value)
      .sort()
      .reduce((accumulator, key) => {
        const normalized = normalizeForMutationKey(value[key]);
        if (typeof normalized !== 'undefined') {
          accumulator[key] = normalized;
        }
        return accumulator;
      }, {});
  }
  return value;
};

const getMutationKey = (domain, method, args) =>
  `${domain}.${method}:${JSON.stringify(normalizeForMutationKey(args))}`;

const enqueueMutation = (operation) => {
  const request = mutationQueue.then(operation, operation);
  mutationQueue = request.catch(() => {});
  return request;
};

const runBatchedMutations = async (operation, options = {}) => {
  const isOuterBatch = mutationBatchDepth === 0;
  mutationBatchDepth += 1;
  try {
    if (isOuterBatch) {
      mutationBatchCollections = [...new Set(
        (Array.isArray(options?.collections) && options.collections.length
          ? options.collections
          : PATCHABLE_COLLECTIONS)
          .filter((name) => PATCHABLE_COLLECTIONS.includes(name)),
      )];
      mutationBatchPreflightPromise = ensureServerStateReadyForMutation({
        required: true,
        reason: options?.reason || 'batch.mutation-preflight',
        requiredCollections: mutationBatchCollections,
      });
      await mutationBatchPreflightPromise;
      mutationBatchBeforeState = await exportLocalCollections(mutationBatchCollections);
    }

    const result = await operation();
    if (isOuterBatch && mutationBatchDirty) {
      const afterState = await exportLocalCollections(mutationBatchCollections);
      await pushServerStatePatch({
        beforeState: mutationBatchBeforeState,
        afterState,
        collections: mutationBatchCollections,
      });
      announceDataChange({ domain: 'batch', method: 'commit', collections: mutationBatchCollections });
      mutationBatchDirty = false;
    }
    return result;
  } catch (error) {
    if (isOuterBatch) mutationBatchDirty = false;
    throw error;
  } finally {
    mutationBatchDepth = Math.max(0, mutationBatchDepth - 1);
    if (mutationBatchDepth === 0) {
      mutationBatchPreflightPromise = null;
      mutationBatchDirty = false;
      mutationBatchCollections = null;
      mutationBatchBeforeState = null;
    }
  }
};

const mergeTransactionChangesIntoLocalState = async (changes = {}) => {
  const bridge = getBridge();
  const collectionNames = Object.keys(changes).filter((name) => Array.isArray(changes[name]));
  if (!collectionNames.length) return;
  const current = await bridge.__storage.exportCollections(collectionNames);
  const partialState = {};

  collectionNames.forEach((name) => {
    const existingRows = Array.isArray(current?.[name]) ? current[name] : [];
    const nextRows = [...existingRows];
    const indexById = new Map(nextRows.map((row, index) => [String(row?.id ?? ''), index]));
    changes[name].forEach((row) => {
      if (!row || row._summaryOnly) return;
      const id = String(row?.id ?? '').trim();
      if (!id) return;
      const currentIndex = indexById.get(id);
      if (currentIndex === undefined) {
        indexById.set(id, nextRows.length);
        nextRows.unshift(row);
      } else {
        nextRows[currentIndex] = row;
      }
    });
    partialState[name] = nextRows;
  });

  await bridge.__storage.mergeState(partialState);
};

const createSupplierOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) {
    return callBridge('suppliers', 'create', true, payload);
  }

  const response = await fetch(getServerStateUrl('/suppliers/create'), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo crear el proveedor.');
  }

  const result = await response.json();
  const supplier = result?.supplier ?? null;
  if (!supplier?.id) {
    throw new Error('El servidor no devolvió el proveedor creado.');
  }

  if (result?.revision) {
    rememberServerRevision(result.revision);
    localServerCommitSerial += 1;
  }

  // El controlador incorpora el proveedor confirmado a React inmediatamente.
  // No reconstruimos ni persistimos toda la base en el navegador.
  announceDataChange({
    domain: 'suppliers',
    method: 'create',
    collections: ['suppliers'],
  });

  return supplier;
};

const createAndApproveContractOnServer = async ({ contract, contractId, trace } = {}) => {
  if (!shouldUseServerState()) {
    throw new Error('La aprobacion transaccional requiere conexion con el servidor.');
  }
  if (!contractId && (!contract || contract._summaryOnly)) {
    throw new Error('No se puede aprobar un contrato incompleto o resumido.');
  }

  const meta = await fetchServerMeta();
  const revision = meta?.revision ?? getKnownLocalRevision();
  const response = await fetch(getServerStateUrl(contractId
    ? `/contracts/${encodeURIComponent(contractId)}/approve`
    : '/contracts/create-and-approve'), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ contract, trace, revision }),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo crear y aprobar el contrato.');
  }
  const payload = await response.json();
  if (!payload?.contract?.id || !payload?.rental?.id || payload.contract.rentalId !== payload.rental.id) {
    throw new Error('El servidor no confirmo la orden de servicio vinculada.');
  }
  // React recibe las filas confirmadas directamente; no serializar toda la base
  // del navegador antes de cerrar la aprobacion.
  markServerStateStale('contracts.approve');
  if (payload?.revision) {
    rememberServerRevision(payload.revision);
    localServerCommitSerial += 1;
  }
  announceDataChange({
    domain: 'contracts',
    method: 'create-and-approve',
    collections: Object.keys(payload?.changes ?? {}),
  });
  return payload;
};

const updateContractOnServer = async (contract = {}) => {
  if (!shouldUseServerState()) {
    return callBridge('contracts', 'update', true, contract);
  }
  const requestedId = String(contract?.id ?? '').trim();
  if (!requestedId) throw new Error('Debes indicar el contrato que deseas actualizar.');
  const knownRevision = getKnownLocalRevision();
  const revision = knownRevision || (await fetchServerMeta())?.revision || null;

  const response = await fetch(getServerStateUrl(`/contracts/${encodeURIComponent(requestedId)}/update`), {
    method: 'PUT',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({
      contract,
      revision,
    }),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo actualizar el contrato.');
  }

  const result = await response.json();
  if (!result?.contract?.id) {
    throw new Error('El servidor no devolvio el contrato actualizado.');
  }
  await mergeTransactionChangesIntoLocalState(result?.changes ?? {});
  if (result?.revision) {
    rememberServerRevision(result.revision);
    localServerCommitSerial += 1;
  }
  announceDataChange({
    domain: 'contracts',
    method: 'update',
    collections: Object.keys(result?.changes ?? {}),
  });
  return result.contract;
};

const removeContractOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) {
    return callBridge('contracts', 'remove', true, payload);
  }
  const requestedId = String(payload?.id ?? '').trim();
  if (!requestedId) throw new Error('Debes indicar el contrato que deseas eliminar.');
  const knownRevision = getKnownLocalRevision();
  const revision = knownRevision || (await fetchServerMeta())?.revision || null;
  const trace = {
    updatedById: payload?.updatedById ?? payload?.userId ?? null,
    updatedByName: payload?.updatedByName ?? payload?.userName ?? 'Sistema',
    updatedByRole: payload?.updatedByRole ?? payload?.userRole ?? 'Sistema',
  };

  const response = await fetch(getServerStateUrl(`/contracts/${encodeURIComponent(requestedId)}/remove`), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ trace, revision }),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo eliminar el contrato anulado.');
  }

  const result = await response.json();
  if (!result?.contract?.id || !result?.safety?.inventoryUnchanged) {
    throw new Error('El servidor no confirmo una eliminacion segura del contrato.');
  }
  await mergeTransactionChangesIntoLocalState(result?.changes ?? {});
  if (result?.revision) {
    rememberServerRevision(result.revision);
    localServerCommitSerial += 1;
  }
  announceDataChange({
    domain: 'contracts',
    method: 'remove',
    collections: Object.keys(result?.changes ?? {}),
  });
  return result.contract;
};

const pollRemoteRevision = async () => {
  if (!shouldUseServerState() || syncSubscribers.size === 0 || remotePollInFlight) return;
  if (document.visibilityState === 'hidden') return;

  const now = Date.now();
  if (remotePollBackoffUntil && now < remotePollBackoffUntil) return;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  if (now - lastRemotePollAt < REMOTE_POLL_MS) return;
  lastRemotePollAt = now;
  remotePollInFlight = true;

  const commitSerialAtStart = localServerCommitSerial;
  try {
    const meta = await fetchServerMeta();
    resetRemoteBackoff();

    // Una mutacion local pudo terminar mientras este GET meta estaba en vuelo.
    // En ese caso la respuesta puede representar una revision anterior y no
    // debe provocar un bootstrap completo.
    if (commitSerialAtStart !== localServerCommitSerial) return;

    const remoteRevision = meta?.revision ?? null;
    if (!remoteRevision) return;
    const localRevision = getKnownLocalRevision();
    if (!localRevision) {
      rememberServerRevision(remoteRevision);
      return;
    }
    if (isIncomingRevisionNewer(remoteRevision, localRevision)) {
      if (moduleScopedSyncSubscribers.size > 0) {
        // Personal reads its own endpoint. Defer the global snapshot until a
        // module that actually needs it is opened.
        markServerStateStale('remote-revision');
        loadedServerCollections.clear();
        serverStateIsPartial = true;
        lastSharedRevision = remoteRevision;
        setCachedServerRevision(remoteRevision);
      } else {
        await syncServerState({ force: true, reason: 'remote-revision' });
      }
      notifySubscribers({ source: 'remote', reason: 'remote-revision', revision: remoteRevision });
    }
  } catch (error) {
    applyRemoteBackoff(error);
    // Production can temporarily throttle polling when several users share IP.
  } finally {
    remotePollInFlight = false;
  }
};

const startSyncPoll = () => {
  if (typeof window === 'undefined' || syncPollTimer) return;
  syncPollTimer = window.setInterval(pollRemoteRevision, REMOTE_POLL_TICK_MS);
};

const ensureSyncListeners = () => {
  if (syncListenersReady || typeof window === 'undefined') return;
  syncListenersReady = true;

  if ('BroadcastChannel' in window) {
    syncChannel = new BroadcastChannel(SYNC_CHANNEL_NAME);
    syncChannel.onmessage = (event) => {
      const payload = event.data;
      if (!payload || payload.source === browserTabId) return;

      // La presencia de otra pestana nunca representa un cambio de base.
      // Antes podia devolver lastSharedRevision a una version antigua y hacer
      // que la siguiente aprobacion descargara todo el bootstrap.
      if (payload.domain === 'presence') {
        notifySubscribers({ ...payload, reason: 'broadcast' });
        return;
      }

      // Ignora anuncios atrasados o duplicados. Solo una revision realmente
      // posterior puede marcar el estado comercial como desactualizado.
      if (payload.revision && !isIncomingRevisionNewer(payload.revision)) {
        return;
      }

      markServerStateStale('broadcast');
      loadedServerCollections.clear();
      serverStateIsPartial = true;
      notifySubscribers({ ...payload, reason: 'broadcast' });
    };
  } else {
    window.addEventListener('storage', (event) => {
      if (event.key !== WEB_DB_STORAGE_KEY) return;
      markServerStateStale('storage');
      loadedServerCollections.clear();
      serverStateIsPartial = true;
      notifySubscribers({ source: 'storage', reason: 'storage' });
    });
  }

  startSyncPoll();
  document.addEventListener('visibilitychange', pollRemoteRevision);
};

const moduleScopedSyncSubscribers = new Set();
const subscribeToDataChanges = (callback, { moduleScoped = false } = {}) => {
  ensureSyncListeners();
  startSyncPoll();
  syncSubscribers.add(callback);
  if (moduleScoped) moduleScopedSyncSubscribers.add(callback);
  return () => {
    syncSubscribers.delete(callback);
    moduleScopedSyncSubscribers.delete(callback);
    if (syncSubscribers.size === 0 && syncPollTimer) {
      window.clearInterval(syncPollTimer);
      syncPollTimer = null;
    }
  };
};

const getTargetedMutationCollections = (domain, method) => {
  if (domain === 'cash') {
    if (['createDebt', 'payDebt', 'deleteDebt'].includes(method)) {
      return CASH_DEBT_PATCH_COLLECTIONS;
    }
    if (method === 'voidAndReplaceMovementReceipt') {
      return ['cashSessions', 'cashMovements'];
    }
    return CASH_MOVEMENT_PATCH_COLLECTIONS;
  }
  if (domain === 'settings' && method === 'update') {
    // Settings se persiste como un parche dedicado; no necesita arrastrar
    // colecciones comerciales ni inventario.
    return [];
  }
  if (domain === 'inventory') {
    if (method === 'processRecovery') return INVENTORY_RECOVERY_PATCH_COLLECTIONS;
    if (method === 'createMovement') return INVENTORY_MOVEMENT_PATCH_COLLECTIONS;
    if (['create', 'update', 'remove'].includes(method)) return INVENTORY_ITEM_PATCH_COLLECTIONS;
    if (['createCombo', 'updateCombo', 'removeCombo'].includes(method)) return INVENTORY_COMBO_PATCH_COLLECTIONS;
  }
  if (domain === 'users' && ['create', 'update', 'remove', 'resendInvite'].includes(method)) {
    return USER_PATCH_COLLECTIONS;
  }
  if (domain === 'rentals' && method === 'updateOperational') {
    return RENTAL_OPERATIONAL_PATCH_COLLECTIONS;
  }
  if (domain === 'rentals' && method === 'registerReturn') {
    return RENTAL_RETURN_PATCH_COLLECTIONS;
  }
  if (domain === 'rentals' && method === 'cancel') {
    return RENTAL_CANCEL_PATCH_COLLECTIONS;
  }
  if (domain === 'quotes' && ['create', 'update', 'remove'].includes(method)) {
    return QUOTE_MUTATION_PATCH_COLLECTIONS;
  }
  if (domain !== 'contracts') return null;
  if (method === 'create') return CONTRACT_CREATE_PATCH_COLLECTIONS;
  if (method === 'update') return CONTRACT_UPDATE_PATCH_COLLECTIONS;
  if (method === 'remove') return CONTRACT_REMOVE_PATCH_COLLECTIONS;
  return null;
};

// El preflight solo carga las colecciones necesarias para validar la operación.
// Las colecciones del patch pueden ser más amplias, por ejemplo para agregar
// una entrada de auditoría sin descargar previamente todo el historial.
const getMutationPreflightCollections = (domain, method, targetedCollections) => {
  if (domain === 'contracts' && method === 'update') {
    // Para editar un contrato solo necesitamos cargar los registros comerciales
    // y operativos que participan realmente en la validacion. Los historiales
    // pesados se incluyen en el patch final cuando cambian, pero no se descargan
    // completos antes de guardar.
    return [
      'contracts',
      'rentals',
      'items',
      'deliveries',
      'transportRoutes',
      'calendarEvents',
    ];
  }
  if (domain === 'contracts' && method === 'remove') {
    return [
      'contracts',
      'rentals',
      'inventoryMovements',
    ];
  }
  if (domain === 'inventory' && ['create', 'update'].includes(method)) {
    // Crear o editar valida la categoria dentro del bridge. Si solo precargamos
    // items, el selector puede mostrar categorias inferidas del inventario pero
    // la mutacion recibe state.categories vacio y rechaza una categoria real.
    return ['items', 'categories'];
  }
  if (domain === 'inventory' && method === 'remove') {
    return ['items'];
  }
  if (domain === 'inventory' && ['createCombo', 'updateCombo', 'removeCombo'].includes(method)) {
    return ['inventoryCombos', 'items'];
  }
  return targetedCollections;
};

const callBridge = async (domain, method, mutates, ...args) => {
  const mutationKey = mutates ? getMutationKey(domain, method, args) : '';
  const isPresenceMutation = domain === 'presence';
  const targetedCollections = mutates ? getTargetedMutationCollections(domain, method) : null;
  const preflightCollections = mutates
    ? getMutationPreflightCollections(domain, method, targetedCollections)
    : null;
  if (mutationKey && inFlightMutations.has(mutationKey)) {
    return inFlightMutations.get(mutationKey);
  }

  const request = (async () => {
    const runMutationAttempt = async (attempt = 0) => {
      try {
        if (!isPresenceMutation) {
          if (mutationBatchDepth > 0) {
            if (!mutationBatchPreflightPromise) {
              mutationBatchPreflightPromise = ensureServerStateReadyForMutation({
                required: true,
                reason: `batch.${domain}.${method}:mutation-preflight`,
                requiredCollections: preflightCollections,
              });
            }
            await mutationBatchPreflightPromise;
          } else {
            await ensureServerStateReadyForMutation({
              required: true,
              reason: `${domain}.${method}:mutation-preflight`,
              requiredCollections: preflightCollections,
            });
          }
        }
      } catch (error) {
        if (isTransientServerError(error) && attempt < MUTATION_TRANSIENT_RETRIES) {
          await sleep(getRetryDelayMs(error, attempt));
          return runMutationAttempt(attempt + 1);
        }
        throw new Error(getSaveErrorMessage(error, 'No se pudo sincronizar la informacion antes de guardar.'));
      }

      const beforeMutationState = !isPresenceMutation && mutationBatchDepth === 0
        ? (targetedCollections
          ? await exportLocalCollections(targetedCollections)
          : await exportLocalState())
        : null;
      const result = await getBridge()[domain][method](...args);
      if (isPresenceMutation) {
        announceDataChange({ domain, method, collections: targetedCollections });
        return result;
      }
      if (mutationBatchDepth > 0) {
        mutationBatchDirty = true;
        return result;
      }
      try {
        const afterMutationState = beforeMutationState
          ? (targetedCollections
            ? await exportLocalCollections(targetedCollections)
            : await exportLocalState())
          : null;
        await pushServerStatePatch({
          beforeState: beforeMutationState,
          afterState: afterMutationState,
          collections: targetedCollections ?? PATCHABLE_COLLECTIONS,
          includeSettings: domain === 'settings' && method === 'update',
        });
        announceDataChange({ domain, method, collections: targetedCollections });
        return result;
      } catch (error) {
        if (isPresenceMutation) {
          applyRemoteBackoff(error);
        if (isRevisionConflictError(error)) {
          await syncServerState({ force: true, reason: `${domain}.${method}:presence-conflict` });
        }
          return result;
        }

        if (isRevisionConflictError(error) && attempt < MUTATION_CONFLICT_RETRIES) {
          await syncServerState({
            force: true,
            required: true,
            reason: `${domain}.${method}:revision-conflict`,
          });
          const collectionsToReload = targetedCollections ?? PARTIAL_BOOTSTRAP_COLLECTIONS;
          await ensureServerCollectionsLoaded(collectionsToReload, `${domain}.${method}:revision-conflict`);
          await sleep(getRetryDelayMs(error, attempt));
          return runMutationAttempt(attempt + 1);
        }

        if (isTransientServerError(error) && attempt < MUTATION_TRANSIENT_RETRIES) {
          await sleep(getRetryDelayMs(error, attempt));
          return runMutationAttempt(attempt + 1);
        }

        throw new Error(getSaveErrorMessage(error, 'No se pudo guardar en el servidor.'));
      }
    };

    if (mutates) {
      return enqueueMutation(() => runMutationAttempt());
    }

    await syncServerState({ force: false, reason: `${domain}.${method}` });
    const result = await getBridge()[domain][method](...args);
    return result;
  })();

  if (mutationKey) {
    inFlightMutations.set(mutationKey, request);
    request.then(
      () => inFlightMutations.delete(mutationKey),
      () => inFlightMutations.delete(mutationKey),
    );
  }

  return request;
};



const callDirectInventoryItemRemove = async (payload = {}) => {
  if (!shouldUseServerState()) return callBridge('inventory', 'remove', true, payload);
  const itemId = String(payload?.id ?? '').trim();
  if (!itemId) throw new Error('Debes indicar el producto que deseas eliminar.');
  const response = await fetch(getServerStateUrl(`/inventory/items/${encodeURIComponent(itemId)}/remove`), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo eliminar el producto.');
  const result = await response.json();
  if (result?.revision) {
    rememberServerRevision(result.revision);
    localServerCommitSerial += 1;
  }
  await fetchServerCollections(['items'], 'inventory.remove:confirmed');
  announceDataChange({ domain: 'inventory', method: 'remove', collections: ['items', 'systemAuditLog'] });
  return result?.item ?? { id: itemId };
};

const callDirectCashOperation = async (path, payload = {}) => {
  if (!shouldUseServerState()) return null;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 25000);
  try {
    const clientOperationId = String(payload?.clientOperationId ?? '').trim()
      || (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `cash-${Date.now()}-${Math.random().toString(16).slice(2)}`);
    const response = await fetch(getServerStateUrl(path), {
      method: 'POST', cache: 'no-store', signal: controller.signal,
      headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ ...payload, clientOperationId }),
    });
    if (!response.ok) throw await createServerStateError(response, 'No se pudo registrar la operacion de caja.');
    const result = await response.json();
    if (Object.prototype.hasOwnProperty.call(result ?? {}, 'revision')) {
      lastSharedRevision = result.revision; setCachedServerRevision(result.revision);
    }
    if (path === '/cash/movement') {
      await applyDirectCashResultLocally(result);
    }
    const method = path.includes('update-receipt')
      ? 'updateMovementReceipt'
      : path.includes('collect')
        ? 'collectReceivable'
        : 'createManualMovement';
    announceDataChange({ domain: 'cash', method });
    return result;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('El servidor tardo demasiado en confirmar la operacion. No la repitas: vuelve a abrir el contrato para verificar el recibo.');
    throw error;
  } finally { clearTimeout(timeoutId); }
};


const applyDirectCashResultLocally = async (result = {}) => {
  const createdRows = Array.isArray(result?.movements)
    ? result.movements
    : result?.movement
      ? [result.movement]
      : [];
  if (!createdRows.length) return;

  const local = await exportLocalCollections(['cashMovements', 'cashSessions']);
  const currentRows = Array.isArray(local?.cashMovements) ? local.cashMovements : [];
  const byId = new Map(currentRows.map((row) => [String(row?.id ?? ''), row]));
  createdRows.forEach((row) => {
    const id = String(row?.id ?? '').trim();
    if (id) byId.set(id, row);
  });
  await mergeLocalState({ cashMovements: [...byId.values()] });
  loadedServerCollections.add('cashMovements');
  localServerCommitSerial += 1;
};

const getPersonnelOverview = async (params = {}) => {
  if (!shouldUseServerState()) {
    const bundle = await callBridge('personnel', 'listBundle', false);
    return buildPersonnelOverview({ personnelEmployees: bundle.employees, personnelAttendance: bundle.attendance, personnelIncidents: bundle.incidents }, params);
  }
  const response = await fetch(getServerStateUrl('/personnel/overview?' + new URLSearchParams(params)), {
    cache: 'no-store', headers: getInternalHeaders(),
  });
  if (!response.ok) throw await createServerStateError(response, 'No se pudo cargar Personal.');
  return response.json();
};

const mutatePersonnelOnServer = (method, payload) => {
  if (!shouldUseServerState()) return callBridge('personnel', method, true, payload);
  return enqueueMutation(async () => {
    const response = await fetch(getServerStateUrl('/personnel/' + method), {
      method: 'POST', headers: getInternalHeaders({ 'Content-Type': 'application/json' }), body: JSON.stringify(payload),
    });
    if (!response.ok) throw await createServerStateError(response, 'No se pudo guardar Personal.');
    const result = await response.json();
    markServerStateStale('personnel.' + method);
    if (result?.revision) {
      rememberServerRevision(result.revision);
      localServerCommitSerial += 1;
    }
    ['personnelEmployees', 'personnelAttendance', 'personnelIncidents'].forEach((name) => loadedServerCollections.delete(name));
    announceDataChange({ domain: 'personnel', method, collections: ['personnelEmployees', 'personnelAttendance', 'personnelIncidents'] });
    return result.record;
  });
};

const getPersonnelOptionsFromServer = async ({ query = '', limit = 20 } = {}) => {
  if (!shouldUseServerState()) {
    const bundle = await callBridge('personnel', 'listBundle', false);
    const normalized = String(query ?? '').trim().toLowerCase();
    const employees = (Array.isArray(bundle?.employees) ? bundle.employees : [])
      .filter((employee) => !employee?.deletedAt && String(employee?.status ?? 'active').toLowerCase() !== 'inactive')
      .filter((employee) => !normalized || [
        employee?.fullName,
        employee?.documentId,
        employee?.employeeCode,
        employee?.position,
        employee?.department,
      ].some((value) => String(value ?? '').toLowerCase().includes(normalized)))
      .slice(0, limit);
    return { employees, total: employees.length };
  }
  const params = new URLSearchParams({
    query: String(query ?? ''),
    limit: String(Math.min(30, Math.max(5, Number(limit) || 20))),
  });
  const response = await fetch(getServerStateUrl(`/personnel/options?${params.toString()}`), {
    cache: 'no-store',
    headers: getInternalHeaders(),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo cargar el personal disponible.');
  }
  const result = await response.json();
  if (result?.revision) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
  }
  return result;
};

const shouldFallbackToBridgeOperation = (error) => error?.status === 404 || error?.status === 405;

const callDirectDamageRepairReinsert = async (payload = {}) => {
  if (!shouldUseServerState()) throw new Error('La reinsercion de daños reparados requiere conexion con el servidor.');
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(getServerStateUrl('/inventory/damage-loss/reinsert'), {
      method: 'POST',
      cache: 'no-store',
      signal: controller.signal,
      headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      throw await createServerStateError(response, 'No se pudo reinsertar el item reparado.');
    }
    const result = await response.json();
    if (result?.revision) rememberServerRevision(result.revision);

    if (result?.item?.id) {
      const snapshot = await exportLocalCollections(['items']);
      const rows = Array.isArray(snapshot?.items) ? snapshot.items : [];
      const exists = rows.some((entry) => String(entry?.id ?? '') === String(result.item.id));
      await mergeLocalState({
        items: exists
          ? rows.map((entry) => (String(entry?.id ?? '') === String(result.item.id) ? result.item : entry))
          : [result.item, ...rows],
      });
    }
    if (result?.movement?.id && loadedServerCollections.has('inventoryMovements')) {
      const snapshot = await exportLocalCollections(['inventoryMovements']);
      const rows = Array.isArray(snapshot?.inventoryMovements) ? snapshot.inventoryMovements : [];
      await mergeLocalState({ inventoryMovements: [result.movement, ...rows.filter((entry) => String(entry?.id ?? '') !== String(result.movement.id))] });
    }

    markServerStateStale('inventory.damageRepairReinsert');
    announceDataChange({
      domain: 'inventory',
      method: 'damageRepairReinsert',
      collections: ['items', 'rentals', 'inventoryMovements'],
    });
    return result;
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardo demasiado en confirmar la reinsercion. Verifica el kardex antes de repetir la operacion.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
};

const callDirectDamageDiscardToMissing = async (payload = {}) => {
  if (!shouldUseServerState()) throw new Error('El descarte de daños requiere conexión con el servidor.');
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(getServerStateUrl('/inventory/damage-loss/discard-to-missing'), {
      method: 'POST',
      cache: 'no-store',
      signal: controller.signal,
      headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      throw await createServerStateError(response, 'No se pudo mover el daño a Faltantes.');
    }
    const result = await response.json();
    if (result?.revision) rememberServerRevision(result.revision);
    markServerStateStale('inventory.damageDiscardToMissing');
    announceDataChange({
      domain: 'inventory',
      method: 'damageDiscardToMissing',
      collections: ['rentals'],
    });
    return result;
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardó demasiado en confirmar el descarte. Actualiza el kardex antes de repetir la operación.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
};

const callDirectInventoryRecoveryOperation = async (payload = {}) => {
  if (!shouldUseServerState()) return callBridge('inventory', 'processRecovery', true, payload);
  const recoveryId = String(payload?.recoveryId ?? '').trim();
  if (!recoveryId) throw new Error('Debes seleccionar un pendiente para procesar.');

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(getServerStateUrl(`/inventory/recoveries/${encodeURIComponent(recoveryId)}/process`), {
      method: 'POST',
      cache: 'no-store',
      signal: controller.signal,
      headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      throw await createServerStateError(response, 'No se pudo procesar la unidad en lavado o reparacion.');
    }
    const result = await response.json();
    if (result?.revision) rememberServerRevision(result.revision);
    announceDataChange({
      domain: 'inventory',
      method: 'processRecovery',
      collections: INVENTORY_RECOVERY_PATCH_COLLECTIONS,
    });
    return result;
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardo demasiado en procesar el item. No repitas la operacion hasta verificar el estado del pendiente.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
};

const callDirectRentalReturnOperation = async (payload = {}) => {
  if (!shouldUseServerState()) return null;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 25000);
  try {
    const response = await fetch(getServerStateUrl('/rentals/register-return'), {
      method: 'POST',
      cache: 'no-store',
      signal: controller.signal,
      headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    if (!response.ok) throw await createServerStateError(response, 'No se pudo registrar la recepcion.');
    const result = await response.json();
    const rental = result?.rental ?? null;
    if (result?.revision) rememberServerRevision(result.revision);
    if (rental?.id) {
      // En modo servidor el controlador ya aplica esta respuesta en memoria.
      // Reescribir aqui toda la coleccion local de alquileres hacia que un clic
      // sencillo quedara congelado mientras serializaba cientos de ordenes.
      rememberFullRecordCache(fullRentalCache, rental, [rental.id, rental.orderCode, rental.contractCode]);
    }
    announceDataChange({ domain: 'rentals', method: 'registerReturn', collections: RENTAL_RETURN_PATCH_COLLECTIONS });
    return rental
      ? { ...rental, __inventoryItems: Array.isArray(result?.items) ? result.items : [], __inventoryLossMovements: Array.isArray(result?.movements) ? result.movements : [] }
      : result;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('El servidor tardo demasiado en cerrar la recepcion. No la repitas: vuelve a abrir movimientos para verificar el estado.');
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
};

const updateRentalOperationalOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) return callBridge('rentals', 'updateOperational', true, payload);
  const rentalId = String(payload?.id ?? payload?.rentalId ?? '').trim();
  if (!rentalId) throw new Error('No se pudo identificar la orden de servicio.');

  const response = await fetch(getServerStateUrl(`/rentals/${encodeURIComponent(rentalId)}/operational`), {
    method: 'PATCH',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(payload),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo actualizar la orden operativa.');
  }
  const result = await response.json();
  if (result?.revision) rememberServerRevision(result.revision);
  const rental = result?.rental ?? null;
  if (rental?.id) {
    forgetFullRecordCache(fullRentalCache, [rentalId, rental.id, rental.orderCode, rental.contractCode]);
  }
  announceDataChange({ domain: 'rentals', method: 'updateOperational', collections: ['rentals'] });
  return rental ?? result;
};


const updateRentalReturnChargeOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) {
    throw new Error('La edición del cargo requiere conexión con el servidor.');
  }

  const rentalId = String(payload?.rentalId ?? payload?.id ?? '').trim();
  if (!rentalId) throw new Error('No se pudo identificar la devolución.');

  const response = await fetch(
    getServerStateUrl(`/rentals/${encodeURIComponent(rentalId)}/return-charge`),
    {
      method: 'PATCH',
      cache: 'no-store',
      headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        ...payload,
        revision: Object.prototype.hasOwnProperty.call(payload, 'revision')
          ? payload.revision
          : lastSharedRevision ?? getCachedServerRevision() ?? null,
      }),
    },
  );
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo actualizar el cargo de devolución.');
  }

  const result = await response.json();
  if (result?.revision) rememberServerRevision(result.revision);

  const rental = result?.rental ?? null;
  if (rental?.id) {
    const localSnapshot = await exportLocalCollections(['rentals']);
    const currentRentals = Array.isArray(localSnapshot?.rentals) ? localSnapshot.rentals : [];
    const nextRentals = currentRentals.some((entry) => String(entry?.id ?? '') === String(rental.id))
      ? currentRentals.map((entry) => (
        String(entry?.id ?? '') === String(rental.id) ? rental : entry
      ))
      : [rental, ...currentRentals];

    await mergeLocalState({ rentals: nextRentals });
    forgetFullRecordCache(fullRentalCache, [
      rentalId,
      rental.id,
      rental.orderCode,
      rental.contractCode,
    ]);
    rememberFullRecordCache(fullRentalCache, rental, [
      rentalId,
      rental.orderCode,
      rental.contractCode,
    ]);
  }

  announceDataChange({
    domain: 'rentals',
    method: 'updateReturnCharge',
    collections: ['rentals', 'cashMovements', 'systemAuditLog'],
  });
  return result;
};


const cancelContractOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) return null;

  const requestedId = String(payload?.id ?? payload?.rentalId ?? payload?.contractId ?? '').trim();
  if (!requestedId) {
    throw new Error('No se pudo identificar el contrato u orden de servicio a anular.');
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 20000);
  try {
    const response = await fetch(getServerStateUrl('/contracts/cancel'), {
      method: 'POST',
      cache: 'no-store',
      signal: controller.signal,
      headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      throw await createServerStateError(response, 'No se pudo anular el contrato.');
    }

    const result = await response.json();
    if (result?.revision) rememberServerRevision(result.revision);

    const collections = {};
    if (result?.contract?.id) {
      const snapshot = await exportLocalCollections(['contracts']);
      const rows = Array.isArray(snapshot?.contracts) ? snapshot.contracts : [];
      collections.contracts = rows.some((entry) => String(entry?.id ?? '') === String(result.contract.id))
        ? rows.map((entry) => (String(entry?.id ?? '') === String(result.contract.id) ? result.contract : entry))
        : [result.contract, ...rows];
      forgetFullRecordCache(fullContractCache, result.contract);
      rememberFullRecordCache(fullContractCache, result.contract, [result.contract.contractCode]);
    }
    if (result?.rental?.id) {
      const snapshot = await exportLocalCollections(['rentals']);
      const rows = Array.isArray(snapshot?.rentals) ? snapshot.rentals : [];
      collections.rentals = rows.some((entry) => String(entry?.id ?? '') === String(result.rental.id))
        ? rows.map((entry) => (String(entry?.id ?? '') === String(result.rental.id) ? result.rental : entry))
        : [result.rental, ...rows];
      forgetFullRecordCache(fullRentalCache, result.rental);
      rememberFullRecordCache(fullRentalCache, result.rental, [result.rental.orderCode, result.rental.contractCode]);
    }
    if (Array.isArray(result?.deliveries)) {
      const snapshot = await exportLocalCollections(['deliveries']);
      const rows = Array.isArray(snapshot?.deliveries) ? snapshot.deliveries : [];
      const changed = new Map(result.deliveries.map((entry) => [String(entry?.id ?? ''), entry]));
      collections.deliveries = rows.map((entry) => changed.get(String(entry?.id ?? '')) ?? entry);
    }
    if (Array.isArray(result?.supplierLoans)) {
      const snapshot = await exportLocalCollections(['supplierLoans']);
      const rows = Array.isArray(snapshot?.supplierLoans) ? snapshot.supplierLoans : [];
      const changed = new Map(result.supplierLoans.map((entry) => [String(entry?.id ?? ''), entry]));
      collections.supplierLoans = rows.map((entry) => changed.get(String(entry?.id ?? '')) ?? entry);
    }
    if (Object.keys(collections).length) await mergeLocalState(collections);

    markServerStateStale('rentals.cancel:direct');
    announceDataChange({
      domain: 'rentals',
      method: 'cancel',
      collections: ['items', 'contracts', 'rentals', 'deliveries', 'supplierLoans', 'inventoryMovements', 'systemAuditLog'],
    });
    return result?.rental ?? result;
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardo demasiado en confirmar la anulacion. No la repitas: vuelve a abrir el contrato para verificar su estado.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
};

const fetchContractEconomicContext = async (identifier) => {
  const requestedId = String(identifier ?? '').trim();
  if (!requestedId) {
    throw new Error('Debes indicar el contrato para abrir el seguimiento economico.');
  }

  if (!shouldUseServerState()) {
    const contract = await callBridge('contracts', 'getById', false, requestedId);
    return { contract, rental: null, serviceOrder: null, cashMovements: [] };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  try {
    try {
      const repairResponse = await fetch(
        getServerStateUrl(`/contracts/${encodeURIComponent(requestedId)}/economic-ledger/repair-legacy-reset`),
        {
          method: 'POST',
          cache: 'no-store',
          headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({}),
        },
      );
      if (repairResponse.ok) {
        const repairResult = await repairResponse.json();
        if (repairResult?.revision) {
          lastSharedRevision = repairResult.revision;
          setCachedServerRevision(repairResult.revision);
        }
        if (repairResult?.repaired && repairResult?.contract?.id) {
          rememberFullRecordCache(
            fullContractCache,
            repairResult.contract,
            [requestedId, repairResult.contract.id, repairResult.contract.contractCode],
          );
        }
      }
    } catch (repairError) {
      console.warn('[economic-ledger] No se pudo comprobar reparacion legacy; se continuara con la lectura.', repairError);
    }

    const response = await fetch(
      getServerStateUrl(`/contracts/${encodeURIComponent(requestedId)}/economic-context`),
      {
        method: 'GET',
        cache: 'no-store',
        signal: controller.signal,
        headers: getInternalHeaders(),
      },
    );

    if (!response.ok) {
      throw await createServerStateError(
        response,
        'No se pudo cargar el seguimiento economico del contrato.',
      );
    }

    const result = await response.json();
    if (Object.prototype.hasOwnProperty.call(result ?? {}, 'revision')) {
      lastSharedRevision = result.revision;
      setCachedServerRevision(result.revision);
    }
    return result;
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardo demasiado en abrir el seguimiento economico.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
};


const resetContractEconomicsOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) {
    throw new Error('El Reset economico requiere abrir la aplicacion desde el servidor.');
  }

  const requestedId = String(payload?.id ?? payload?.contractId ?? payload?.contractCode ?? '').trim();
  if (!requestedId) {
    throw new Error('Debes indicar el contrato para ejecutar el Reset economico.');
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 20000);
  let response;
  try {
    response = await fetch(
      getServerStateUrl(`/contracts/${encodeURIComponent(requestedId)}/economic-reset`),
      {
        method: 'POST',
        cache: 'no-store',
        signal: controller.signal,
        headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      },
    );
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardo demasiado en ejecutar el Reset economico. No lo repitas: vuelve a abrir el contrato para verificar.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }

  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo ejecutar el Reset economico del contrato.');
  }

  const result = await response.json();
  if (Object.prototype.hasOwnProperty.call(result ?? {}, 'revision')) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
  }
  // El endpoint devuelve el contrato completo con el economicLedger ya reemplazado.
  // Debemos guardarlo inmediatamente en la base local antes de disparar la
  // sincronizacion resumida. De lo contrario preserveLocalDetailsInSummaries
  // conserva el economicLedger anterior y vuelve a mezclar las lineas eliminadas.
  if (result?.contract?.id) {
    const localSnapshot = await exportLocalCollections(['contracts']);
    const currentContracts = Array.isArray(localSnapshot?.contracts) ? localSnapshot.contracts : [];
    const nextContracts = currentContracts.some((entry) => String(entry?.id ?? '') === String(result.contract.id))
      ? currentContracts.map((entry) => (
        String(entry?.id ?? '') === String(result.contract.id) ? result.contract : entry
      ))
      : [result.contract, ...currentContracts];
    await mergeLocalState({ contracts: nextContracts });
    rememberFullRecordCache(
      fullContractCache,
      result.contract,
      [requestedId, result.contract.id, result.contract.contractCode],
    );
  }

  if (result?.rental?.id) {
    const localSnapshot = await exportLocalCollections(['rentals']);
    const currentRentals = Array.isArray(localSnapshot?.rentals) ? localSnapshot.rentals : [];
    const nextRentals = currentRentals.some((entry) => String(entry?.id ?? '') === String(result.rental.id))
      ? currentRentals.map((entry) => (
        String(entry?.id ?? '') === String(result.rental.id) ? result.rental : entry
      ))
      : [result.rental, ...currentRentals];
    await mergeLocalState({ rentals: nextRentals });
    rememberFullRecordCache(
      fullRentalCache,
      result.rental,
      [result.rental.id, result.rental.orderCode, result.rental.contractCode],
    );
  }

  forgetFullRecordCache(fullContractCache, [requestedId]);
  markServerStateStale('contracts.resetEconomics:direct');
  announceDataChange({
    domain: 'contracts',
    method: 'resetEconomics',
    collections: ['contracts', 'rentals', 'cashMovements', 'cashDebts', 'generatedReports'],
  });
  return result;
};



const applyContractNoteMutationResult = async (result, requestedId, method) => {
  if (result && Object.prototype.hasOwnProperty.call(result, 'revision')) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
  }

  if (result?.contract?.id) {
    const current = await exportLocalCollections(['contracts']);
    const contracts = Array.isArray(current?.contracts) ? current.contracts : [];
    const nextContracts = contracts.some((entry) => String(entry?.id) === String(result.contract.id))
      ? contracts.map((entry) => String(entry?.id) === String(result.contract.id)
        ? { ...entry, ...result.contract }
        : entry)
      : [result.contract, ...contracts];
    await mergeLocalState({ contracts: nextContracts });
    forgetFullRecordCache(fullContractCache, [requestedId, result.contract.id]);
  }

  markServerStateStale(`contracts.${method}:direct`);
  announceDataChange({
    domain: 'contracts',
    method,
    collections: ['contracts', 'systemAuditLog'],
  });
  return result;
};

const mutateContractNoteOnServer = async ({ method, payload = {}, noteId = null, actionName }) => {
  if (!shouldUseServerState()) return null;
  const requestedId = String(payload?.id ?? payload?.contractId ?? payload?.contractCode ?? '').trim();
  if (!requestedId) throw new Error('Debes indicar el contrato para guardar la nota.');

  const cleanNoteId = String(noteId ?? payload?.noteId ?? '').trim();
  const suffix = cleanNoteId
    ? `/contracts/${encodeURIComponent(requestedId)}/notes/${encodeURIComponent(cleanNoteId)}`
    : `/contracts/${encodeURIComponent(requestedId)}/notes`;
  const requestPayload = {
    ...payload,
    revision: Object.prototype.hasOwnProperty.call(payload, 'revision')
      ? payload.revision
      : lastSharedRevision ?? getCachedServerRevision() ?? null,
  };

  const response = await fetch(getServerStateUrl(suffix), {
    method,
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(requestPayload),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo actualizar la nota del contrato.');
  }
  return applyContractNoteMutationResult(await response.json(), requestedId, actionName);
};

const createContractNoteOnServer = (payload = {}) => mutateContractNoteOnServer({
  method: 'POST',
  payload,
  actionName: 'addNote',
});

const updateContractNoteOnServer = (payload = {}) => mutateContractNoteOnServer({
  method: 'PATCH',
  payload,
  noteId: payload?.noteId,
  actionName: 'updateNote',
});

const deleteContractNoteOnServer = (payload = {}) => mutateContractNoteOnServer({
  method: 'DELETE',
  payload,
  noteId: payload?.noteId,
  actionName: 'deleteNote',
});

const setContractFinalizedOnServer = async (payload = {}) => {
  const requestedId = String(payload?.id ?? payload?.contractId ?? payload?.contractCode ?? '').trim();
  if (!requestedId) throw new Error('Debes indicar el contrato para actualizar su finalizacion.');

  if (!shouldUseServerState()) {
    return callBridge('contracts', 'update', true, payload);
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);
  let response;
  try {
    response = await fetch(
      getServerStateUrl(`/contracts/${encodeURIComponent(requestedId)}/finalized`),
      {
        method: 'PATCH',
        cache: 'no-store',
        signal: controller.signal,
        headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      },
    );
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardo demasiado en actualizar el contrato.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }

  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo actualizar el finalizado del contrato.');
  }

  const result = await response.json();
  if (result?.revision) rememberServerRevision(result.revision);
  if (result?.contract?.id) {
    forgetFullRecordCache(fullContractCache, [requestedId, result.contract.id]);
  }
  // React recibe el parche pequeno y actualiza la fila de inmediato. La copia
  // local completa queda marcada para refrescarse antes de la proxima mutacion,
  // evitando serializar cientos de contratos por este unico booleano.
  markServerStateStale('contracts.setFinalized:direct');
  announceDataChange({
    domain: 'contracts',
    method: 'setFinalized',
    collections: ['contracts', 'systemAuditLog'],
  });
  return result?.contract ?? null;
};

const updateContractEconomicLedgerOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) {
    return null;
  }

  const requestedId = String(payload?.id ?? payload?.contractId ?? payload?.contractCode ?? '').trim();
  if (!requestedId) {
    throw new Error('Debes indicar el contrato para guardar el cuaderno economico.');
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  let response;
  try {
    response = await fetch(
      getServerStateUrl(`/contracts/${encodeURIComponent(requestedId)}/economic-ledger`),
      {
        method: 'PUT',
        cache: 'no-store',
        signal: controller.signal,
        headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      },
    );
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardo demasiado en guardar el cuaderno economico. Vuelve a abrirlo antes de repetir la operacion.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }

  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo guardar el cuaderno economico del contrato.');
  }

  const result = await response.json();
  if (result && Object.prototype.hasOwnProperty.call(result, 'revision')) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
  }
  markServerStateStale('contracts.updateEconomicLedger:direct');
  announceDataChange({ domain: 'contracts', method: 'updateEconomicLedger' });
  return result?.contract ?? null;
};

const getFilenameFromDisposition = (disposition) => {
  const value = String(disposition ?? '');
  const utf8Match = value.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf8Match) return decodeURIComponent(utf8Match[1]);
  const match = value.match(/filename="?([^";]+)"?/i);
  return match?.[1] ? match[1] : '';
};

const exportDatabaseDirect = async (payload = {}) => {
  if (!shouldUseServerState()) {
    throw new Error('La descarga de bases grandes requiere abrir la app desde el servidor, no desde un archivo local.');
  }

  await callBridge('system', 'verifyResetAccess', false, { code: payload?.code });
  const response = await fetch(getServerStateUrl('/database/export'), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({
      code: payload?.code,
      userId: payload?.userId,
      observations: payload?.observations,
    }),
  });

  if (response.status === 404 || response.status === 405) {
    throw new Error('El backend aun no tiene activa la descarga directa. Reinicia el servidor local/API y vuelve a intentar.');
  }
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo descargar la base de datos.');
  }

  const blob = await response.blob();
  const revision = response.headers.get('X-Copetin-Revision');
  if (revision) {
    rememberServerRevision(revision);
    localServerCommitSerial += 1;
  }
  const exportedAt = response.headers.get('X-Copetin-Exported-At') || new Date().toISOString();
  const filename = getFilenameFromDisposition(response.headers.get('Content-Disposition'))
    || `copetin-base-datos-${String(exportedAt).replace(/[:.]/g, '-')}.json`;
  return {
    ok: true,
    blob,
    filename,
    exportedAt,
    summary: {
      total: Number(response.headers.get('X-Copetin-Summary-Total') ?? 0) || 0,
    },
  };
};

const importDatabaseDirect = async (payload = {}) => {
  if (!payload?.file) {
    return callBridge('system', 'importDatabase', true, payload);
  }
  if (!shouldUseServerState()) {
    throw new Error('La importacion de archivos grandes requiere abrir la app desde el servidor, no desde un archivo local.');
  }

  await callBridge('system', 'verifyResetAccess', false, { code: payload?.code });
  const response = await fetch(getServerStateUrl('/database/import'), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({
      'Content-Type': 'application/octet-stream',
      'X-Copetin-Reset-Code': String(payload?.code ?? ''),
      'X-Copetin-User-Id': String(payload?.userId ?? ''),
      'X-Copetin-Confirmation': String(payload?.confirmation ?? ''),
      'X-Copetin-Observations': encodeURIComponent(String(payload?.observations ?? '')),
    }),
    body: payload.file,
  });

  if (response.status === 404 || response.status === 405) {
    throw new Error('El backend aun no tiene activa la importacion directa. Reinicia el servidor local/API y vuelve a intentar.');
  }
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo importar la base de datos.');
  }

  const result = await response.json();
  if (result?.revision) {
    rememberServerRevision(result.revision);
    localServerCommitSerial += 1;
  }
  markServerStateStale('database-import');
  await syncServerState({ force: true, required: true, reason: 'database-import' });
  announceDataChange({ domain: 'system', method: 'importDatabase' });
  return result;
};

const analyzeAccountingResetOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) {
    return callBridge('system', 'analyzeReset', false, payload);
  }
  const verification = await callBridge('system', 'verifyResetAccess', false, { code: payload?.code });
  const response = await fetch(getServerStateUrl('/accounting/reset-preview'), {
    method: 'POST',
    cache: 'no-store',
    headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({
      ...payload,
      userId: payload?.userId ?? verification?.user?.id ?? '',
    }),
  });
  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo analizar el reinicio contable.');
  }
  const result = await response.json();
  if (result?.revision) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
  }
  return result?.analysis ?? result;
};

const executeAccountingResetOnServer = async (payload = {}) => {
  if (!shouldUseServerState()) {
    throw new Error('El reinicio contable seguro requiere abrir la aplicacion desde el servidor.');
  }
  const verification = await callBridge('system', 'verifyResetAccess', false, { code: payload?.code });
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000);
  let response;
  try {
    response = await fetch(getServerStateUrl('/accounting/reset'), {
      method: 'POST',
      cache: 'no-store',
      signal: controller.signal,
      headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        ...payload,
        userId: payload?.userId ?? verification?.user?.id ?? '',
      }),
    });
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El servidor tardo demasiado en confirmar el reinicio contable. No lo repitas: recarga Contabilidad para verificar.');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }

  if (!response.ok) {
    throw await createServerStateError(response, 'No se pudo iniciar el nuevo periodo contable.');
  }
  const result = await response.json();
  if (result?.revision) {
    lastSharedRevision = result.revision;
    setCachedServerRevision(result.revision);
    localServerCommitSerial += 1;
  }

  await mergeLocalState({
    cashSessions: Array.isArray(result?.cashSessions) ? result.cashSessions : [],
    cashMovements: Array.isArray(result?.cashMovements) ? result.cashMovements : [],
    cashDebts: Array.isArray(result?.cashDebts) ? result.cashDebts : [],
  });
  loadedServerCollections.add('cashSessions');
  loadedServerCollections.add('cashMovements');
  loadedServerCollections.add('cashDebts');
  markServerStateStale('accounting-reset');
  announceDataChange({
    domain: 'system',
    method: 'executeReset',
    collections: ['cashSessions', 'cashMovements', 'cashDebts', 'resetLogs', 'systemAuditLog'],
  });
  return result;
};

const isAccountingOnlyReset = (payload = {}) => {
  const modules = [...new Set((Array.isArray(payload?.modules) ? payload.modules : [])
    .map((value) => String(value ?? '').trim())
    .filter(Boolean))];
  return modules.length === 1 && modules[0] === 'cash_accounting';
};

const mutateUserOnServer = (method, payload = {}) => {
  if (!shouldUseServerState()) return callBridge('users', method, true, payload);

  return enqueueMutation(async () => {
    let localUser = null;
    try {
      localUser = await getBridge().users[method](payload);
      const userId = String(localUser?.id ?? payload?.id ?? '').trim();
      if (!userId || !localUser) throw new Error('No se pudo preparar el usuario para guardar.');

      const response = await fetch(getServerStateUrl(`/users/${encodeURIComponent(userId)}`), {
        method: 'PUT',
        cache: 'no-store',
        headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          actorUserId: String(payload?.actorUserId ?? '').trim(),
          user: localUser,
        }),
      });
      if (!response.ok) {
        throw await createServerStateError(response, 'No se pudo guardar el usuario.');
      }

      const result = await response.json();
      if (result?.revision) {
        rememberServerRevision(result.revision);
        localServerCommitSerial += 1;
      }
      announceDataChange({ domain: 'users', method, collections: USER_PATCH_COLLECTIONS });
      return result?.user ?? localUser;
    } catch (error) {
      // Si el servidor rechaza la operacion, restauramos la coleccion oficial
      // para que la pantalla no muestre un cambio que nunca fue confirmado.
      if (localUser) {
        await fetchServerCollections(['users'], `users.${method}:rollback`).catch(() => {});
      }
      throw error;
    }
  });
};

export const runtimeInfo =
  {
    ...getWebRuntimeInfo(),
    storage: REMOTE_API_BASE_URL
      ? 'remote-api'
      : shouldUseServerState()
        ? 'server-state'
        : getWebRuntimeInfo().storage,
    apiBaseUrl: REMOTE_API_BASE_URL || 'same-origin',
  };

export const api = {
  sync: {
    subscribe: subscribeToDataChanges,
    ensureLoaded: (options = {}) => syncServerState({
      required: options?.background ? false : true,
      reason: 'initial-bootstrap',
      preferCache: Boolean(options?.background),
    }),
    pullLatest: () => syncServerState({ force: true, reason: 'manual-refresh' }),
    refreshCollections: (names, reason = 'targeted-refresh') => fetchServerCollections(names, reason),
    getMobileCalendarOverview: fetchMobileCalendarOverview,
    getMobileOrdersOverview: fetchMobileOrdersOverview,
    getAccountingBaseOverview: fetchAccountingBaseOverview,
    getOrdersEditorOverview: fetchOrdersEditorOverview,
    getClientsOverview: fetchClientsOverview,
    getAvailabilityOverview: fetchAvailabilityOverview,
    getInventoryMovementsOverview: fetchInventoryMovementsOverview,
    getRevision: fetchServerMeta,
    batchMutations: runBatchedMutations,
    ensureCollectionsLoaded: (names, reason) => ensureServerCollectionsLoaded(names, reason),
  },
  inventory: {
    list: () => callBridge('inventory', 'list', false),
    listCombos: () => callBridge('inventory', 'listCombos', false),
    create: (payload) => callBridge('inventory', 'create', true, payload),
    update: (payload) => callBridge('inventory', 'update', true, payload),
    remove: (payload) => callDirectInventoryItemRemove(payload),
    createCombo: (payload) => callBridge('inventory', 'createCombo', true, payload),
    updateCombo: (payload) => callBridge('inventory', 'updateCombo', true, payload),
    removeCombo: (payload) => callBridge('inventory', 'removeCombo', true, payload),
    listMovements: async () => { await ensureServerCollectionsLoaded(['inventoryMovements'], 'inventory-movements'); return callBridge('inventory', 'listMovements', false); },
    createMovement: (payload) => callBridge('inventory', 'createMovement', true, payload),
    getDamageLossOverview: fetchInventoryDamageLossOverview,
    searchMovementHistory: fetchInventoryMovementHistory,
    getLegacyContracts: fetchLegacyContracts,
    createLegacyContract: (payload) => postLegacyContract('', payload),
    updateLegacyContract: (id, payload) => mutateLegacyContract('PUT', `/${encodeURIComponent(id)}`, payload),
    settleLegacyContract,
    deleteLegacyContract: (id, payload) => mutateLegacyContract('DELETE', `/${encodeURIComponent(id)}`, payload),
    receiveLegacyContractItem: (id, payload) => postLegacyContract(`/${encodeURIComponent(id)}/receive`, payload),
    resolveLegacyContractItem: (id, payload) => postLegacyContract(`/${encodeURIComponent(id)}/resolve-item`, payload),
    getProductsKardex: fetchProductsKardex,
    getProductKardexHistory: fetchProductKardexHistory,
    reinsertRepairedDamage: (payload) => callDirectDamageRepairReinsert(payload),
    discardDamageToMissing: (payload) => callDirectDamageDiscardToMissing(payload),
    listRecoveries: async () => {
      if (shouldUseServerState()) {
        // stockRecoveries es una coleccion diferida. Debemos leerla directamente
        // del servidor y consultar el bridge local sin disparar luego un bootstrap,
        // porque callBridge(..., false) puede reemplazar la copia recien cargada
        // antes de devolverla a la vista de Lavado y Reparacion.
        await fetchServerCollections(['stockRecoveries'], 'stock-recoveries');
        return getBridge().inventory.listRecoveries();
      }
      return callBridge('inventory', 'listRecoveries', false);
    },
    processRecovery: (payload) => callDirectInventoryRecoveryOperation(payload),
  },
  uploads: {
    productImage: uploadProductImage,
    economicReceiptImage: uploadEconomicReceiptImage,
    deleteEconomicReceiptImage,
    attendancePhoto: uploadAttendancePhoto,
    roomImage: uploadLincolnRoomImage,
    deleteRoomImage: deleteLincolnRoomImage,
    packageImage: uploadLincolnPackageImage,
    deletePackageImage: deleteLincolnPackageImage,
  },
  categories: {
    list: () => callBridge('categories', 'list', false),
    create: (payload) => callBridge('categories', 'create', true, payload),
    update: (payload) => callBridge('categories', 'update', true, payload),
    remove: (payload) => callBridge('categories', 'remove', true, payload),
  },
  quotes: {
    list: () => callBridge('quotes', 'list', false),
    create: (payload) => callBridge('quotes', 'create', true, payload),
    update: (payload) => callBridge('quotes', 'update', true, payload),
    remove: (payload) => callBridge('quotes', 'remove', true, payload),
  },
  contracts: {
    list: () => callBridge('contracts', 'list', false),
    listHidden: () => callBridge('contracts', 'listHidden', false),
    ensureFull: (identifier, reason) => fetchFullServerContract(identifier, reason),
    getEconomicContext: (identifier) => fetchContractEconomicContext(identifier),
    create: async (payload) => {
      const created = await callBridge('contracts', 'create', true, payload);
      forgetFullRecordCache(fullContractCache, created);
      return created;
    },
    createAndApprove: async (payload) => {
      const result = await createAndApproveContractOnServer(payload);
      forgetFullRecordCache(fullContractCache, result?.contract ?? payload);
      if (result?.rental) forgetFullRecordCache(fullRentalCache, result.rental);
      return result;
    },
    update: async (payload) => {
      forgetFullRecordCache(fullContractCache, payload);
      const updated = await updateContractOnServer(payload);
      forgetFullRecordCache(fullContractCache, updated);
      return updated;
    },
    setFinalized: setContractFinalizedOnServer,
    updateEconomicLedger: async (payload) => {
      forgetFullRecordCache(fullContractCache, payload);
      const updated = await updateContractEconomicLedgerOnServer(payload);
      forgetFullRecordCache(fullContractCache, updated);
      return updated;
    },
    addNote: (payload) => createContractNoteOnServer(payload),
    updateNote: (payload) => updateContractNoteOnServer(payload),
    deleteNote: (payload) => deleteContractNoteOnServer(payload),
    resetEconomics: (payload) => resetContractEconomicsOnServer(payload),
    remove: (payload) => removeContractOnServer(payload),
    restore: (payload) => callBridge('contracts', 'restore', true, payload),
    revertToQuote: (payload) => callBridge('contracts', 'revertToQuote', true, payload),
  },
  suppliers: {
    listBundle: async ({ force = false } = {}) => {
      if (!shouldUseServerState()) return callBridge('suppliers', 'listBundle', false);
      const now = Date.now();
      if (!force && supplierOverviewCache && now - supplierOverviewCache.cachedAt < SUPPLIER_OVERVIEW_CACHE_TTL_MS) {
        return supplierOverviewCache.bundle;
      }
      if (!force && supplierOverviewRequest) return supplierOverviewRequest;

      const request = (async () => {
        const response = await fetch(getServerStateUrl('/suppliers/overview'), {
          cache: 'no-store',
          headers: getInternalHeaders(),
        });
        if (!response.ok) {
          throw await createServerStateError(response, 'No se pudo cargar la vista de proveedores.');
        }
        const payload = await response.json();
        if (payload?.revision) {
          lastSharedRevision = payload.revision;
          setCachedServerRevision(payload.revision);
        }
        const bundle = {
          suppliers: Array.isArray(payload?.suppliers) ? payload.suppliers : [],
          quotes: Array.isArray(payload?.quotes) ? payload.quotes : [],
          loans: Array.isArray(payload?.loans) ? payload.loans : [],
        };
        supplierOverviewCache = { bundle, cachedAt: Date.now() };
        return bundle;
      })();

      supplierOverviewRequest = request;
      try {
        return await request;
      } finally {
        if (supplierOverviewRequest === request) supplierOverviewRequest = null;
      }
    },
    create: async (payload) => {
      const created = await createSupplierOnServer(payload);
      invalidateSupplierOverviewCache();
      return created;
    },
    update: async (payload) => {
      const updated = await callBridge('suppliers', 'update', true, payload);
      invalidateSupplierOverviewCache();
      return updated;
    },
    createQuote: async (payload) => {
      const created = await callBridge('suppliers', 'createQuote', true, payload);
      invalidateSupplierOverviewCache();
      return created;
    },
    createLoan: async (payload) => {
      const created = await callBridge('suppliers', 'createLoan', true, payload);
      invalidateSupplierOverviewCache();
      return created;
    },
    updateLoanStatus: async (payload) => {
      const updated = await callBridge('suppliers', 'updateLoanStatus', true, payload);
      invalidateSupplierOverviewCache();
      return updated;
    },
  },
  personnel: {
    getOverview: getPersonnelOverview,
    getOptions: (payload) => getPersonnelOptionsFromServer(payload),
    listBundle: async () => { await ensureServerCollectionsLoaded(['personnelEmployees', 'personnelAttendance', 'personnelIncidents'], 'personnel-bundle'); return callBridge('personnel', 'listBundle', false); },
    createEmployee: (payload) => mutatePersonnelOnServer('createEmployee', payload),
    updateEmployee: (payload) => mutatePersonnelOnServer('updateEmployee', payload),
    removeEmployee: (payload) => mutatePersonnelOnServer('removeEmployee', payload),
    createIncident: (payload) => mutatePersonnelOnServer('createIncident', payload),
    updateIncident: (payload) => mutatePersonnelOnServer('updateIncident', payload),
    importAttendance: (payload) => mutatePersonnelOnServer('importAttendance', payload),
  },
  clients: {
    list: () => callBridge('clients', 'list', false),
    create: (payload) => callBridge('clients', 'create', true, payload),
    update: (payload) => callBridge('clients', 'update', true, payload),
  },
  users: {
    list: () => callBridge('users', 'list', false),
    // Lectura estrictamente local para vistas progresivas. No debe iniciar ni
    // esperar el bootstrap global del servidor.
    listCached: () => getBridge().users.list(),
    create: (payload) => mutateUserOnServer('create', payload),
    update: (payload) => mutateUserOnServer('update', payload),
    remove: (payload) => mutateUserOnServer('remove', payload),
    resendInvite: (payload) => mutateUserOnServer('resendInvite', payload),
  },
  auth: {
    getSession: async () => {
      const bridge = getBridge();
      const hasStoredSession = await bridge.auth.hasStoredSession();
      if (!hasStoredSession) {
        console.info(`[copetin-sync] Sesion local ausente; se omite GET ${SERVER_STATE_ENDPOINT}`);
        return null;
      }

      // Para reconstruir una sesion solo necesitamos usuarios. Descargar esta
      // coleccion evita bloquear el ingreso con el bootstrap completo, especialmente
      // en celulares, sin cambiar permisos ni la validacion contra el servidor.
      await fetchServerCollections(['users'], 'auth-session-users');
      return bridge.auth.getSession();
    },
    login: async (payload) => {
      // Las credenciales y permisos viven en usuarios. Validamos esa coleccion
      // directamente contra el servidor y dejamos el resto del estado para la carga
      // del espacio de trabajo; asi el selector Copetin/Lincoln aparece de inmediato.
      await fetchServerCollections(['users'], 'auth-login-users');
      const session = await getBridge().auth.login(payload);
      const { __requiresFullStatePush, ...publicSession } = session;
      if (__requiresFullStatePush) {
        pushServerState()
          .then(() => announceDataChange({ domain: 'auth', method: 'login-initial-password' }))
          .catch((error) => {
            applyRemoteBackoff(error);
            console.warn('[copetin-sync] No se pudo guardar cambio inicial de contrasena.', error);
          });
      } else {
        console.info('[copetin-sync] Login sin mutacion persistible; se omite push completo.', {
          downloaded: hasLoadedServerState,
        });
      }
      return publicSession;
    },
    logout: async () => {
      const result = await getBridge().auth.logout();
      announceDataChange({ domain: 'auth', method: 'logout' });
      console.info('[copetin-sync] Logout local sin mutacion persistible; se omite push completo.');
      return result;
    },
  },
  presence: {
    listActive: async () => {
      const active = await callServerPresence('listActive');
      if (active) return normalizePresenceList(active);
      return normalizePresenceList(await callBridge('presence', 'listActive', false));
    },
    heartbeat: async (payload) => {
      const active = await callServerPresence('heartbeat', payload);
      if (active) return normalizePresenceList(active);
      return normalizePresenceList(await callBridge('presence', 'heartbeat', true, payload));
    },
    leave: async (payload) => {
      const active = await callServerPresence('leave', payload);
      if (active) return normalizePresenceList(active);
      return normalizePresenceList(await callBridge('presence', 'leave', true, payload));
    },
  },
  updateNotice: {
    get: async () => {
      if (!shouldUseServerState() || isLocalHost()) return null;
      const result = await fetchServerUpdateNotice();
      return result?.notice ?? null;
    },
    publish: async (payload) => {
      if (!shouldUseServerState() || isLocalHost()) return null;
      const result = await postServerUpdateNotice('publish', payload);
      return result?.notice ?? null;
    },
    clear: async () => {
      if (!shouldUseServerState() || isLocalHost()) return null;
      const result = await postServerUpdateNotice('clear');
      return result?.notice ?? null;
    },
  },
  transport: {
    listDeliveries: () => callBridge('transport', 'listDeliveries', false),
    listRoutes: () => callBridge('transport', 'listRoutes', false),
    createDelivery: (payload) => callBridge('transport', 'createDelivery', true, payload),
    updateDelivery: (payload) => callBridge('transport', 'updateDelivery', true, payload),
    createRoute: (payload) => callBridge('transport', 'createRoute', true, payload),
    updateRoute: (payload) => callBridge('transport', 'updateRoute', true, payload),
    registerPickupChecklist: (payload) =>
      callBridge('transport', 'registerPickupChecklist', true, payload),
    listVehicles: () => callBridge('transport', 'listVehicles', false),
    createVehicle: (payload) => callBridge('transport', 'createVehicle', true, payload),
    updateVehicle: (payload) => callBridge('transport', 'updateVehicle', true, payload),
    removeVehicle: (payload) => callBridge('transport', 'removeVehicle', true, payload),
    listDrivers: () => callBridge('transport', 'listDrivers', false),
    createDriver: (payload) => callBridge('transport', 'createDriver', true, payload),
    updateDriver: (payload) => callBridge('transport', 'updateDriver', true, payload),
    removeDriver: (payload) => callBridge('transport', 'removeDriver', true, payload),
  },
  calendar: {
    listEvents: () => callBridge('calendar', 'listEvents', false),
    createEvent: (payload) => callBridge('calendar', 'createEvent', true, payload),
    listBoardNotes: async () => {
      if (shouldUseServerState()) await fetchServerCollections(['calendarBoardNotes'], 'calendar-board-notes');
      return getBridge().calendar.listBoardNotes();
    },
    upsertBoardNote: (payload) => callBridge('calendar', 'upsertBoardNote', true, payload),
    removeBoardNote: (payload) => callBridge('calendar', 'removeBoardNote', true, payload),
  },
  settings: {
    get: () => callBridge('settings', 'get', false),
    update: (payload) => callBridge('settings', 'update', true, payload),
  },
  reports: {
    listGenerated: async () => { await ensureServerCollectionsLoaded(['generatedReports'], 'generated-reports'); return callBridge('reports', 'listGenerated', false); },
    generate: (payload) => callBridge('reports', 'generate', true, payload),
  },
  audit: {
    list: async () => { await ensureServerCollectionsLoaded(['systemAuditLog'], 'audit-log'); return callBridge('audit', 'list', false); },
  },
  rentals: {
    list: () => callBridge('rentals', 'list', false),
    getFull: (identifier, reason = 'rental-report') => fetchFullServerRental(identifier, reason),
    create: (payload) => callBridge('rentals', 'create', true, payload),
    updateOperational: updateRentalOperationalOnServer,
    cancel: async (payload) => {
      try {
        const cancelled = await cancelContractOnServer(payload);
        if (cancelled) return cancelled;
      } catch (error) {
        if (!shouldFallbackToBridgeOperation(error)) throw error;
      }
      return callBridge('rentals', 'cancel', true, payload);
    },
    remove: (payload) => callBridge('rentals', 'remove', true, payload),
    registerReturn: async (payload) => {
      if (shouldUseServerState()) return callDirectRentalReturnOperation(payload);
      return callBridge('rentals', 'registerReturn', true, payload);
    },
    updateReturnCharge: (payload) => updateRentalReturnChargeOnServer(payload),
  },
  cash: {
    getDailyReport: async (date) => {
      if (!shouldUseServerState()) return null;
      const response = await fetch(getServerStateUrl(`/accounting/daily-report?date=${encodeURIComponent(date)}`), { cache: 'no-store', headers: getInternalHeaders() });
      if (!response.ok) throw await createServerStateError(response, 'No se pudo cargar el reporte diario.');
      return response.json();
    },
    getOpeningOverview: async () => {
      if (!shouldUseServerState()) {
        const [context, summary] = await Promise.all([api.cash.getAccountingContext(), api.cash.getFastSummary()]);
        return { ...context, summary };
      }
      const response = await fetch(getServerStateUrl('/accounting/opening-overview'), { cache: 'no-store', headers: getInternalHeaders() });
      if (!response.ok) throw await createServerStateError(response, 'No se pudo abrir Contabilidad.');
      const result = await response.json();
      if (result.revision) { lastSharedRevision = result.revision; setCachedServerRevision(result.revision); }
      return result;
    },
    getPettyCategories: async () => {
      if (!shouldUseServerState()) {
        const result = await callBridge('settings', 'get', false);
        return { categories: result.settings?.accounting?.pettyExpenseCategories ?? [] };
      }
      const response = await fetch(getServerStateUrl('/cash/petty-categories'), { cache: 'no-store', headers: getInternalHeaders() });
      if (!response.ok) throw await createServerStateError(response, 'No se pudieron cargar las categorías.');
      return response.json();
    },
    createPettyCategory: async (label) => {
      if (!shouldUseServerState()) {
        const { settings } = await callBridge('settings', 'get', false);
        const result = addPettyExpenseCategory(settings?.accounting?.pettyExpenseCategories, label);
        await callBridge('settings', 'update', true, { accounting: { ...settings?.accounting, pettyExpenseCategories: result.categories } });
        return result;
      }
      const response = await fetch(getServerStateUrl('/cash/petty-categories'), { method: 'POST', headers: getInternalHeaders({ 'Content-Type': 'application/json' }), body: JSON.stringify({ label }) });
      if (!response.ok) throw await createServerStateError(response, 'No se pudo guardar la categoría.');
      const result = await response.json();
      if (result.revision) { lastSharedRevision = result.revision; setCachedServerRevision(result.revision); }
      return result;
    },
    getFastSummary: fetchFastAccountingSummary,
    getSummary: async () => {
      const localSummary = await callBridge('cash', 'getSummary', false);
      if (!shouldUseServerState()) return localSummary;

      const response = await fetch(getServerStateUrl('/accounting/summary'), {
        cache: 'no-store',
        headers: getInternalHeaders(),
      });
      if (!response.ok) {
        throw await createServerStateError(response, 'No se pudo consultar el saldo oficial de las cajas.');
      }
      const serverSummary = await response.json();
      if (serverSummary?.revision) {
        lastSharedRevision = serverSummary.revision;
        setCachedServerRevision(serverSummary.revision);
      }
      return {
        ...localSummary,
        ...serverSummary,
        activeSession: serverSummary?.activeSession ?? localSummary?.activeSession ?? null,
        guaranteeHeldBs: Number(localSummary?.guaranteeHeldBs ?? 0),
        operationalBigCashBs: Number(
          localSummary?.operationalBigCashBs
          ?? serverSummary?.bigCashBalanceBs
          ?? 0
        ),
        treasuryAccounts: Array.isArray(localSummary?.treasuryAccounts)
          ? localSummary.treasuryAccounts
          : [],
        treasuryAllocatedBs: Number(localSummary?.treasuryAllocatedBs ?? 0),
        treasuryUnassignedBs: Number(
          localSummary?.treasuryUnassignedBs
          ?? serverSummary?.bigCashBalanceBs
          ?? 0
        ),
      };
    },
    listSessions: () => callBridge('cash', 'listSessions', false),
    getAccountingContext: async () => {
      if (!shouldUseServerState()) {
        const [movements, debts] = await Promise.all([
          callBridge('cash', 'listMovements', false),
          callBridge('cash', 'listDebts', false),
        ]);
        return { movements, debts, paymentChannels: [], totalMovements: movements.length, truncated: false };
      }
      const response = await fetch(getServerStateUrl('/accounting-context?limit=750'), {
        cache: 'no-store',
        headers: getInternalHeaders(),
      });
      if (!response.ok) {
        throw await createServerStateError(response, 'No se pudo cargar el resumen de contabilidad.');
      }
      const payload = await response.json();
      if (payload?.revision) {
        lastSharedRevision = payload.revision;
        setCachedServerRevision(payload.revision);
      }
      return payload;
    },
    getContractCollections: async (references = []) => {
      const normalizedReferences = Array.isArray(references) ? references : [];
      if (!normalizedReferences.length) return { groups: [] };
      if (!shouldUseServerState()) {
        const movements = await callBridge('cash', 'listMovements', false);
        return { groups: buildContractCollectionGroups({ movements, references: normalizedReferences }) };
      }
      const batches = [];
      for (let index = 0; index < normalizedReferences.length; index += 250) {
        batches.push(normalizedReferences.slice(index, index + 250));
      }
      const payloads = await Promise.all(batches.map(async (batch) => {
        const response = await fetch(getServerStateUrl('/accounting/contract-collections'), {
          method: 'POST',
          cache: 'no-store',
          headers: {
            ...getInternalHeaders(),
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ references: batch }),
        });
        if (!response.ok) {
          throw await createServerStateError(response, 'No se pudo cargar el historial completo de cobros.');
        }
        return response.json();
      }));
      const latestRevision = payloads.find((payload) => payload?.revision)?.revision;
      if (latestRevision) rememberServerRevision(latestRevision);
      return { groups: payloads.flatMap((payload) => payload?.groups ?? []) };
    },
    getAccountLedger: async ({ accountKey = 'all', dateFrom = '', dateTo = '', query = '', limit = 600 } = {}) => {
      if (!shouldUseServerState()) {
        const movements = await callBridge('cash', 'listMovements', false);
        const rows = (Array.isArray(movements) ? movements : [])
          .filter((movement) => String(movement?.cashBoxType ?? '').toUpperCase() === 'BIG_CASH')
          .slice(0, limit);
        return { accounts: [], rows, total: rows.length, summary: { incomeBs: 0, outBs: 0, netBs: 0 } };
      }
      const params = new URLSearchParams({
        accountKey: String(accountKey ?? 'all'),
        limit: String(Math.min(1000, Math.max(20, Number(limit) || 600))),
      });
      if (dateFrom) params.set('dateFrom', String(dateFrom));
      if (dateTo) params.set('dateTo', String(dateTo));
      if (query) params.set('query', String(query));
      const response = await fetch(getServerStateUrl(`/accounting/accounts-ledger?${params.toString()}`), {
        cache: 'no-store',
        headers: getInternalHeaders(),
      });
      if (!response.ok) {
        throw await createServerStateError(response, 'No se pudo cargar el movimiento de la cuenta.');
      }
      const payload = await response.json();
      if (payload?.revision) {
        lastSharedRevision = payload.revision;
        setCachedServerRevision(payload.revision);
      }
      return payload;
    },
    getReceiptProofs: async ({ accountKey = 'all', dateFrom = '', dateTo = '', query = '', limit = 160 } = {}) => {
      if (!shouldUseServerState()) {
        return { accounts: [], rows: [], total: 0 };
      }
      const params = new URLSearchParams({
        accountKey: String(accountKey ?? 'all'),
        limit: String(Math.min(300, Math.max(20, Number(limit) || 160))),
      });
      if (dateFrom) params.set('dateFrom', String(dateFrom));
      if (dateTo) params.set('dateTo', String(dateTo));
      if (query) params.set('query', String(query));
      const response = await fetch(getServerStateUrl(`/accounting/comprobantes?${params.toString()}`), {
        cache: 'no-store',
        headers: getInternalHeaders(),
      });
      if (!response.ok) {
        throw await createServerStateError(response, 'No se pudieron cargar los comprobantes.');
      }
      const payload = await response.json();
      if (payload?.revision) {
        lastSharedRevision = payload.revision;
        setCachedServerRevision(payload.revision);
      }
      return payload;
    },
    getPettyHistory: async () => {
      if (!shouldUseServerState()) {
        const movements = await callBridge('cash', 'listMovements', false);
        const pettyMovements = movements.filter((movement) => (
          String(movement?.cashBoxType ?? '').toUpperCase() === 'PETTY_CASH'
        ));
        return { movements: pettyMovements, total: pettyMovements.length };
      }
      const response = await fetch(getServerStateUrl('/accounting/petty-history'), {
        cache: 'no-store',
        headers: getInternalHeaders(),
      });
      if (!response.ok) {
        throw await createServerStateError(response, 'No se pudo cargar el historial de Caja Chica.');
      }
      const payload = await response.json();
      if (payload?.revision) {
        lastSharedRevision = payload.revision;
        setCachedServerRevision(payload.revision);
      }
      return payload;
    },
    getPettySector: async ({ sector, offset = 0, limit = 80, ...filters } = {}) => {
      if (!shouldUseServerState()) {
        const normalizedSector = String(sector ?? 'expenses').toLowerCase();
        let rows = [];
        if (normalizedSector === 'suppliers') {
          const bundle = await callBridge('suppliers', 'listBundle', false);
          rows = Array.isArray(bundle?.loans) ? bundle.loans : [];
        } else if (normalizedSector === 'debts') {
          rows = await callBridge('cash', 'listDebts', false);
        } else {
          const movements = await callBridge('cash', 'listMovements', false);
          const timeline = buildPettyCashFundTimeline(movements);
          const pettyMovements = movements.filter((movement) => String(movement?.cashBoxType ?? '').toUpperCase() === 'PETTY_CASH' && !movement.accountingArchivedAt && movement.accountingPeriodStatus !== 'archived')
            .map(row => {
              const balance = timeline.byMovementId.get(String(row.id));
              return { ...row, fundBalanceBs: balance?.totalBs ?? null, fundCashBalanceBs: balance?.cashBs ?? null, fundDigitalBalanceBs: balance?.digitalBs ?? null };
            });
          const isAdvance = (movement) => String(movement?.category ?? '').toLowerCase().includes('adelanto')
            || String(movement?.accountingTag ?? '').toLowerCase() === 'personnel_advance';
          if (normalizedSector === 'advances') {
            rows = pettyMovements.filter((movement) => Number(movement?.amountBs ?? 0) < 0 && !movement?.isInternalTransfer && isAdvance(movement));
          } else if (normalizedSector === 'expenses') {
            rows = pettyMovements.filter((movement) => Number(movement?.amountBs ?? 0) !== 0 && !movement?.isInternalTransfer && !isAdvance(movement));
          } else {
            rows = pettyMovements;
          }
        }
        rows = Array.isArray(rows) ? rows : [];
        rows.sort((a, b) => normalizedSector === 'expenses' ? compareCashLedgerOrder(a, b)
          : new Date(b?.createdAt ?? b?.debtDate ?? b?.requestDate ?? 0) - new Date(a?.createdAt ?? a?.debtDate ?? a?.requestDate ?? 0));
        return {
          sector: normalizedSector,
          rows: rows.slice(offset, offset + limit),
          offset,
          limit,
          total: rows.length,
          hasMore: offset + limit < rows.length,
        };
      }
      const params = new URLSearchParams({
        sector: String(sector ?? 'expenses'),
        offset: String(Math.max(0, Number(offset) || 0)),
        limit: String(Math.min(80, Math.max(1, Number(limit) || 80))),
      });
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && String(value).trim() !== '') params.set(key, String(value));
      });
      const response = await fetch(getServerStateUrl(`/accounting/petty-sector?${params.toString()}`), {
        cache: 'no-store',
        headers: getInternalHeaders(),
      });
      if (!response.ok) {
        throw await createServerStateError(response, 'No se pudo cargar el sector de Caja Chica.');
      }
      const payload = await response.json();
      if (payload?.revision) {
        lastSharedRevision = payload.revision;
        setCachedServerRevision(payload.revision);
      }
      return payload;
    },
    listMovements: async (payload) => { await ensureServerCollectionsLoaded(['cashMovements'], 'cash-movements'); return callBridge('cash', 'listMovements', false, payload); },
    listDebts: async () => { await ensureServerCollectionsLoaded(['cashDebts'], 'cash-debts'); return callBridge('cash', 'listDebts', false); },
    openSession: (payload) => callBridge('cash', 'openSession', true, payload),
    closeSession: (payload) => callBridge('cash', 'closeSession', true, payload),
    updateTreasuryAccounts: (payload) => callBridge('cash', 'updateTreasuryAccounts', true, payload),
    createManualMovement: async (payload) => {
      if (shouldUseServerState()) {
        try {
          const directPath = payload?.linkedContractId
            || String(payload?.accountingTag ?? '').includes('guarantee')
            || String(payload?.category ?? '').includes('garantia')
            ? '/cash/manual-economic-movement'
            : '/cash/movement';
          const result = await callDirectCashOperation(directPath, payload);
          return result;
        } catch (error) {
          if (!shouldFallbackToBridgeOperation(error)) throw error;
          console.warn('[copetin-sync] Endpoint directo de caja no disponible; usando compatibilidad local.', error);
        }
      }
      return callBridge('cash', 'createManualMovement', true, payload);
    },
    approveFundDelivery: async (payload = {}) => {
      if (!shouldUseServerState()) throw new Error('La aprobacion de entrega de fondos requiere conexion con el servidor.');
      const movementId = String(payload?.movementId ?? payload?.id ?? '').trim();
      if (!movementId) throw new Error('Entrega de fondos no identificada.');
      const response = await fetch(getServerStateUrl(`/cash/fund-delivery/${encodeURIComponent(movementId)}/approve`), {
        method: 'PATCH', cache: 'no-store',
        headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw await createServerStateError(response, 'No se pudo aprobar la entrega de fondos.');
      const result = await response.json();
      if (result?.revision) { lastSharedRevision = result.revision; setCachedServerRevision(result.revision); }
      await applyDirectCashResultLocally(result);
      announceDataChange({ domain: 'cash', method: 'approveFundDelivery', collections: ['cashMovements'] });
      return result;
    },
    updatePettyExpense: async (payload) => {
      if (!shouldUseServerState()) throw new Error('La edicion atomica requiere conexion con el servidor.');
      const movementId = String(payload?.movementId ?? payload?.id ?? '').trim();
      const response = await fetch(getServerStateUrl(`/cash/petty-expense/${encodeURIComponent(movementId)}`), {
        method: 'PATCH', cache: 'no-store',
        headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw await createServerStateError(response, 'No se pudo editar el gasto de Caja Chica.');
      const result = await response.json();
      if (result?.revision) { lastSharedRevision = result.revision; setCachedServerRevision(result.revision); }
      await applyDirectCashResultLocally(result);
      announceDataChange({ domain: 'cash', method: 'updatePettyExpense' });
      return result;
    },
    deletePettyExpense: async (payload) => {
      if (!shouldUseServerState()) throw new Error('La eliminacion atomica requiere conexion con el servidor.');
      const movementId = String(payload?.movementId ?? payload?.id ?? '').trim();
      const response = await fetch(getServerStateUrl(`/cash/petty-expense/${encodeURIComponent(movementId)}`), {
        method: 'DELETE', cache: 'no-store',
        headers: getInternalHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw await createServerStateError(response, 'No se pudo eliminar el gasto de Caja Chica.');
      const result = await response.json();
      if (result?.revision) { lastSharedRevision = result.revision; setCachedServerRevision(result.revision); }
      announceDataChange({ domain: 'cash', method: 'deletePettyExpense' });
      return result;
    },
    updateMovementReceipt: async (payload) => {
      if (shouldUseServerState()) return callDirectCashOperation('/cash/update-receipt-metadata', payload);
      return callBridge('cash', 'updateMovementReceipt', true, payload);
    },
    voidAndReplaceMovementReceipt: (payload) => callBridge('cash', 'voidAndReplaceMovementReceipt', true, payload),
    collectReceivable: async (payload) => {
      if (shouldUseServerState()) return callDirectCashOperation('/cash/collect-receivable', payload);
      return callBridge('cash', 'collectReceivable', true, payload);
    },
    topUpVipPrepaid: async (payload) => {
      if (!shouldUseServerState()) throw new Error('La recarga VIP atomica requiere conexion con el servidor.');
      return callDirectCashOperation('/cash/vip-prepaid/top-up', payload);
    },
    repairVipPrepaid: async () => {
      if (!shouldUseServerState()) return { ok: true, repaired: 0, repairs: [] };
      return callDirectCashOperation('/accounting/vip-prepaid/repair', {});
    },
    createDebt: (payload) => callBridge('cash', 'createDebt', true, payload),
    payDebt: (payload) => callBridge('cash', 'payDebt', true, payload),
    deleteDebt: (payload) => callBridge('cash', 'deleteDebt', true, payload),
    printHistoryReport: (payload) => callBridge('cash', 'printHistoryReport', false, payload),
  },
  attendance: {
    listUsers: () => fetchAttendanceUsersDirect(),
    listRecords: (filters) => fetchAttendanceRecordsDirect(filters),
    createRecord: (payload) => createAttendanceRecordDirect(payload),
  },
  lincoln: {
    createCashFunds: ({funds,revision,actor}) => callLincolnMutation('/__lincoln_db/cash/funds',{body:{funds,revision,actor},fallback:'No se pudo registrar el ingreso de fondos.'}),
    createCashRendition: ({rendition,revision,actor}) => callLincolnMutation('/__lincoln_db/cash/renditions',{body:{rendition,revision,actor},fallback:'No se pudo guardar la rendición de caja.'}),
    updateEconomicMovement: ({id,movement,revision,actor}) => callLincolnMutation(`/__lincoln_db/economic-movements/${encodeURIComponent(id)}`,{method:'PUT',body:{movement,revision,actor},fallback:'No se pudo editar el movimiento y su recibo.'}),
    deleteEconomicMovement: ({id,reason,revision,actor}) => callLincolnMutation(`/__lincoln_db/economic-movements/${encodeURIComponent(id)}`,{method:'DELETE',body:{reason,revision,actor},fallback:'No se pudo eliminar el movimiento.'}),
    deleteContract: ({eventId,reason,revision,actor}) => callLincolnMutation(`/__lincoln_db/events/${encodeURIComponent(eventId)}`,{method:'DELETE',body:{reason,revision,actor},fallback:'No se pudo eliminar el contrato.'}),
    getState: () => fetchLincolnState(),
    getCommercialOverview: (payload) => fetchLincolnCommercialOverview(payload),
    getContractPdf: (payload) => fetchLincolnContractPdf(payload),
    getClientsOverview: (payload) => fetchLincolnClientsOverview(payload),
    getRoomsOverview: (payload) => fetchLincolnRoomsOverview(payload),
    getPackagesOverview: (payload) => fetchLincolnPackagesOverview(payload),
    getAgendaMonth: (payload) => fetchLincolnAgendaMonth(payload),
    getAgendaYear: (payload) => fetchLincolnAgendaYear(payload),
    getSettlements: (payload) => fetchLincolnSettlements(payload),
    getSettlementDetail: (payload) => fetchLincolnSettlementDetail(payload),
    getMonthlyReport: (payload) => fetchLincolnMonthlyReport(payload),
    getAnnualReport: (payload) => fetchLincolnAnnualReport(payload),
    getEventReport: (payload) => fetchLincolnEventReport(payload),
    setSettlementStatus: (payload) => setLincolnSettlementStatus(payload),
    replaceState: (payload) => replaceLincolnState(payload),
    createRecord: (payload) => mutateLincolnRecord(payload),
    updateRecord: (payload) => mutateLincolnRecord(payload),
    convertReservation: (payload) => convertLincolnReservation(payload),
    createEventPayment: (payload) => createLincolnEventPayment(payload),
    createEconomicEntry: (payload) => createLincolnEconomicEntry(payload),
    resetEventEconomics: (payload) => resetLincolnEventEconomics(payload),
    voidEventPayment: (payload) => voidLincolnEventPayment(payload),
    returnGuarantee: (payload) => returnLincolnEventGuarantee(payload),
    createExpense: (payload) => mutateLincolnExpense(payload),
    updateExpense: (payload) => mutateLincolnExpense(payload),
    verifyResetAccess: (payload) => verifyLincolnResetAccess(payload),
    analyzeReset: (payload) => analyzeLincolnReset(payload),
    executeReset: (payload) => executeLincolnReset(payload),
    exportDatabase: (payload) => exportLincolnDatabase(payload),
  },
  system: {
    verifyResetAccess: (payload) => callBridge('system', 'verifyResetAccess', false, payload),
    analyzeReset: (payload) => (
      isAccountingOnlyReset(payload)
        ? analyzeAccountingResetOnServer(payload)
        : callBridge('system', 'analyzeReset', false, payload)
    ),
    executeReset: (payload) => (
      isAccountingOnlyReset(payload)
        ? executeAccountingResetOnServer(payload)
        : callBridge('system', 'executeReset', true, payload)
    ),
    exportDatabase: (payload) => exportDatabaseDirect(payload),
    importDatabase: (payload) => importDatabaseDirect(payload),
    listResetLogs: () => callBridge('system', 'listResetLogs', false),
    reset: (payload) => callBridge('system', 'reset', true, payload),
  },
  printer: {
    printRentalReceipt: (payload) => callBridge('printer', 'printRentalReceipt', false, payload),
    printReturnReceipt: (payload) => callBridge('printer', 'printReturnReceipt', false, payload),
    printCashMovementReceipt: async (payload) => {
      if (!shouldUseServerState() || payload?.movement?.accountingTag === 'guarantee_damage_application') {
        return callBridge('printer', 'printCashMovementReceipt', false, payload);
      }
      const movementId = String(payload?.movementId ?? payload?.id ?? '').trim();
      if (!movementId) throw new Error('Debes indicar el movimiento de caja para imprimir.');
      const response = await fetch(getServerStateUrl(`/accounting/receipt-context/${encodeURIComponent(movementId)}`), {
        cache: 'no-store', headers: getInternalHeaders(),
      });
      if (!response.ok) throw await createServerStateError(response, 'No se pudo consultar el recibo.');
      const receiptContext = await response.json();
      return getBridge().printer.printCashMovementReceipt({ ...payload, receiptContext });
    },
    printContract: (payload) => callBridge('printer', 'printContract', false, payload),
    printInventoryOrder: (payload) => callBridge('printer', 'printInventoryOrder', false, payload),
    printInventoryWeek: (payload) => callBridge('printer', 'printInventoryWeek', false, payload),
    printRouteSheet: (payload) => callBridge('printer', 'printRouteSheet', false, payload),
  },
  dashboard: {
    get: () => callBridge('dashboard', 'get', false),
  },
};
